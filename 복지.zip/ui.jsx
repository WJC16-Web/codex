// ui.jsx — 공용 UI 컴포넌트 (모바일/데스크탑 양쪽에서 사용)

// ─── Tag / Badge ────────────────────────────────────────────────────────
function Tag({ tone = 'neutral', size = 'md', children, dot, style }) {
  const tones = {
    neutral: { bg: 'var(--ink-100)', fg: 'var(--ink-700)', dot: 'var(--ink-500)' },
    navy:    { bg: 'var(--navy-100)', fg: 'var(--navy-800)', dot: 'var(--navy-600)' },
    green:   { bg: 'var(--green-100)', fg: 'var(--green-800)', dot: 'var(--green-600)' },
    danger:  { bg: 'var(--danger-soft)', fg: 'var(--danger)', dot: 'var(--danger)' },
    warn:    { bg: 'var(--warning-soft)', fg: 'var(--warning)', dot: 'var(--warning)' },
    info:    { bg: 'var(--info-soft)', fg: 'var(--info)', dot: 'var(--info)' },
    success: { bg: 'var(--success-soft)', fg: 'var(--success)', dot: 'var(--success)' },
    outline: { bg: 'transparent', fg: 'var(--ink-700)', dot: 'var(--ink-500)', border: '1px solid var(--ink-200)' }
  };
  const t = tones[tone] || tones.neutral;
  const sizes = {
    sm: { padding: '2px 8px', fontSize: 11, gap: 5 },
    md: { padding: '3px 10px', fontSize: 12, gap: 6 },
    lg: { padding: '5px 12px', fontSize: 13, gap: 7 }
  };
  const s = sizes[size];
  return (
    <span style={{
      display: 'inline-flex', alignItems: 'center', gap: s.gap,
      padding: s.padding, fontSize: s.fontSize, fontWeight: 600,
      background: t.bg, color: t.fg, border: t.border || 'none',
      borderRadius: 'var(--r-pill)', lineHeight: 1.4, ...style
    }}>
      {dot && <span style={{ width: 6, height: 6, borderRadius: '50%', background: t.dot }} />}
      {children}
    </span>
  );
}

// ─── Button ─────────────────────────────────────────────────────────────
function Btn({ kind = 'primary', size = 'md', children, icon, full, onClick, style }) {
  const kinds = {
    primary: { bg: 'var(--navy-700)', fg: '#fff', hover: 'var(--navy-800)' },
    secondary: { bg: 'var(--navy-100)', fg: 'var(--navy-800)', hover: 'var(--navy-200)' },
    accent: { bg: 'var(--green-700)', fg: '#fff', hover: 'var(--green-800)' },
    ghost: { bg: 'transparent', fg: 'var(--ink-700)', hover: 'var(--ink-100)' },
    outline: { bg: '#fff', fg: 'var(--ink-800)', border: '1px solid var(--ink-200)', hover: 'var(--ink-50)' },
    danger: { bg: 'var(--danger)', fg: '#fff', hover: '#A92A24' }
  };
  const k = kinds[kind];
  const sizes = {
    xs: { padding: '4px 10px', fontSize: 12, height: 26, radius: 6 },
    sm: { padding: '6px 12px', fontSize: 13, height: 32, radius: 8 },
    md: { padding: '8px 16px', fontSize: 14, height: 38, radius: 9 },
    lg: { padding: '12px 20px', fontSize: 15, height: 46, radius: 11 }
  };
  const s = sizes[size];
  return (
    <button onClick={onClick} style={{
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6,
      background: k.bg, color: k.fg, border: k.border || 'none',
      padding: s.padding, fontSize: s.fontSize, height: s.height, borderRadius: s.radius,
      fontWeight: 600, width: full ? '100%' : 'auto', whiteSpace: 'nowrap', ...style
    }}>
      {icon}
      {children}
    </button>
  );
}

// ─── Card ───────────────────────────────────────────────────────────────
function Card({ children, padding = 20, style, ...rest }) {
  return (
    <div {...rest} style={{
      background: 'var(--bg-card)', borderRadius: 'var(--r-lg)',
      border: '1px solid var(--ink-100)', padding,
      boxShadow: 'var(--shadow-sm)', ...style
    }}>
      {children}
    </div>
  );
}

// ─── KPI ────────────────────────────────────────────────────────────────
function KPI({ label, value, unit, delta, tone = 'neutral', icon, style }) {
  const deltaColor = !delta ? null : delta.startsWith('-') ? 'var(--danger)' : 'var(--green-700)';
  return (
    <div style={{
      background: 'var(--bg-card)', borderRadius: 'var(--r-lg)',
      border: '1px solid var(--ink-100)', padding: 18, ...style
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
        <div style={{ fontSize: 12, color: 'var(--ink-500)', fontWeight: 500 }}>{label}</div>
        {icon}
      </div>
      <div style={{ display: 'flex', alignItems: 'baseline', gap: 5, marginTop: 10 }}>
        <span className="num" style={{ fontSize: 26, fontWeight: 700, color: 'var(--ink-900)', letterSpacing: '-0.02em' }}>{value}</span>
        {unit && <span style={{ fontSize: 13, color: 'var(--ink-500)', fontWeight: 500 }}>{unit}</span>}
      </div>
      {delta && (
        <div style={{ fontSize: 12, color: deltaColor, marginTop: 4, fontWeight: 600 }}>{delta}</div>
      )}
    </div>
  );
}

// ─── Icons (currentColor inline SVG) ────────────────────────────────────
const Ic = {
  home: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M3 11l9-7 9 7v9a2 2 0 0 1-2 2h-4v-7h-6v7H5a2 2 0 0 1-2-2v-9z"/></svg>,
  search: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="11" cy="11" r="7"/><path d="m20 20-3.5-3.5"/></svg>,
  chat: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M21 12a8 8 0 1 1-3.4-6.55L21 4l-1.2 4.05A8 8 0 0 1 21 12z"/></svg>,
  heart: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 21s-7-4.35-9.5-9C.5 7.5 4 4 7.5 5.5 9.5 6.3 12 9 12 9s2.5-2.7 4.5-3.5C20 4 23.5 7.5 21.5 12c-2.5 4.65-9.5 9-9.5 9z"/></svg>,
  bell: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M6 8a6 6 0 0 1 12 0c0 7 3 8 3 8H3s3-1 3-8"/><path d="M10 21a2 2 0 0 0 4 0"/></svg>,
  user: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0 1 16 0"/></svg>,
  map: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="m3 6 6-2 6 2 6-2v14l-6 2-6-2-6 2V6z"/><path d="M9 4v16M15 6v16"/></svg>,
  filter: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M3 5h18l-7 9v6l-4-2v-4L3 5z"/></svg>,
  pin: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M12 22s7-7.5 7-13a7 7 0 1 0-14 0c0 5.5 7 13 7 13z"/><circle cx="12" cy="9" r="2.5"/></svg>,
  star: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="m12 2 3 7 7 .8-5.3 4.7L18 22l-6-3.5L6 22l1.3-7.5L2 9.8 9 9z"/></svg>,
  check: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m5 13 4 4L19 7"/></svg>,
  x: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><path d="M6 6l12 12M18 6L6 18"/></svg>,
  plus: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" {...p}><path d="M12 5v14M5 12h14"/></svg>,
  chevR: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m9 6 6 6-6 6"/></svg>,
  chevL: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m15 6-6 6 6 6"/></svg>,
  chevD: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m6 9 6 6 6-6"/></svg>,
  more: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" {...p}><circle cx="5" cy="12" r="1.6"/><circle cx="12" cy="12" r="1.6"/><circle cx="19" cy="12" r="1.6"/></svg>,
  pill: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="3" y="9" width="18" height="6" rx="3" transform="rotate(-30 12 12)"/><path d="M9.7 6.5 17.5 14.3" /></svg>,
  bowl: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M3 11h18a9 9 0 0 1-18 0z"/><path d="M2 21h20"/></svg>,
  shield: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M12 3 4 6v6c0 5 3.5 8 8 9 4.5-1 8-4 8-9V6l-8-3z"/></svg>,
  card: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="2.5" y="5" width="19" height="14" rx="2"/><path d="M2.5 10h19"/></svg>,
  building: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><rect x="4" y="3" width="16" height="18" rx="1.5"/><path d="M9 8h2M13 8h2M9 12h2M13 12h2M9 16h6"/></svg>,
  bed: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M3 18V8M3 14h18v4M21 18v-4c0-1.5-1-3-3-3h-7v3"/><circle cx="7.5" cy="11.5" r="1.8"/></svg>,
  doc: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M14 3H6a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V9z"/><path d="M14 3v6h6M8 13h8M8 17h5"/></svg>,
  chart: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M3 21h18"/><rect x="5" y="11" width="3" height="7"/><rect x="10.5" y="7" width="3" height="11"/><rect x="16" y="13" width="3" height="5"/></svg>,
  arrowUp: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 19V5m-6 6 6-6 6 6"/></svg>,
  arrowDn: (p) => <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.4" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 5v14m6-6-6 6-6-6"/></svg>,
  sparkle: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="currentColor" {...p}><path d="M12 2l1.6 5.4L19 9l-5.4 1.6L12 16l-1.6-5.4L5 9l5.4-1.6z"/><path d="M19 14l.8 2.2L22 17l-2.2.8L19 20l-.8-2.2L16 17l2.2-.8z"/></svg>,
  phone: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" {...p}><path d="M5 4h3l2 5-2.5 1.5a11 11 0 0 0 6 6L15 14l5 2v3a2 2 0 0 1-2 2A16 16 0 0 1 3 6a2 2 0 0 1 2-2z"/></svg>,
  thermo: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M10 14V5a2 2 0 1 1 4 0v9a4 4 0 1 1-4 0z"/><circle cx="12" cy="17" r="1.5" fill="currentColor"/></svg>,
  blood: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M12 3s7 8 7 12a7 7 0 1 1-14 0c0-4 7-12 7-12z"/></svg>,
  camera: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><path d="M3 8h3l2-2.5h8L18 8h3v11H3V8z"/><circle cx="12" cy="13" r="3.5"/></svg>,
  send: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m4 20 18-8L4 4l3 8-3 8z"/><path d="M7 12h15"/></svg>,
  cog: (p) => <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.6 1.6 0 0 0 .3 1.7l.1.1a2 2 0 1 1-2.8 2.8l-.1-.1a1.6 1.6 0 0 0-1.7-.3 1.6 1.6 0 0 0-1 1.5V21a2 2 0 1 1-4 0v-.1a1.6 1.6 0 0 0-1-1.5 1.6 1.6 0 0 0-1.7.3l-.1.1a2 2 0 1 1-2.8-2.8l.1-.1a1.6 1.6 0 0 0 .3-1.7 1.6 1.6 0 0 0-1.5-1H3a2 2 0 1 1 0-4h.1a1.6 1.6 0 0 0 1.5-1 1.6 1.6 0 0 0-.3-1.7l-.1-.1a2 2 0 1 1 2.8-2.8l.1.1a1.6 1.6 0 0 0 1.7.3H9a1.6 1.6 0 0 0 1-1.5V3a2 2 0 1 1 4 0v.1a1.6 1.6 0 0 0 1 1.5 1.6 1.6 0 0 0 1.7-.3l.1-.1a2 2 0 1 1 2.8 2.8l-.1.1a1.6 1.6 0 0 0-.3 1.7V9c.6.3 1 .9 1 1.6H21a2 2 0 1 1 0 4h-.1c-.7 0-1.3.4-1.5 1z"/></svg>,
  alert: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3 1 21h22L12 3z"/><path d="M12 10v5M12 18v.5"/></svg>,
  clock: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.7" {...p}><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>,
  won: (p) => <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M4 6 7 18l3-9 2 7 2-7 3 9 3-12"/><path d="M3 11h18M3 14h18"/></svg>,
  download: (p) => <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3v13m-5-5 5 5 5-5M5 21h14"/></svg>,
};

// ─── Avatar placeholder (initials over color) ───────────────────────────
function Avatar({ name = '김', size = 36, tone = 'navy', style }) {
  const palettes = {
    navy: ['var(--navy-700)', '#fff'],
    green: ['var(--green-700)', '#fff'],
    warm: ['#A85A3D', '#fff'],
    plum: ['#7A4B7A', '#fff'],
    slate: ['var(--ink-600)', '#fff']
  };
  const [bg, fg] = palettes[tone] || palettes.navy;
  return (
    <div style={{
      width: size, height: size, borderRadius: '50%', background: bg, color: fg,
      display: 'inline-flex', alignItems: 'center', justifyContent: 'center',
      fontWeight: 700, fontSize: size * 0.4, flexShrink: 0, ...style
    }}>{name.slice(0, 1)}</div>
  );
}

// ─── Photo placeholder (gradient block w/ optional pin) ─────────────────
function Photo({ tone = 'navy', label, ratio = '4/3', icon, style, children }) {
  const palettes = {
    navy: ['#1B466F', '#4180B0'],
    green: ['#1B7654', '#36A47C'],
    sand: ['#C29A6E', '#E1C399'],
    plum: ['#7A4B7A', '#B58CB5'],
    slate: ['#4A5C72', '#92A0AF'],
    warm: ['#A65A3D', '#D69E80']
  };
  const [a, b] = palettes[tone] || palettes.navy;
  return (
    <div style={{
      aspectRatio: ratio, borderRadius: 'var(--r-md)',
      background: `linear-gradient(135deg, ${a}, ${b})`,
      position: 'relative', overflow: 'hidden',
      display: 'flex', alignItems: 'center', justifyContent: 'center',
      color: 'rgba(255,255,255,0.85)', ...style
    }}>
      {icon || (
        <svg width="36" height="36" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.4" opacity="0.45">
          <rect x="3" y="5" width="18" height="14" rx="2"/>
          <circle cx="9" cy="11" r="2"/>
          <path d="m3 17 5-5 4 4 3-3 6 6"/>
        </svg>
      )}
      {label && (
        <div style={{ position: 'absolute', left: 10, bottom: 8, fontSize: 11, fontWeight: 600, color: 'rgba(255,255,255,0.85)' }}>
          {label}
        </div>
      )}
      {children}
    </div>
  );
}

// ─── Simple bar/spark ───────────────────────────────────────────────────
function Spark({ values, color = 'var(--navy-700)', width = 120, height = 36 }) {
  const max = Math.max(...values);
  const min = Math.min(...values);
  const range = max - min || 1;
  const pts = values.map((v, i) => {
    const x = (i / (values.length - 1)) * width;
    const y = height - ((v - min) / range) * (height - 4) - 2;
    return `${x},${y}`;
  }).join(' ');
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

function Bars({ values, color = 'var(--navy-600)', width = 200, height = 60, gap = 4 }) {
  const max = Math.max(...values);
  const bw = (width - gap * (values.length - 1)) / values.length;
  return (
    <svg width={width} height={height} style={{ display: 'block' }}>
      {values.map((v, i) => {
        const h = (v / max) * (height - 4);
        return <rect key={i} x={i * (bw + gap)} y={height - h} width={bw} height={h} rx={2} fill={color} opacity={0.85} />;
      })}
    </svg>
  );
}

// ─── Donut ──────────────────────────────────────────────────────────────
function Donut({ percent, size = 60, stroke = 8, color = 'var(--navy-700)', track = 'var(--ink-100)', label }) {
  const r = (size - stroke) / 2;
  const c = 2 * Math.PI * r;
  const off = c * (1 - percent / 100);
  return (
    <div style={{ position: 'relative', width: size, height: size }}>
      <svg width={size} height={size} style={{ transform: 'rotate(-90deg)' }}>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={track} strokeWidth={stroke}/>
        <circle cx={size/2} cy={size/2} r={r} fill="none" stroke={color} strokeWidth={stroke} strokeDasharray={c} strokeDashoffset={off} strokeLinecap="round"/>
      </svg>
      {label && (
        <div style={{ position: 'absolute', inset: 0, display: 'flex', alignItems: 'center', justifyContent: 'center', fontSize: 13, fontWeight: 700 }}>{label}</div>
      )}
    </div>
  );
}

// ─── Map mock (서울 시설 위치) ──────────────────────────────────────────
function MapMock({ height = 360, pins = [] }) {
  return (
    <div style={{
      width: '100%', height, borderRadius: 'var(--r-md)', overflow: 'hidden', position: 'relative',
      background: 'linear-gradient(180deg, #DCE8F0 0%, #E6EEF4 100%)'
    }}>
      {/* roads */}
      <svg width="100%" height="100%" viewBox="0 0 400 360" preserveAspectRatio="none" style={{ position: 'absolute', inset: 0 }}>
        <defs>
          <pattern id="grid" width="40" height="40" patternUnits="userSpaceOnUse">
            <path d="M40 0H0V40" fill="none" stroke="#C7D4DE" strokeWidth="0.5"/>
          </pattern>
        </defs>
        <rect width="400" height="360" fill="url(#grid)"/>
        {/* rivers */}
        <path d="M0 220 Q120 200 200 230 T400 210" stroke="#9CC1D9" strokeWidth="22" fill="none" opacity="0.7"/>
        {/* roads */}
        <path d="M0 80 L400 100" stroke="#fff" strokeWidth="6"/>
        <path d="M0 80 L400 100" stroke="#D4DEE6" strokeWidth="1"/>
        <path d="M140 0 L160 360" stroke="#fff" strokeWidth="6"/>
        <path d="M140 0 L160 360" stroke="#D4DEE6" strokeWidth="1"/>
        <path d="M280 0 L300 360" stroke="#fff" strokeWidth="4"/>
        <path d="M0 280 L400 300" stroke="#fff" strokeWidth="4"/>
        {/* blocks */}
        <rect x="40" y="20" width="80" height="50" fill="#E5EBEF" rx="2"/>
        <rect x="180" y="120" width="90" height="60" fill="#E5EBEF" rx="2"/>
        <rect x="40" y="260" width="100" height="60" fill="#E5EBEF" rx="2"/>
        <rect x="310" y="40" width="70" height="50" fill="#E5EBEF" rx="2"/>
        <rect x="220" y="270" width="80" height="50" fill="#E5EBEF" rx="2"/>
        {/* parks */}
        <circle cx="350" cy="240" r="40" fill="#CDE3D2"/>
        <circle cx="80" cy="160" r="30" fill="#CDE3D2"/>
      </svg>
      {/* pins */}
      {pins.map((p, i) => (
        <div key={i} style={{
          position: 'absolute', left: `${p.x}%`, top: `${p.y}%`,
          transform: 'translate(-50%, -100%)',
          display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 0
        }}>
          {p.label && (
            <div style={{
              background: '#fff', padding: '4px 10px 5px', borderRadius: 'var(--r-pill)',
              fontSize: 11, fontWeight: 700, color: 'var(--ink-900)',
              boxShadow: 'var(--shadow-md)', marginBottom: 4,
              whiteSpace: 'nowrap',
              border: p.selected ? '2px solid var(--navy-700)' : '1px solid var(--ink-200)'
            }}>{p.label}</div>
          )}
          <svg width="22" height="28" viewBox="0 0 22 28">
            <path d="M11 0a11 11 0 0 1 11 11c0 8-11 17-11 17S0 19 0 11A11 11 0 0 1 11 0z" fill={p.selected ? 'var(--navy-800)' : 'var(--navy-700)'}/>
            <circle cx="11" cy="11" r="4" fill="#fff"/>
          </svg>
        </div>
      ))}
      {/* compass */}
      <div style={{ position: 'absolute', right: 12, top: 12, background: '#fff', borderRadius: 6, padding: '6px 8px', fontSize: 10, fontWeight: 700, color: 'var(--ink-700)', boxShadow: 'var(--shadow-sm)' }}>N</div>
      {/* zoom */}
      <div style={{ position: 'absolute', right: 12, bottom: 12, background: '#fff', borderRadius: 8, boxShadow: 'var(--shadow-md)', display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
        <button style={{ width: 32, height: 32, borderBottom: '1px solid var(--ink-100)', fontSize: 16, color: 'var(--ink-700)' }}>＋</button>
        <button style={{ width: 32, height: 32, fontSize: 16, color: 'var(--ink-700)' }}>−</button>
      </div>
    </div>
  );
}

// ─── Star rating ────────────────────────────────────────────────────────
function Stars({ value = 4.5, size = 14 }) {
  return (
    <span style={{ display: 'inline-flex', gap: 1, alignItems: 'center', color: '#E89C2D' }}>
      {[1,2,3,4,5].map(n => (
        <svg key={n} width={size} height={size} viewBox="0 0 24 24" fill={n <= value ? 'currentColor' : 'var(--ink-200)'}>
          <path d="m12 2 3 7 7 .8-5.3 4.7L18 22l-6-3.5L6 22l1.3-7.5L2 9.8 9 9z"/>
        </svg>
      ))}
    </span>
  );
}

Object.assign(window, { Tag, Btn, Card, KPI, Ic, Avatar, Photo, Spark, Bars, Donut, MapMock, Stars });
