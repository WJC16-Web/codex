// mobile-app.jsx — 보호자 앱 7개 화면
// 각 화면은 iOS device frame 안에 들어가는 내부 콘텐츠 영역.
// iPhone safe area를 고려해 상단 status bar 영역과 하단 home indicator는 frame이 처리.

// ─── Shared mobile bits ─────────────────────────────────────────────────
const M_W = 390;     // iPhone 15 design width
const M_H = 844;
const CONTENT_H = M_H - 47 - 34; // minus iOS status & home indicator

function MAppHeader({ title, right, dark, subtitle, large }) {
  return (
    <div style={{
      padding: large ? '14px 20px 18px' : '14px 20px 14px',
      background: dark ? 'var(--navy-900)' : 'transparent',
      color: dark ? '#fff' : 'var(--ink-900)'
    }}>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div style={{ fontSize: large ? 26 : 19, fontWeight: 700, letterSpacing: '-0.02em' }}>{title}</div>
        <div style={{ display: 'flex', gap: 12 }}>{right}</div>
      </div>
      {subtitle && <div style={{ fontSize: 13, color: dark ? 'rgba(255,255,255,0.7)' : 'var(--ink-500)', marginTop: 4 }}>{subtitle}</div>}
    </div>
  );
}

function MTabBar({ active = 'home' }) {
  const tabs = [
    { id: 'home', label: '홈', icon: Ic.home },
    { id: 'find', label: '시설 찾기', icon: Ic.search },
    { id: 'care', label: '케어 현황', icon: Ic.heart },
    { id: 'chat', label: '상담', icon: Ic.chat },
    { id: 'my', label: '마이', icon: Ic.user },
  ];
  return (
    <div style={{
      position: 'absolute', left: 0, right: 0, bottom: 0,
      background: '#fff', borderTop: '1px solid var(--ink-100)',
      paddingTop: 8, paddingBottom: 28,
      display: 'flex', justifyContent: 'space-around'
    }}>
      {tabs.map(t => {
        const Icon = t.icon;
        const on = t.id === active;
        return (
          <div key={t.id} style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: 3, color: on ? 'var(--navy-700)' : 'var(--ink-400)' }}>
            <Icon />
            <div style={{ fontSize: 10, fontWeight: on ? 700 : 500 }}>{t.label}</div>
          </div>
        );
      })}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-1. 홈
// ═══════════════════════════════════════════════════════════════════════
function MobileHome() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      {/* Hero header w/ parent summary */}
      <div style={{
        background: 'linear-gradient(180deg, var(--navy-800) 0%, var(--navy-700) 100%)',
        color: '#fff', padding: '14px 20px 22px'
      }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
          <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.7)', fontWeight: 500 }}>2026년 5월 28일 목</div>
          <div style={{ display: 'flex', gap: 14 }}>
            <Ic.bell style={{ color: '#fff' }}/>
            <Ic.cog style={{ color: '#fff' }}/>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Avatar name="박" tone="warm" size={52} style={{ border: '2px solid rgba(255,255,255,0.3)' }}/>
          <div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginBottom: 2 }}>아버지</div>
            <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em' }}>박정호 님</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)', marginTop: 4 }}>은빛마을 요양원 · 304호</div>
          </div>
        </div>
        {/* Quick stat row */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8, marginTop: 18 }}>
          {[
            { l: '오늘 식사', v: '3/3', tone: 'ok' },
            { l: '복약', v: '완료', tone: 'ok' },
            { l: '체온', v: '36.5°', tone: 'ok' },
          ].map((s, i) => (
            <div key={i} style={{ background: 'rgba(255,255,255,0.1)', borderRadius: 10, padding: '10px 12px', backdropFilter: 'blur(8px)' }}>
              <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.7)', fontWeight: 500 }}>{s.l}</div>
              <div style={{ fontSize: 15, fontWeight: 700, marginTop: 2, color: '#fff' }}>{s.v}</div>
            </div>
          ))}
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '16px 16px 80px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* Urgent alert */}
        <div style={{ background: 'var(--danger-soft)', border: '1px solid #F3CFCB', borderRadius: 12, padding: '12px 14px', display: 'flex', gap: 10, alignItems: 'flex-start' }}>
          <Ic.alert style={{ color: 'var(--danger)', flexShrink: 0, marginTop: 1 }}/>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--danger)' }}>5월 정기 검진 일정 안내</div>
            <div style={{ fontSize: 12, color: 'var(--ink-700)', marginTop: 2 }}>6월 3일(화) 오전 10시 — 응답 필요</div>
          </div>
          <Ic.chevR style={{ color: 'var(--danger)', marginTop: 2 }}/>
        </div>

        {/* Today's photo */}
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <Photo tone="green" ratio="16/10" label="오늘 오후 활동 · 원예 프로그램"/>
          <div style={{ padding: '12px 14px' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--ink-900)' }}>오늘의 활동</div>
              <Tag tone="green" size="sm" dot>실시간</Tag>
            </div>
            <div style={{ fontSize: 12, color: 'var(--ink-500)', marginTop: 4 }}>15분 전 · 활동실에서 원예 수업 참여</div>
          </div>
        </Card>

        {/* Notice */}
        <Card padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>시설 공지</div>
            <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>더보기</span>
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <Tag tone="navy" size="sm">신규</Tag>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, color: 'var(--ink-800)', fontWeight: 600 }}>6월 가족 면회 신청 안내</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>1일 전</div>
            </div>
          </div>
        </Card>

        {/* Bill */}
        <Card padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 500 }}>5월 청구 비용</div>
              <div style={{ fontSize: 20, fontWeight: 700, color: 'var(--ink-900)', marginTop: 2, letterSpacing: '-0.02em' }} className="num">2,184,000<span style={{ fontSize: 13, color: 'var(--ink-500)', marginLeft: 4, fontWeight: 500 }}>원</span></div>
              <Tag tone="success" size="sm" dot style={{ marginTop: 6 }}>자동결제 6월 5일</Tag>
            </div>
            <Btn kind="secondary" size="sm">상세</Btn>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-2. 시설 찾기 (지도 + 리스트)
// ═══════════════════════════════════════════════════════════════════════
function MobileFind() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', position: 'relative', display: 'flex', flexDirection: 'column' }}>
      {/* Search bar */}
      <div style={{ padding: '12px 16px 8px', background: '#fff', borderBottom: '1px solid var(--ink-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, background: 'var(--ink-50)', borderRadius: 10, padding: '10px 12px' }}>
          <Ic.search style={{ color: 'var(--ink-500)' }}/>
          <div style={{ fontSize: 14, color: 'var(--ink-700)', flex: 1 }}>강남구 · 요양원</div>
          <Ic.x style={{ color: 'var(--ink-400)' }}/>
        </div>
        {/* Filter chips */}
        <div style={{ display: 'flex', gap: 6, marginTop: 10, overflowX: 'auto', paddingBottom: 2 }}>
          {[
            { l: '필터', icon: true, on: false },
            { l: '공실 있음', on: true },
            { l: '1~3등급', on: false },
            { l: '치매 가능', on: true },
            { l: '여성', on: false }
          ].map((c, i) => (
            <div key={i} style={{
              padding: '6px 12px', borderRadius: 'var(--r-pill)',
              fontSize: 12, fontWeight: 600,
              background: c.on ? 'var(--navy-700)' : '#fff',
              color: c.on ? '#fff' : 'var(--ink-700)',
              border: c.on ? 'none' : '1px solid var(--ink-200)',
              whiteSpace: 'nowrap', display: 'inline-flex', alignItems: 'center', gap: 4
            }}>
              {c.icon && <Ic.filter style={{ width: 12, height: 12 }}/>}
              {c.l}
            </div>
          ))}
        </div>
      </div>

      {/* Map area */}
      <div style={{ padding: '12px 16px 0' }}>
        <MapMock height={220} pins={[
          { x: 25, y: 30, label: '은빛마을', selected: false },
          { x: 55, y: 45, label: '햇살요양원', selected: true },
          { x: 70, y: 22, label: '늘봄케어' },
          { x: 35, y: 70, label: '한울' },
          { x: 78, y: 65 }
        ]}/>
      </div>

      {/* Result list */}
      <div style={{ flex: 1, padding: '14px 16px 80px', overflow: 'hidden' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
          <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink-700)' }}>총 <span style={{ color: 'var(--navy-700)' }}>148</span>곳</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 4, fontSize: 12, color: 'var(--ink-700)', fontWeight: 600 }}>
            거리순 <Ic.chevD style={{ width: 12, height: 12 }}/>
          </div>
        </div>
        <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
          {[
            { name: '햇살요양원', dist: '0.8km', rooms: 2, rate: 4.7, reviews: 124, price: '218만원', tag: ['치매 전담','여성동'], tone: 'green', sel: true },
            { name: '늘봄케어센터', dist: '1.2km', rooms: 5, rate: 4.5, reviews: 89, price: '195만원', tag: ['재활 특화','남녀'], tone: 'navy', sel: false }
          ].map((r, i) => (
            <Card key={i} padding={12} style={{ border: r.sel ? '2px solid var(--navy-700)' : '1px solid var(--ink-100)' }}>
              <div style={{ display: 'flex', gap: 12 }}>
                <Photo tone={r.tone} ratio="1" style={{ width: 72, height: 72, flexShrink: 0, borderRadius: 10 }}/>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--ink-900)' }}>{r.name}</div>
                    <Tag tone="green" size="sm" dot>공실 {r.rooms}</Tag>
                  </div>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
                    <Stars value={r.rate} size={11}/>
                    <span style={{ fontSize: 11, fontWeight: 600 }}>{r.rate}</span>
                    <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>({r.reviews})</span>
                    <span style={{ fontSize: 11, color: 'var(--ink-400)', margin: '0 2px' }}>·</span>
                    <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>{r.dist}</span>
                  </div>
                  <div style={{ display: 'flex', gap: 4, marginTop: 6 }}>
                    {r.tag.map(t => <Tag key={t} tone="outline" size="sm">{t}</Tag>)}
                  </div>
                  <div style={{ marginTop: 8, fontSize: 13, fontWeight: 700, color: 'var(--navy-700)' }}>
                    월 {r.price}<span style={{ color: 'var(--ink-500)', fontWeight: 500, fontSize: 11 }}> 부터</span>
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-3. 시설 상세
// ═══════════════════════════════════════════════════════════════════════
function MobileDetail() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      {/* Hero photo */}
      <div style={{ position: 'relative', height: 220 }}>
        <Photo tone="navy" ratio="auto" style={{ width: '100%', height: '100%', borderRadius: 0 }}/>
        <div style={{ position: 'absolute', top: 14, left: 14, right: 14, display: 'flex', justifyContent: 'space-between' }}>
          <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.chevL/></div>
          <div style={{ display: 'flex', gap: 8 }}>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.heart/></div>
            <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'rgba(0,0,0,0.4)', backdropFilter: 'blur(8px)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.send style={{ width: 16, height: 16 }}/></div>
          </div>
        </div>
        <div style={{ position: 'absolute', bottom: 12, right: 14, background: 'rgba(0,0,0,0.5)', backdropFilter: 'blur(8px)', color: '#fff', padding: '4px 10px', borderRadius: 'var(--r-pill)', fontSize: 11, fontWeight: 600 }}>1 / 12</div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '18px 18px 100px', display: 'flex', flexDirection: 'column', gap: 16 }}>
        {/* Title */}
        <div>
          <div style={{ display: 'flex', gap: 6, marginBottom: 8 }}>
            <Tag tone="green" size="sm" dot>공실 2</Tag>
            <Tag tone="navy" size="sm">치매 전담</Tag>
            <Tag tone="outline" size="sm">여성동</Tag>
          </div>
          <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', color: 'var(--ink-900)' }}>햇살요양원</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6, fontSize: 12, color: 'var(--ink-500)' }}>
            <Stars value={4.7} size={12}/>
            <span style={{ color: 'var(--ink-900)', fontWeight: 600 }}>4.7</span>
            <span>· 후기 124</span>
            <span>·</span>
            <span>서울 강남구 역삼동</span>
          </div>
        </div>

        {/* Key facts */}
        <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
          {[
            { l: '월 비용', v: '218만원', s: '본인부담' },
            { l: '정원', v: '48명', s: '현재 46명' },
            { l: '요양보호사', v: '12명', s: '환자 4명당 1명' },
            { l: '간호인력', v: '간호조무사 3', s: '24시간 상주' }
          ].map((k, i) => (
            <div key={i} style={{ background: '#fff', border: '1px solid var(--ink-100)', borderRadius: 10, padding: '10px 12px' }}>
              <div style={{ fontSize: 10, color: 'var(--ink-500)', fontWeight: 500 }}>{k.l}</div>
              <div style={{ fontSize: 15, fontWeight: 700, color: 'var(--ink-900)', marginTop: 2 }}>{k.v}</div>
              <div style={{ fontSize: 10, color: 'var(--ink-500)', marginTop: 1 }}>{k.s}</div>
            </div>
          ))}
        </div>

        {/* Tabs */}
        <div style={{ display: 'flex', gap: 16, borderBottom: '1px solid var(--ink-100)' }}>
          {['소개','시설','프로그램','식단','후기'].map((t, i) => (
            <div key={t} style={{
              padding: '10px 0', fontSize: 13,
              fontWeight: i === 0 ? 700 : 500,
              color: i === 0 ? 'var(--navy-700)' : 'var(--ink-500)',
              borderBottom: i === 0 ? '2px solid var(--navy-700)' : 'none',
              marginBottom: -1
            }}>{t}</div>
          ))}
        </div>

        {/* Photos */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>시설 사진</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
            <Photo tone="navy" ratio="1" style={{ borderRadius: 8 }}/>
            <Photo tone="green" ratio="1" style={{ borderRadius: 8 }}/>
            <Photo tone="sand" ratio="1" style={{ borderRadius: 8 }} label="+9"/>
          </div>
        </div>

        {/* Programs */}
        <div>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 8 }}>운영 프로그램</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 6 }}>
            {[
              { t: '인지 강화 프로그램', d: '월·수·금 오전 10시', tone: 'navy' },
              { t: '원예 치료', d: '화·목 오후 2시', tone: 'green' },
              { t: '음악 치료', d: '주 1회 토요일', tone: 'plum' }
            ].map((p, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 10, background: '#fff', borderRadius: 10, border: '1px solid var(--ink-100)' }}>
                <div style={{ width: 8, height: 32, background: `var(--${p.tone === 'navy' ? 'navy' : p.tone === 'green' ? 'green' : 'navy'}-${p.tone === 'plum' ? 500 : 600})`, borderRadius: 2 }}/>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{p.t}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>{p.d}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Sticky CTA */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '12px 16px 18px', background: '#fff', borderTop: '1px solid var(--ink-100)', display: 'flex', gap: 10 }}>
        <Btn kind="outline" size="md" icon={<Ic.phone/>}>전화</Btn>
        <Btn kind="primary" size="md" full>방문 예약 · 상담</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-4. 상담 센터 (AI 채팅)
// ═══════════════════════════════════════════════════════════════════════
function MobileCounsel() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <MAppHeader title="상담" right={<Ic.more/>} />
      {/* Tabs */}
      <div style={{ display: 'flex', gap: 0, padding: '0 16px', borderBottom: '1px solid var(--ink-100)' }}>
        {['AI 사전상담','실시간 상담','이력'].map((t, i) => (
          <div key={t} style={{ padding: '12px 14px', fontSize: 13, fontWeight: i === 0 ? 700 : 500, color: i === 0 ? 'var(--navy-700)' : 'var(--ink-500)', borderBottom: i === 0 ? '2px solid var(--navy-700)' : '2px solid transparent', marginBottom: -1 }}>{t}</div>
        ))}
      </div>

      {/* Chat area */}
      <div style={{ flex: 1, overflow: 'hidden', padding: '16px 16px 90px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* AI intro */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, var(--navy-700), var(--green-700))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', flexShrink: 0 }}>
            <Ic.sparkle style={{ width: 14, height: 14 }}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 600, marginBottom: 4 }}>케어 AI</div>
            <div style={{ background: '#fff', borderRadius: '4px 14px 14px 14px', padding: '12px 14px', border: '1px solid var(--ink-100)', fontSize: 13, lineHeight: 1.55, color: 'var(--ink-800)' }}>
              안녕하세요. 부모님 시설 입소를 도와드리는 AI 상담사예요. 먼저 몇 가지 여쭤보고 맞는 시설을 추천해 드릴게요.
            </div>
          </div>
        </div>

        {/* AI question */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, var(--navy-700), var(--green-700))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', flexShrink: 0 }}>
            <Ic.sparkle style={{ width: 14, height: 14 }}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ background: '#fff', borderRadius: '4px 14px 14px 14px', padding: '12px 14px', border: '1px solid var(--ink-100)', fontSize: 13, lineHeight: 1.55, color: 'var(--ink-800)', marginBottom: 8 }}>
              부모님 장기요양등급을 알고 계신가요?
            </div>
            <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
              {['1등급','2등급','3등급','4·5등급','등급 없음','잘 모르겠어요'].map(o => (
                <div key={o} style={{ padding: '8px 12px', background: '#fff', border: '1px solid var(--navy-200)', color: 'var(--navy-700)', borderRadius: 'var(--r-pill)', fontSize: 12, fontWeight: 600 }}>{o}</div>
              ))}
            </div>
          </div>
        </div>

        {/* User reply */}
        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
          <div style={{ background: 'var(--navy-700)', color: '#fff', borderRadius: '14px 4px 14px 14px', padding: '10px 14px', fontSize: 13, fontWeight: 500, maxWidth: '78%' }}>2등급이에요</div>
        </div>

        {/* AI followup */}
        <div style={{ display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <div style={{ width: 32, height: 32, borderRadius: '50%', background: 'linear-gradient(135deg, var(--navy-700), var(--green-700))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', flexShrink: 0 }}>
            <Ic.sparkle style={{ width: 14, height: 14 }}/>
          </div>
          <div style={{ flex: 1 }}>
            <div style={{ background: '#fff', borderRadius: '4px 14px 14px 14px', padding: '12px 14px', border: '1px solid var(--ink-100)', fontSize: 13, lineHeight: 1.55, color: 'var(--ink-800)', marginBottom: 8 }}>
              치매 진단을 받으신 적이 있나요?
            </div>
          </div>
        </div>
      </div>

      {/* Input */}
      <div style={{ position: 'absolute', bottom: 0, left: 0, right: 0, padding: '10px 14px 18px', background: '#fff', borderTop: '1px solid var(--ink-100)', display: 'flex', gap: 8, alignItems: 'center' }}>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--ink-50)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic.plus style={{ color: 'var(--ink-600)' }}/></div>
        <div style={{ flex: 1, background: 'var(--ink-50)', borderRadius: 'var(--r-pill)', padding: '10px 16px', fontSize: 13, color: 'var(--ink-400)' }}>메시지 입력</div>
        <div style={{ width: 36, height: 36, borderRadius: '50%', background: 'var(--navy-700)', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic.send style={{ width: 16, height: 16 }}/></div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-5. 부모 케어 현황
// ═══════════════════════════════════════════════════════════════════════
function MobileCare() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <MAppHeader title="아버지 케어 현황" subtitle="박정호 님 · 햇살요양원 304호" right={<Ic.bell/>}/>
      {/* Date selector */}
      <div style={{ display: 'flex', gap: 6, padding: '0 16px 12px', overflowX: 'auto' }}>
        {[
          { d: '25', dow: '월', on: false },
          { d: '26', dow: '화', on: false },
          { d: '27', dow: '수', on: false },
          { d: '28', dow: '목', on: true },
          { d: '29', dow: '금', on: false }
        ].map((d, i) => (
          <div key={i} style={{
            width: 52, padding: '8px 0',
            borderRadius: 10, textAlign: 'center',
            background: d.on ? 'var(--navy-700)' : '#fff',
            color: d.on ? '#fff' : 'var(--ink-700)',
            border: d.on ? 'none' : '1px solid var(--ink-100)'
          }}>
            <div style={{ fontSize: 10, fontWeight: 500, opacity: 0.8 }}>{d.dow}</div>
            <div style={{ fontSize: 16, fontWeight: 700, marginTop: 1 }}>{d.d}</div>
          </div>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '0 16px 80px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Today summary */}
        <Card padding={14}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>오늘 요약</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'var(--green-50)', borderRadius: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--green-100)', color: 'var(--green-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic.bowl/></div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>식사</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--green-700)' }}>3 / 3</div>
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'var(--green-50)', borderRadius: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--green-100)', color: 'var(--green-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic.pill/></div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>복약</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--green-700)' }}>완료</div>
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'var(--navy-50)', borderRadius: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--navy-100)', color: 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic.thermo/></div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>체온</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--navy-800)' }}>36.5°C</div>
              </div>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 12px', background: 'var(--navy-50)', borderRadius: 10 }}>
              <div style={{ width: 32, height: 32, borderRadius: 8, background: 'var(--navy-100)', color: 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Ic.blood/></div>
              <div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>혈압</div>
                <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--navy-800)' }}>128/82</div>
              </div>
            </div>
          </div>
        </Card>

        {/* Timeline */}
        <Card padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>오늘의 기록</div>
            <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>전체 보기</span>
          </div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 0 }}>
            {[
              { t: '15:42', l: '원예 프로그램 참여', s: '활동실 · 사진 3장', tone: 'green', ic: Ic.camera },
              { t: '12:30', l: '점심 식사 완료', s: '잡곡밥 / 된장찌개 / 90% 섭취', tone: 'green', ic: Ic.bowl },
              { t: '09:00', l: '아침 약 복용', s: '혈압약 외 2종', tone: 'navy', ic: Ic.pill },
              { t: '07:15', l: '아침 활력 측정', s: '체온 36.5°C, 혈압 128/82', tone: 'navy', ic: Ic.thermo }
            ].map((it, i, arr) => {
              const Icon = it.ic;
              return (
                <div key={i} style={{ display: 'flex', gap: 10, position: 'relative', paddingBottom: i === arr.length - 1 ? 0 : 12 }}>
                  <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                    <div style={{ width: 28, height: 28, borderRadius: '50%', background: it.tone === 'green' ? 'var(--green-100)' : 'var(--navy-100)', color: it.tone === 'green' ? 'var(--green-700)' : 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                      <Icon style={{ width: 14, height: 14 }}/>
                    </div>
                    {i < arr.length - 1 && <div style={{ width: 2, flex: 1, background: 'var(--ink-100)', marginTop: 2 }}/>}
                  </div>
                  <div style={{ flex: 1, paddingTop: 2 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'baseline' }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{it.l}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 500 }}>{it.t}</div>
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>{it.s}</div>
                  </div>
                </div>
              );
            })}
          </div>
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-6. 결제
// ═══════════════════════════════════════════════════════════════════════
function MobilePayment() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <MAppHeader title="결제" right={<Ic.doc/>}/>

      <div style={{ flex: 1, overflow: 'hidden', padding: '4px 16px 80px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* This month */}
        <div style={{ background: 'linear-gradient(135deg, var(--navy-800), var(--navy-700))', borderRadius: 16, padding: 18, color: '#fff', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', right: -20, top: -20, width: 120, height: 120, borderRadius: '50%', background: 'rgba(255,255,255,0.06)' }}/>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>5월 청구액</div>
          <div className="num" style={{ fontSize: 32, fontWeight: 700, marginTop: 4, letterSpacing: '-0.02em' }}>
            2,184,000<span style={{ fontSize: 15, fontWeight: 500, color: 'rgba(255,255,255,0.7)', marginLeft: 4 }}>원</span>
          </div>
          <div style={{ display: 'flex', gap: 8, marginTop: 10 }}>
            <Tag tone="green" size="sm" dot>자동결제 예정</Tag>
            <Tag tone="outline" size="sm" style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', borderColor: 'rgba(255,255,255,0.2)' }}>6월 5일</Tag>
          </div>
        </div>

        {/* Bill breakdown */}
        <Card padding={14}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>비용 내역</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { l: '시설 이용료 (1인실)', v: '1,650,000' },
              { l: '간병비', v: '420,000' },
              { l: '식비', v: '180,000' },
              { l: '간식·소모품', v: '32,000' },
              { l: '장기요양 본인부담 차감', v: '-98,000', neg: true }
            ].map((b, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 13 }}>
                <div style={{ color: 'var(--ink-700)' }}>{b.l}</div>
                <div className="num" style={{ fontWeight: 600, color: b.neg ? 'var(--green-700)' : 'var(--ink-900)' }}>{b.v}원</div>
              </div>
            ))}
            <div style={{ height: 1, background: 'var(--ink-100)', margin: '4px 0' }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>최종 결제 금액</div>
              <div className="num" style={{ fontSize: 18, fontWeight: 700, color: 'var(--navy-700)' }}>2,184,000원</div>
            </div>
          </div>
        </Card>

        {/* Payment method */}
        <Card padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>결제 수단</div>
            <span style={{ fontSize: 11, color: 'var(--navy-700)', fontWeight: 600 }}>변경</span>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, padding: 12, background: 'var(--bg-sunken)', borderRadius: 10 }}>
            <div style={{ width: 44, height: 30, borderRadius: 4, background: 'linear-gradient(135deg, #2A5F8E, #133355)', display: 'flex', alignItems: 'center', justifyContent: 'flex-end', padding: '0 4px' }}>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: 'rgba(255,255,255,0.5)' }}/>
              <div style={{ width: 8, height: 8, borderRadius: '50%', background: '#fff', marginLeft: -3 }}/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>국민카드 •••• 4892</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>자동결제 등록됨</div>
            </div>
          </div>
        </Card>

        {/* History */}
        <Card padding={14}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 10 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>결제 내역</div>
            <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>전체</span>
          </div>
          {[
            { m: '4월', v: '2,184,000', d: '2026.05.05', s: '완료' },
            { m: '3월', v: '2,184,000', d: '2026.04.05', s: '완료' },
            { m: '2월', v: '2,212,000', d: '2026.03.05', s: '완료' }
          ].map((h, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 0', borderTop: i > 0 ? '1px solid var(--ink-100)' : 'none' }}>
              <div>
                <div style={{ fontSize: 13, fontWeight: 600 }}>{h.m} 시설 이용료</div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>{h.d}</div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="num" style={{ fontSize: 13, fontWeight: 700 }}>{h.v}원</div>
                <Tag tone="success" size="sm" style={{ marginTop: 3 }}>{h.s}</Tag>
              </div>
            </div>
          ))}
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 1-7. 알림
// ═══════════════════════════════════════════════════════════════════════
function MobileNoti() {
  const items = [
    { type: '긴급', tone: 'danger', t: '검진 일정 응답 필요', s: '6월 3일 정기 검진 동의서를 확인해주세요', time: '15분 전', icon: Ic.alert, new: true },
    { type: '공지', tone: 'navy', t: '6월 가족 면회 신청 안내', s: '햇살요양원에서 새로운 공지를 등록했습니다', time: '1시간 전', icon: Ic.building, new: true },
    { type: '케어', tone: 'green', t: '오늘 활동 사진이 업로드되었습니다', s: '원예 프로그램 · 3장', time: '3시간 전', icon: Ic.camera, new: false },
    { type: '비용', tone: 'warn', t: '5월 청구서가 도착했습니다', s: '2,184,000원 · 6월 5일 자동결제', time: '어제', icon: Ic.won, new: false },
    { type: '입소', tone: 'navy', t: '계약서 서명이 완료되었습니다', s: '햇살요양원 입소 계약', time: '2일 전', icon: Ic.doc, new: false },
    { type: '케어', tone: 'green', t: '아침 활력 측정 완료', s: '체온 36.5°C, 혈압 128/82', time: '2일 전', icon: Ic.thermo, new: false }
  ];

  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      <MAppHeader title="알림" right={<><Ic.check/><Ic.cog/></>}/>
      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 6, padding: '0 16px 10px', overflowX: 'auto' }}>
        {[
          { l: '전체', on: true, n: 28 },
          { l: '긴급', n: 1 },
          { l: '공지', n: 4 },
          { l: '케어', n: 18 },
          { l: '비용', n: 3 }
        ].map((c, i) => (
          <div key={i} style={{
            padding: '6px 12px', borderRadius: 'var(--r-pill)',
            background: c.on ? 'var(--navy-700)' : '#fff',
            color: c.on ? '#fff' : 'var(--ink-700)',
            border: c.on ? 'none' : '1px solid var(--ink-200)',
            fontSize: 12, fontWeight: 600,
            display: 'inline-flex', alignItems: 'center', gap: 6, whiteSpace: 'nowrap'
          }}>
            {c.l}
            <span style={{ background: c.on ? 'rgba(255,255,255,0.2)' : 'var(--ink-100)', padding: '0 6px', borderRadius: 'var(--r-pill)', fontSize: 10 }}>{c.n}</span>
          </div>
        ))}
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '0 16px 80px' }}>
        <div style={{ display: 'flex', flexDirection: 'column' }}>
          {items.map((n, i) => {
            const Icon = n.icon;
            const toneColors = {
              danger: { bg: 'var(--danger-soft)', fg: 'var(--danger)' },
              navy: { bg: 'var(--navy-100)', fg: 'var(--navy-700)' },
              green: { bg: 'var(--green-100)', fg: 'var(--green-700)' },
              warn: { bg: 'var(--warning-soft)', fg: 'var(--warning)' }
            };
            const c = toneColors[n.tone];
            return (
              <div key={i} style={{ display: 'flex', gap: 12, padding: '14px 0', borderBottom: i < items.length - 1 ? '1px solid var(--ink-100)' : 'none', alignItems: 'flex-start' }}>
                <div style={{ width: 38, height: 38, borderRadius: 10, background: c.bg, color: c.fg, display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
                  <Icon style={{ width: 18, height: 18 }}/>
                </div>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ display: 'flex', gap: 6, alignItems: 'center' }}>
                    <Tag tone={n.tone === 'warn' ? 'warn' : n.tone} size="sm">{n.type}</Tag>
                    {n.new && <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--danger)' }}/>}
                    <div style={{ marginLeft: 'auto', fontSize: 11, color: 'var(--ink-400)' }}>{n.time}</div>
                  </div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink-900)', marginTop: 5 }}>{n.t}</div>
                  <div style={{ fontSize: 12, color: 'var(--ink-500)', marginTop: 2 }}>{n.s}</div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, {
  M_W, M_H, CONTENT_H, MTabBar, MAppHeader,
  MobileHome, MobileFind, MobileDetail, MobileCounsel, MobileCare, MobilePayment, MobileNoti
});
