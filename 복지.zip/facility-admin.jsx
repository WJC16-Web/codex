// facility-admin.jsx — 시설 관리자 웹 9개 화면 (desktop)

const D_W = 1320;
const D_H = 860;

// ─── Shared Sidebar ─────────────────────────────────────────────────────
function FASidebar({ active = 'dashboard' }) {
  const groups = [
    { label: 'MAIN', items: [
      { id: 'dashboard', t: '대시보드', icon: Ic.chart },
      { id: 'rooms', t: '공실 관리', icon: Ic.bed, badge: '3' },
      { id: 'crm', t: '입소 상담', icon: Ic.chat, badge: '8' },
    ]},
    { label: '운영', items: [
      { id: 'residents', t: '입소자 관리', icon: Ic.user },
      { id: 'guardians', t: '보호자 관리', icon: Ic.heart },
      { id: 'staff', t: '직원 관리', icon: Ic.shield },
    ]},
    { label: '시설', items: [
      { id: 'content', t: '콘텐츠 관리', icon: Ic.building },
      { id: 'billing', t: '정산 관리', icon: Ic.won },
      { id: 'stats', t: '통계', icon: Ic.chart },
    ]}
  ];

  return (
    <div style={{ width: 240, height: '100%', background: 'var(--navy-950)', color: '#fff', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
      {/* Brand */}
      <div style={{ padding: '22px 22px 18px', borderBottom: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          <div style={{ width: 30, height: 30, borderRadius: 8, background: 'linear-gradient(135deg, var(--green-500), var(--navy-400))', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 14 }}>복</div>
          <div>
            <div style={{ fontSize: 14, fontWeight: 700, letterSpacing: '-0.01em' }}>복지 시설 콘솔</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)', marginTop: 1 }}>햇살요양원</div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflowY: 'hidden', padding: '14px 12px' }}>
        {groups.map((g, gi) => (
          <div key={g.label} style={{ marginBottom: 18 }}>
            <div style={{ fontSize: 10, fontWeight: 700, letterSpacing: '0.08em', color: 'rgba(255,255,255,0.4)', padding: '0 12px 6px' }}>{g.label}</div>
            {g.items.map(it => {
              const Icon = it.icon;
              const on = it.id === active;
              return (
                <div key={it.id} style={{
                  display: 'flex', alignItems: 'center', gap: 10,
                  padding: '9px 12px', borderRadius: 8,
                  background: on ? 'rgba(255,255,255,0.08)' : 'transparent',
                  color: on ? '#fff' : 'rgba(255,255,255,0.65)',
                  fontSize: 13, fontWeight: on ? 600 : 500,
                  marginBottom: 2, position: 'relative'
                }}>
                  {on && <div style={{ position: 'absolute', left: 0, top: 7, bottom: 7, width: 3, background: 'var(--green-500)', borderRadius: 2 }}/>}
                  <Icon style={{ width: 17, height: 17, opacity: on ? 1 : 0.85 }}/>
                  <span style={{ flex: 1 }}>{it.t}</span>
                  {it.badge && (
                    <span style={{ background: 'var(--green-700)', color: '#fff', fontSize: 10, fontWeight: 700, padding: '1px 6px', borderRadius: 'var(--r-pill)' }}>{it.badge}</span>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>

      {/* User */}
      <div style={{ padding: 12, borderTop: '1px solid rgba(255,255,255,0.08)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: 8, borderRadius: 8 }}>
          <Avatar name="김" tone="green" size={32}/>
          <div style={{ flex: 1, minWidth: 0 }}>
            <div style={{ fontSize: 12, fontWeight: 600 }}>김지원 원장</div>
            <div style={{ fontSize: 10, color: 'rgba(255,255,255,0.5)' }}>관리자</div>
          </div>
          <Ic.cog style={{ width: 16, height: 16, color: 'rgba(255,255,255,0.5)' }}/>
        </div>
      </div>
    </div>
  );
}

// ─── Topbar ─────────────────────────────────────────────────────────────
function FATopbar({ title, breadcrumb, actions }) {
  return (
    <div style={{ padding: '20px 32px 18px', background: '#fff', borderBottom: '1px solid var(--ink-100)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
      <div>
        {breadcrumb && <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 500, marginBottom: 4 }}>{breadcrumb}</div>}
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.018em' }}>{title}</div>
      </div>
      <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: 'var(--ink-50)', borderRadius: 8, minWidth: 260 }}>
          <Ic.search style={{ width: 16, height: 16, color: 'var(--ink-500)' }}/>
          <span style={{ fontSize: 13, color: 'var(--ink-400)' }}>입소자, 보호자, 상담 검색…</span>
        </div>
        <div style={{ position: 'relative' }}>
          <Ic.bell style={{ color: 'var(--ink-700)' }}/>
          <span style={{ position: 'absolute', top: -2, right: -2, width: 7, height: 7, background: 'var(--danger)', borderRadius: '50%', border: '1.5px solid #fff' }}/>
        </div>
        {actions}
      </div>
    </div>
  );
}

function FAShell({ active, title, breadcrumb, actions, children }) {
  return (
    <div style={{ width: D_W, height: D_H, background: 'var(--bg-app)', display: 'flex', overflow: 'hidden', fontFamily: 'var(--font-sans)' }}>
      <FASidebar active={active}/>
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <FATopbar title={title} breadcrumb={breadcrumb} actions={actions}/>
        <div style={{ flex: 1, padding: '24px 32px', overflow: 'hidden' }}>{children}</div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-1. 대시보드
// ═══════════════════════════════════════════════════════════════════════
function FADashboard() {
  return (
    <FAShell
      active="dashboard"
      title="안녕하세요, 김지원 원장님"
      breadcrumb="햇살요양원 · 2026년 5월 28일 목요일"
      actions={<Btn kind="primary" size="sm" icon={<Ic.plus/>}>긴급 공실 등록</Btn>}
    >
      {/* KPI row */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 18 }}>
        <KPI label="현재 입소" value="46" unit="/ 48명" delta="입소율 95.8%" icon={<Ic.user style={{ color: 'var(--navy-600)' }}/>}/>
        <KPI label="공실" value="2" unit="실" delta="여성동 2 / 남성동 0" icon={<Ic.bed style={{ color: 'var(--green-600)' }}/>}/>
        <KPI label="이번 달 상담" value="38" unit="건" delta="+12 vs 전월" icon={<Ic.chat style={{ color: 'var(--navy-600)' }}/>}/>
        <KPI label="5월 매출" value="9,840" unit="만원" delta="+4.2% vs 전월" icon={<Ic.won style={{ color: 'var(--green-600)' }}/>}/>
      </div>

      {/* Main grid */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14, height: 'calc(100% - 130px)' }}>
        {/* Left col */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Pipeline */}
          <Card padding={20}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
              <div>
                <div className="h3">입소 파이프라인</div>
                <div className="cap" style={{ marginTop: 2 }}>이번 달 진행 중 38건</div>
              </div>
              <div style={{ display: 'flex', gap: 4 }}>
                {['주','월','분기'].map((p, i) => (
                  <div key={p} style={{ padding: '5px 10px', fontSize: 12, fontWeight: 600, color: i === 1 ? 'var(--navy-800)' : 'var(--ink-500)', background: i === 1 ? 'var(--ink-100)' : 'transparent', borderRadius: 6 }}>{p}</div>
                ))}
              </div>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 8 }}>
              {[
                { l: '신규 문의', v: 12, c: 'var(--navy-600)' },
                { l: '상담 중', v: 8, c: 'var(--navy-700)' },
                { l: '방문 예약', v: 6, c: 'var(--green-600)' },
                { l: '계약 진행', v: 4, c: 'var(--green-700)' },
                { l: '입소 완료', v: 8, c: 'var(--green-800)' }
              ].map((s, i) => (
                <div key={i} style={{ padding: '14px 12px', background: 'var(--bg-sunken)', borderRadius: 10, borderLeft: `3px solid ${s.c}` }}>
                  <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 500 }}>{s.l}</div>
                  <div className="num" style={{ fontSize: 22, fontWeight: 700, marginTop: 4 }}>{s.v}</div>
                </div>
              ))}
            </div>
          </Card>

          {/* Revenue chart */}
          <Card padding={20} style={{ flex: 1, minHeight: 0 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div>
                <div className="h3">매출 추이</div>
                <div className="cap" style={{ marginTop: 2 }}>최근 6개월</div>
              </div>
              <div style={{ display: 'flex', gap: 10, fontSize: 11, color: 'var(--ink-500)' }}>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><span style={{ width: 8, height: 8, background: 'var(--navy-700)', borderRadius: 2 }}/>시설료</span>
                <span style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}><span style={{ width: 8, height: 8, background: 'var(--green-600)', borderRadius: 2 }}/>식·간병비</span>
              </div>
            </div>
            <div style={{ height: 200, padding: '10px 0' }}>
              <svg width="100%" height="100%" viewBox="0 0 600 200" preserveAspectRatio="none">
                {[0,1,2,3,4].map(i => <line key={i} x1="0" x2="600" y1={40*i + 10} y2={40*i+10} stroke="var(--ink-100)" strokeWidth="1"/>)}
                {/* bars */}
                {[68,72,75,80,78,84].map((h, i) => {
                  const x = 30 + i * 95;
                  return (
                    <g key={i}>
                      <rect x={x} y={200 - h*1.8} width="32" height={h*1.8} rx="3" fill="var(--navy-700)"/>
                      <rect x={x+34} y={200 - h*0.7} width="32" height={h*0.7} rx="3" fill="var(--green-600)"/>
                    </g>
                  );
                })}
              </svg>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-around', fontSize: 11, color: 'var(--ink-500)', fontWeight: 500, marginTop: 4 }}>
              {['12월','1월','2월','3월','4월','5월'].map(m => <span key={m}>{m}</span>)}
            </div>
          </Card>
        </div>

        {/* Right col */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Vacancy */}
          <Card padding={20}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
              <div className="h3">공실 현황</div>
              <span style={{ fontSize: 12, color: 'var(--navy-700)', fontWeight: 600 }}>관리 →</span>
            </div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 18 }}>
              <Donut percent={95.8} size={88} stroke={10} color="var(--navy-700)" label="95.8%"/>
              <div style={{ flex: 1, display: 'flex', flexDirection: 'column', gap: 8 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                  <span style={{ color: 'var(--ink-700)' }}>여성동</span>
                  <span style={{ fontWeight: 600 }}>22 / 24 <span style={{ color: 'var(--green-700)', marginLeft: 4 }}>공실 2</span></span>
                </div>
                <div style={{ height: 6, background: 'var(--ink-100)', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: '91.7%', background: 'var(--navy-700)' }}/>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12, marginTop: 4 }}>
                  <span style={{ color: 'var(--ink-700)' }}>남성동</span>
                  <span style={{ fontWeight: 600 }}>24 / 24 <span style={{ color: 'var(--danger)', marginLeft: 4 }}>만실</span></span>
                </div>
                <div style={{ height: 6, background: 'var(--ink-100)', borderRadius: 3, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: '100%', background: 'var(--navy-700)' }}/>
                </div>
              </div>
            </div>
          </Card>

          {/* New inquiries */}
          <Card padding={20} style={{ flex: 1, minHeight: 0, display: 'flex', flexDirection: 'column' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
              <div className="h3">신규 문의</div>
              <Tag tone="danger" size="sm" dot>미응답 5</Tag>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 0, flex: 1, overflow: 'hidden' }}>
              {[
                { n: '이상미', r: '서초구', s: '2등급 / 치매 의심', t: '12분 전', tone: 'warm', urgent: true },
                { n: '박기수', r: '강남구', s: '3등급 / 재활', t: '34분 전', tone: 'navy' },
                { n: '정혜영', r: '송파구', s: '4등급 / 자녀 동거', t: '1시간 전', tone: 'green' },
                { n: '한승호', r: '용산구', s: '2등급 / 와상', t: '2시간 전', tone: 'plum' }
              ].map((u, i, a) => (
                <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderTop: i > 0 ? '1px solid var(--ink-100)' : 'none' }}>
                  <Avatar name={u.n[0]} tone={u.tone} size={36}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                      <div style={{ fontSize: 13, fontWeight: 600 }}>{u.n} 보호자</div>
                      {u.urgent && <Tag tone="danger" size="sm">긴급</Tag>}
                    </div>
                    <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>{u.r} · {u.s}</div>
                  </div>
                  <div style={{ fontSize: 11, color: 'var(--ink-400)' }}>{u.t}</div>
                </div>
              ))}
            </div>
          </Card>
        </div>
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-2. 공실 관리
// ═══════════════════════════════════════════════════════════════════════
function FARooms() {
  const rooms = [];
  // 24 rooms in 6 cols x 4 rows
  for (let i = 0; i < 24; i++) {
    const wing = i < 12 ? 'F' : 'M';
    const num = 300 + (i < 12 ? i + 1 : i - 11);
    const states = ['occupied', 'occupied', 'occupied', 'occupied', 'vacant', 'occupied', 'occupied', 'reserved', 'occupied', 'occupied', 'occupied', 'vacant', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied', 'occupied'];
    rooms.push({ no: `${wing}-${num}`, wing, state: states[i] });
  }

  return (
    <FAShell
      active="rooms"
      title="공실 관리"
      breadcrumb="운영 · 공실"
      actions={
        <>
          <Btn kind="outline" size="sm" icon={<Ic.alert/>}>긴급 모집</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>호실 추가</Btn>
        </>
      }
    >
      {/* Summary */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12, marginBottom: 18 }}>
        <KPI label="총 호실" value="48" unit="실"/>
        <KPI label="입소" value="44" unit="실" delta="91.7%" icon={<Ic.user style={{ color: 'var(--navy-600)' }}/>}/>
        <KPI label="공실" value="2" unit="실" delta="여성동 2" icon={<Ic.bed style={{ color: 'var(--green-600)' }}/>}/>
        <KPI label="예약" value="2" unit="실" delta="이번 주 입소"/>
        <KPI label="대기자" value="14" unit="명" delta="여성동 8 / 남성동 6"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 14, height: 'calc(100% - 130px)' }}>
        {/* Floor plan */}
        <Card padding={20} style={{ overflow: 'hidden' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 16 }}>
            <div className="h3">3층 — 여성동 / 남성동</div>
            <div style={{ display: 'flex', gap: 14, fontSize: 11, color: 'var(--ink-600)' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 12, background: 'var(--ink-100)', borderRadius: 3 }}/>입소</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 12, background: 'var(--green-100)', border: '1.5px solid var(--green-600)', borderRadius: 3 }}/>공실</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 12, background: 'var(--warning-soft)', border: '1.5px solid var(--warning)', borderRadius: 3 }}/>예약</span>
            </div>
          </div>

          {/* Wing F */}
          <div style={{ marginBottom: 18 }}>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--navy-800)', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
              여성동 (F-301 ~ F-324)
              <Tag tone="green" size="sm">공실 2</Tag>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 6 }}>
              {rooms.slice(0,12).map(r => {
                const styles = {
                  occupied: { bg: 'var(--ink-50)', border: '1px solid var(--ink-100)', color: 'var(--ink-600)' },
                  vacant: { bg: 'var(--green-100)', border: '1.5px solid var(--green-600)', color: 'var(--green-800)' },
                  reserved: { bg: 'var(--warning-soft)', border: '1.5px solid var(--warning)', color: 'var(--warning)' }
                };
                const s = styles[r.state];
                return (
                  <div key={r.no} style={{ ...s, borderRadius: 8, padding: '12px 6px', textAlign: 'center' }}>
                    <div style={{ fontSize: 11, fontWeight: 700 }}>{r.no.split('-')[1]}</div>
                    <div style={{ fontSize: 9, marginTop: 2, fontWeight: 500, opacity: 0.85 }}>
                      {r.state === 'occupied' ? '입소' : r.state === 'vacant' ? '공실' : '예약'}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Wing M */}
          <div>
            <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--navy-800)', marginBottom: 8, display: 'flex', alignItems: 'center', gap: 8 }}>
              남성동 (M-301 ~ M-324)
              <Tag tone="danger" size="sm">만실</Tag>
            </div>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(12, 1fr)', gap: 6 }}>
              {rooms.slice(12,24).map(r => {
                const s = { bg: 'var(--ink-50)', border: '1px solid var(--ink-100)', color: 'var(--ink-600)' };
                return (
                  <div key={r.no} style={{ ...s, borderRadius: 8, padding: '12px 6px', textAlign: 'center' }}>
                    <div style={{ fontSize: 11, fontWeight: 700 }}>{r.no.split('-')[1]}</div>
                    <div style={{ fontSize: 9, marginTop: 2, fontWeight: 500, opacity: 0.85 }}>입소</div>
                  </div>
                );
              })}
            </div>
          </div>
        </Card>

        {/* Selected room detail */}
        <Card padding={20}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 4 }}>
            <Tag tone="green" dot>공실</Tag>
            <Ic.more style={{ color: 'var(--ink-500)' }}/>
          </div>
          <div className="h2" style={{ marginTop: 8 }}>F-305</div>
          <div className="cap" style={{ marginTop: 2 }}>여성동 · 1인실</div>

          <Photo tone="navy" ratio="16/10" style={{ marginTop: 14, marginBottom: 14 }}/>

          {/* Properties */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
            {[
              { l: '입소 가능 일자', v: '2026.06.01' },
              { l: '월 비용', v: '218만원', tone: 'strong' },
              { l: '치매 가능', v: '가능', tone: 'green' },
              { l: '중증 가능', v: '불가', tone: 'neutral' },
              { l: '대기자', v: '8명' },
            ].map((p, i) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', fontSize: 12 }}>
                <span style={{ color: 'var(--ink-500)' }}>{p.l}</span>
                <span style={{ fontWeight: p.tone === 'strong' ? 700 : 600, color: p.tone === 'green' ? 'var(--green-700)' : 'var(--ink-800)' }}>{p.v}</span>
              </div>
            ))}
          </div>

          <div style={{ height: 1, background: 'var(--ink-100)', margin: '16px 0' }}/>

          <div className="label" style={{ marginBottom: 8 }}>플랫폼 노출</div>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
            <span style={{ fontSize: 13, fontWeight: 600 }}>실시간 공실 노출</span>
            <div style={{ width: 36, height: 20, background: 'var(--green-700)', borderRadius: 'var(--r-pill)', position: 'relative' }}>
              <div style={{ position: 'absolute', right: 2, top: 2, width: 16, height: 16, background: '#fff', borderRadius: '50%' }}/>
            </div>
          </div>

          <Btn kind="primary" full>대기자 연결하기</Btn>
        </Card>
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-3. 입소 상담 CRM (kanban)
// ═══════════════════════════════════════════════════════════════════════
function FACRM() {
  const cols = [
    { id: 'new', t: '신규 문의', n: 12, items: [
      { n: '이상미', age: 72, grade: '2등급', tag: '치매', tone: 'warm', t: '오늘 14:22', src: '앱 문의', priority: 'high' },
      { n: '박기수', age: 78, grade: '3등급', tag: '재활', tone: 'navy', t: '오늘 11:08', src: 'AI 상담' },
      { n: '정혜영', age: 81, grade: '4등급', tag: '경증', tone: 'green', t: '어제 17:30', src: '전화' }
    ]},
    { id: 'consult', t: '상담 중', n: 8, items: [
      { n: '한승호', age: 75, grade: '2등급', tag: '와상', tone: 'plum', t: '내일 10:00', src: '재상담', step: '2차' },
      { n: '오현주', age: 68, grade: '3등급', tag: '치매', tone: 'warm', t: '5/30 14:00', src: '서류 검토', step: '서류' },
      { n: '강민철', age: 80, grade: '2등급', tag: '재활', tone: 'navy', t: '5/29 11:00', src: '비용 협의' }
    ]},
    { id: 'visit', t: '방문 예약', n: 6, items: [
      { n: '윤지영', age: 77, grade: '3등급', tag: '치매', tone: 'green', t: '내일 09:30', src: '시설 투어 ', step: '확정' },
      { n: '서태수', age: 82, grade: '2등급', tag: '와상', tone: 'plum', t: '5/30 15:00', src: '가족 동행' }
    ]},
    { id: 'contract', t: '계약 진행', n: 4, items: [
      { n: '김명자', age: 74, grade: '3등급', tag: '경증', tone: 'navy', t: '입소 6/3', src: '서명 대기', step: '계약서', urgent: true },
      { n: '조용철', age: 79, grade: '2등급', tag: '치매', tone: 'warm', t: '입소 6/5', src: '계약 완료' }
    ]},
    { id: 'done', t: '입소 완료', n: 8, items: [
      { n: '최영순', age: 76, grade: '3등급', tag: '경증', tone: 'green', t: '5/25 입소', src: 'F-308 배정', step: '완료' }
    ]}
  ];

  return (
    <FAShell
      active="crm"
      title="입소 상담"
      breadcrumb="운영 · 상담 CRM"
      actions={
        <>
          <Btn kind="outline" size="sm" icon={<Ic.filter/>}>필터</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>상담 등록</Btn>
        </>
      }
    >
      {/* Filter chips */}
      <div style={{ display: 'flex', gap: 8, marginBottom: 14, alignItems: 'center' }}>
        <Tag tone="navy" size="md">전체 38건</Tag>
        <Tag tone="outline" size="md">긴급 3</Tag>
        <Tag tone="outline" size="md">치매 가능</Tag>
        <Tag tone="outline" size="md">여성</Tag>
        <Tag tone="outline" size="md">이번 주 방문 6</Tag>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 8, fontSize: 12, color: 'var(--ink-500)' }}>
          담당자
          <div style={{ display: 'flex' }}>
            {['김','이','박'].map((n, i) => <Avatar key={n} name={n} tone={['navy','green','warm'][i]} size={26} style={{ marginLeft: i ? -8 : 0, border: '2px solid #fff' }}/>)}
          </div>
        </div>
      </div>

      {/* Kanban */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(5, 1fr)', gap: 12, height: 'calc(100% - 50px)' }}>
        {cols.map((col, ci) => (
          <div key={col.id} style={{ background: 'var(--bg-sunken)', borderRadius: 12, padding: 10, display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '4px 6px 10px' }}>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                <span style={{ width: 8, height: 8, borderRadius: 2, background: ['var(--navy-400)','var(--navy-600)','var(--green-500)','var(--green-700)','var(--green-800)'][ci] }}/>
                <span style={{ fontSize: 13, fontWeight: 700 }}>{col.t}</span>
                <span style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 600 }}>{col.n}</span>
              </div>
              <Ic.plus style={{ width: 14, height: 14, color: 'var(--ink-500)' }}/>
            </div>
            <div style={{ display: 'flex', flexDirection: 'column', gap: 8, overflow: 'hidden' }}>
              {col.items.map((it, i) => (
                <div key={i} style={{ background: '#fff', borderRadius: 10, padding: 12, border: '1px solid var(--ink-100)', boxShadow: 'var(--shadow-sm)' }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                      <Avatar name={it.n[0]} tone={it.tone} size={28}/>
                      <div>
                        <div style={{ fontSize: 12, fontWeight: 700 }}>{it.n} 어르신</div>
                        <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>{it.age}세 · {it.grade}</div>
                      </div>
                    </div>
                    {it.urgent && <Tag tone="danger" size="sm">긴급</Tag>}
                    {it.priority === 'high' && <Tag tone="warn" size="sm">우선</Tag>}
                  </div>
                  <div style={{ display: 'flex', gap: 4, marginTop: 9, flexWrap: 'wrap' }}>
                    <Tag tone="outline" size="sm">{it.tag}</Tag>
                    {it.step && <Tag tone="navy" size="sm">{it.step}</Tag>}
                  </div>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 10, fontSize: 10, color: 'var(--ink-500)' }}>
                    <span style={{ display: 'inline-flex', alignItems: 'center', gap: 3 }}><Ic.clock style={{ width: 10, height: 10 }}/>{it.t}</span>
                    <span>{it.src}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        ))}
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-4. 입소자 관리
// ═══════════════════════════════════════════════════════════════════════
function FAResidents() {
  const rows = [
    { n: '박정호', age: 78, sex: 'M', room: 'M-304', grade: '2등급', cond: '치매 중기', g: '박소영(딸)', in: '2024.03.12', stat: '활동' },
    { n: '김순례', age: 82, sex: 'F', room: 'F-301', grade: '3등급', cond: '고혈압', g: '김민준(아들)', in: '2024.07.04', stat: '활동' },
    { n: '이갑수', age: 75, sex: 'M', room: 'M-318', grade: '2등급', cond: '재활 중', g: '이지원(딸)', in: '2025.01.20', stat: '병원' },
    { n: '최정심', age: 80, sex: 'F', room: 'F-309', grade: '4등급', cond: '경증 치매', g: '최우식(아들)', in: '2025.03.08', stat: '활동' },
    { n: '윤덕봉', age: 84, sex: 'M', room: 'M-322', grade: '1등급', cond: '와상', g: '윤은혜(딸)', in: '2023.11.15', stat: '활동' },
    { n: '한금자', age: 77, sex: 'F', room: 'F-314', grade: '2등급', cond: '치매 초기', g: '한도윤(아들)', in: '2025.06.30', stat: '활동' },
    { n: '강명환', age: 79, sex: 'M', room: 'M-312', grade: '3등급', cond: '뇌졸중 후', g: '강민서(아들)', in: '2024.09.18', stat: '주의' },
    { n: '서영자', age: 81, sex: 'F', room: 'F-307', grade: '2등급', cond: '파킨슨', g: '서지호(딸)', in: '2024.05.22', stat: '활동' }
  ];

  return (
    <FAShell
      active="residents"
      title="입소자 관리"
      breadcrumb="운영 · 입소자"
      actions={
        <>
          <Btn kind="outline" size="sm" icon={<Ic.download/>}>내보내기</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>입소자 등록</Btn>
        </>
      }
    >
      {/* Filter bar */}
      <div style={{ background: '#fff', borderRadius: 12, padding: '12px 14px', marginBottom: 14, display: 'flex', gap: 10, alignItems: 'center', border: '1px solid var(--ink-100)' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: 6, padding: '8px 12px', background: 'var(--ink-50)', borderRadius: 8, width: 260 }}>
          <Ic.search style={{ width: 14, height: 14, color: 'var(--ink-500)' }}/>
          <span style={{ fontSize: 13, color: 'var(--ink-500)' }}>이름·호실 검색</span>
        </div>
        <Tag tone="navy" size="md">전체 46명</Tag>
        <Tag tone="outline" size="md">여성 22</Tag>
        <Tag tone="outline" size="md">남성 24</Tag>
        <Tag tone="outline" size="md">치매 18</Tag>
        <Tag tone="outline" size="md">주의 3</Tag>
        <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6, fontSize: 12, color: 'var(--ink-700)', fontWeight: 600 }}>
          입소일 순 <Ic.chevD style={{ width: 14, height: 14 }}/>
        </div>
      </div>

      {/* Table */}
      <Card padding={0} style={{ overflow: 'hidden' }}>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: 'var(--bg-sunken)', borderBottom: '1px solid var(--ink-100)' }}>
              {['', '입소자', '호실', '등급', '건강상태', '보호자', '입소일', '오늘 상태', ''].map(h => (
                <th key={h} style={{ padding: '12px 14px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {rows.map((r, i) => (
              <tr key={i} style={{ borderBottom: i < rows.length - 1 ? '1px solid var(--ink-100)' : 'none' }}>
                <td style={{ padding: '12px 14px' }}><div style={{ width: 16, height: 16, border: '1.5px solid var(--ink-300)', borderRadius: 4 }}/></td>
                <td style={{ padding: '12px 14px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <Avatar name={r.n[0]} tone={r.sex === 'F' ? 'plum' : 'navy'} size={32}/>
                    <div>
                      <div style={{ fontWeight: 600 }}>{r.n}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>{r.age}세 · {r.sex === 'F' ? '여' : '남'}</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '12px 14px', fontWeight: 600 }}>{r.room}</td>
                <td style={{ padding: '12px 14px' }}><Tag tone="navy" size="sm">{r.grade}</Tag></td>
                <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }}>{r.cond}</td>
                <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }}>{r.g}</td>
                <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }} className="num">{r.in}</td>
                <td style={{ padding: '12px 14px' }}>
                  <Tag tone={r.stat === '활동' ? 'success' : r.stat === '주의' ? 'warn' : 'info'} size="sm" dot>{r.stat}</Tag>
                </td>
                <td style={{ padding: '12px 14px' }}><Ic.more style={{ color: 'var(--ink-400)' }}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>

      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 16 }}>
        <div style={{ fontSize: 12, color: 'var(--ink-500)' }}>1~8 / 46 명</div>
        <div style={{ display: 'flex', gap: 4 }}>
          {['‹', '1', '2', '3', '4', '5', '6', '›'].map((p, i) => (
            <div key={i} style={{
              width: 32, height: 32, display: 'flex', alignItems: 'center', justifyContent: 'center',
              fontSize: 12, fontWeight: 600, borderRadius: 6,
              background: p === '1' ? 'var(--navy-700)' : '#fff',
              color: p === '1' ? '#fff' : 'var(--ink-700)',
              border: p === '1' ? 'none' : '1px solid var(--ink-200)'
            }}>{p}</div>
          ))}
        </div>
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-5. 보호자 관리
// ═══════════════════════════════════════════════════════════════════════
function FAGuardians() {
  return (
    <FAShell
      active="guardians"
      title="보호자 관리"
      breadcrumb="운영 · 보호자"
      actions={<Btn kind="primary" size="sm" icon={<Ic.send/>}>전체 공지 발송</Btn>}
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 14, height: '100%' }}>
        {/* Left: list */}
        <Card padding={0} style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '14px 18px', borderBottom: '1px solid var(--ink-100)', display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>보호자 46명</div>
            <Tag tone="warn" size="sm">미납 2</Tag>
            <Tag tone="danger" size="sm">민원 1</Tag>
            <div style={{ marginLeft: 'auto', display: 'flex', alignItems: 'center', gap: 6, padding: '6px 10px', background: 'var(--ink-50)', borderRadius: 8 }}>
              <Ic.search style={{ width: 14, height: 14, color: 'var(--ink-500)' }}/>
              <span style={{ fontSize: 12, color: 'var(--ink-500)' }}>이름 검색</span>
            </div>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: 'var(--bg-sunken)' }}>
                {['보호자','입소자','관계','연락처','납부','상담','민원'].map(h => (
                  <th key={h} style={{ padding: '10px 14px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { n: '박소영', tone: 'warm', p: '박정호', rel: '딸', tel: '010-2238-****', pay: '완료', cs: 3, sel: true },
                { n: '김민준', tone: 'navy', p: '김순례', rel: '아들', tel: '010-5532-****', pay: '완료', cs: 1 },
                { n: '이지원', tone: 'green', p: '이갑수', rel: '딸', tel: '010-7791-****', pay: '미납', payTone: 'warn', cs: 2, claim: true },
                { n: '최우식', tone: 'plum', p: '최정심', rel: '아들', tel: '010-3025-****', pay: '완료', cs: 0 },
                { n: '윤은혜', tone: 'warm', p: '윤덕봉', rel: '딸', tel: '010-8847-****', pay: '완료', cs: 4 },
                { n: '한도윤', tone: 'navy', p: '한금자', rel: '아들', tel: '010-2208-****', pay: '예정', payTone: 'info', cs: 1 },
                { n: '강민서', tone: 'green', p: '강명환', rel: '아들', tel: '010-9911-****', pay: '미납', payTone: 'warn', cs: 0 }
              ].map((r, i, a) => (
                <tr key={i} style={{ borderBottom: i < a.length - 1 ? '1px solid var(--ink-100)' : 'none', background: r.sel ? 'var(--navy-50)' : 'transparent' }}>
                  <td style={{ padding: '12px 14px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <Avatar name={r.n[0]} tone={r.tone} size={32}/>
                      <div style={{ fontWeight: 600 }}>{r.n}</div>
                    </div>
                  </td>
                  <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }}>{r.p}</td>
                  <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }}>{r.rel}</td>
                  <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }} className="num">{r.tel}</td>
                  <td style={{ padding: '12px 14px' }}><Tag tone={r.payTone || 'success'} size="sm">{r.pay}</Tag></td>
                  <td style={{ padding: '12px 14px', color: 'var(--ink-700)' }}>{r.cs}건</td>
                  <td style={{ padding: '12px 14px' }}>{r.claim && <Tag tone="danger" size="sm" dot>접수</Tag>}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        {/* Right: detail */}
        <Card padding={20} style={{ overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
            <Avatar name="박" tone="warm" size={52}/>
            <div style={{ flex: 1 }}>
              <div className="h3">박소영</div>
              <div className="cap">박정호 어르신 · 딸</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 16 }}>
            <Btn kind="secondary" size="sm" icon={<Ic.chat/>}>메시지</Btn>
            <Btn kind="outline" size="sm" icon={<Ic.phone/>}>통화</Btn>
          </div>

          <div className="label" style={{ marginBottom: 8 }}>최근 상담 이력</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
            {[
              { d: '5/22', t: '식사량 감소 문의', tone: 'navy' },
              { d: '5/14', t: '6월 면회 일정 확인', tone: 'green' },
              { d: '5/03', t: '의약품 변경 동의', tone: 'navy' }
            ].map((c, i) => (
              <div key={i} style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
                <Tag tone={c.tone} size="sm" style={{ minWidth: 44, justifyContent: 'center' }}>{c.d}</Tag>
                <div style={{ flex: 1, fontSize: 12, color: 'var(--ink-700)' }}>{c.t}</div>
              </div>
            ))}
          </div>

          <div className="label" style={{ marginBottom: 8 }}>이번 달 청구</div>
          <div style={{ padding: 12, background: 'var(--bg-sunken)', borderRadius: 10 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 12, color: 'var(--ink-700)' }}>5월 청구</span>
              <span className="num" style={{ fontSize: 13, fontWeight: 700 }}>2,184,000원</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 6 }}>
              <span style={{ fontSize: 12, color: 'var(--ink-700)' }}>자동결제</span>
              <Tag tone="success" size="sm">6/5 예정</Tag>
            </div>
          </div>
        </Card>
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-6. 직원 관리 (근무표)
// ═══════════════════════════════════════════════════════════════════════
function FAStaff() {
  const days = ['월','화','수','목','금','토','일'];
  const dates = ['25','26','27','28','29','30','31'];
  const staff = [
    { n: '김지영', role: '간호조무사', tone: 'navy', shifts: ['D','D','N','D','-','D','D'] },
    { n: '박경애', role: '요양보호사', tone: 'green', shifts: ['D','D','D','-','D','N','N'] },
    { n: '이순자', role: '요양보호사', tone: 'plum', shifts: ['N','N','-','D','D','D','D'] },
    { n: '한미경', role: '요양보호사', tone: 'warm', shifts: ['D','-','D','D','N','N','-'] },
    { n: '정선미', role: '간호조무사', tone: 'navy', shifts: ['-','D','D','D','D','-','D'] },
    { n: '오영희', role: '조리원', tone: 'green', shifts: ['D','D','D','D','D','-','-'] }
  ];

  const shiftStyle = (s) => {
    if (s === 'D') return { bg: 'var(--navy-100)', fg: 'var(--navy-800)', l: '주간' };
    if (s === 'N') return { bg: 'var(--ink-800)', fg: '#fff', l: '야간' };
    if (s === '-') return { bg: 'var(--ink-50)', fg: 'var(--ink-400)', l: '휴무' };
    return { bg: 'var(--ink-50)', fg: 'var(--ink-400)', l: '' };
  };

  return (
    <FAShell
      active="staff"
      title="직원 관리"
      breadcrumb="운영 · 직원"
      actions={
        <>
          <Btn kind="outline" size="sm">근무표 내보내기</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>직원 등록</Btn>
        </>
      }
    >
      {/* KPIs */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 18 }}>
        <KPI label="직원" value="24" unit="명"/>
        <KPI label="오늘 근무" value="14" unit="명" delta="주간 11 / 야간 3"/>
        <KPI label="휴가 신청" value="3" unit="건" delta="승인 대기 1" icon={<Ic.alert style={{ color: 'var(--warning)' }}/>}/>
        <KPI label="요양보호사 비율" value="4 : 1" delta="법정 기준 충족" icon={<Ic.check style={{ color: 'var(--green-600)' }}/>}/>
      </div>

      <Card padding={0} style={{ overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div className="h3">근무표 — 5월 4주차</div>
            <div className="cap" style={{ marginTop: 2 }}>5월 25일 ~ 5월 31일</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Btn kind="ghost" size="sm" icon={<Ic.chevL/>}/>
            <Btn kind="outline" size="sm">이번 주</Btn>
            <Btn kind="ghost" size="sm" icon={<Ic.chevR/>}/>
            <div style={{ width: 1, height: 20, background: 'var(--ink-100)', margin: '0 8px' }}/>
            <div style={{ display: 'flex', gap: 12, fontSize: 11, color: 'var(--ink-600)' }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 14, height: 14, background: 'var(--navy-100)', borderRadius: 3 }}/>주간</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 14, height: 14, background: 'var(--ink-800)', borderRadius: 3 }}/>야간</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 14, height: 14, background: 'var(--ink-50)', borderRadius: 3, border: '1px solid var(--ink-100)' }}/>휴무</span>
            </div>
          </div>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: 'var(--bg-sunken)' }}>
              <th style={{ padding: '12px 16px', textAlign: 'left', width: 220, fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>직원</th>
              {days.map((d, i) => (
                <th key={d} style={{ padding: '10px 0', textAlign: 'center', fontSize: 11, fontWeight: 700, color: i === 3 ? 'var(--navy-700)' : 'var(--ink-500)' }}>
                  <div>{d}</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: i === 3 ? 'var(--navy-700)' : 'var(--ink-900)', marginTop: 2 }}>{dates[i]}</div>
                </th>
              ))}
              <th style={{ padding: '10px 16px', textAlign: 'center', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>합계</th>
            </tr>
          </thead>
          <tbody>
            {staff.map((s, i) => {
              const total = s.shifts.filter(x => x !== '-').length;
              return (
                <tr key={i} style={{ borderTop: '1px solid var(--ink-100)' }}>
                  <td style={{ padding: '10px 16px' }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                      <Avatar name={s.n[0]} tone={s.tone} size={32}/>
                      <div>
                        <div style={{ fontWeight: 600 }}>{s.n}</div>
                        <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>{s.role}</div>
                      </div>
                    </div>
                  </td>
                  {s.shifts.map((sh, j) => {
                    const st = shiftStyle(sh);
                    return (
                      <td key={j} style={{ padding: '6px 4px' }}>
                        <div style={{ background: st.bg, color: st.fg, borderRadius: 6, padding: '8px 0', textAlign: 'center', fontSize: 11, fontWeight: 700 }}>{st.l}</div>
                      </td>
                    );
                  })}
                  <td style={{ padding: '10px 16px', textAlign: 'center', fontWeight: 700 }} className="num">{total}일</td>
                </tr>
              );
            })}
          </tbody>
        </table>
      </Card>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-7. 시설 콘텐츠 관리
// ═══════════════════════════════════════════════════════════════════════
function FAContent() {
  return (
    <FAShell
      active="content"
      title="시설 콘텐츠 관리"
      breadcrumb="시설 · 콘텐츠"
      actions={
        <>
          <Btn kind="outline" size="sm">미리보기</Btn>
          <Btn kind="primary" size="sm">저장 및 게시</Btn>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: '220px 1fr 360px', gap: 14, height: '100%' }}>
        {/* sub-nav */}
        <Card padding={10}>
          {[
            { l: '기본 정보', on: true },
            { l: '시설 사진' },
            { l: '운영 프로그램' },
            { l: '주간 식단' },
            { l: '공지사항' }
          ].map((m, i) => (
            <div key={i} style={{
              padding: '10px 12px', borderRadius: 8,
              background: m.on ? 'var(--navy-50)' : 'transparent',
              color: m.on ? 'var(--navy-800)' : 'var(--ink-700)',
              fontSize: 13, fontWeight: m.on ? 700 : 500,
              display: 'flex', alignItems: 'center', justifyContent: 'space-between'
            }}>
              {m.l}
              {m.on && <Ic.chevR style={{ width: 14, height: 14 }}/>}
            </div>
          ))}
        </Card>

        {/* Form */}
        <Card padding={24} style={{ overflow: 'hidden' }}>
          <div className="h3" style={{ marginBottom: 4 }}>시설 기본 정보</div>
          <div className="cap" style={{ marginBottom: 20 }}>플랫폼 시설 상세 페이지에 노출되는 정보입니다.</div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 16 }}>
            <div>
              <div className="label" style={{ marginBottom: 6 }}>시설명</div>
              <div style={{ padding: '11px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 8, fontSize: 14, fontWeight: 500 }}>햇살요양원</div>
            </div>

            <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 12 }}>
              <div>
                <div className="label" style={{ marginBottom: 6 }}>유형</div>
                <div style={{ padding: '11px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 8, fontSize: 14, display: 'flex', justifyContent: 'space-between' }}>노인요양시설<Ic.chevD style={{ color: 'var(--ink-500)' }}/></div>
              </div>
              <div>
                <div className="label" style={{ marginBottom: 6 }}>정원</div>
                <div style={{ padding: '11px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 8, fontSize: 14 }}>48명</div>
              </div>
            </div>

            <div>
              <div className="label" style={{ marginBottom: 6 }}>주소</div>
              <div style={{ padding: '11px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 8, fontSize: 14 }}>서울특별시 강남구 역삼동 123-45</div>
            </div>

            <div>
              <div className="label" style={{ marginBottom: 6 }}>시설 소개</div>
              <div style={{ padding: '14px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 8, fontSize: 14, color: 'var(--ink-700)', lineHeight: 1.6, minHeight: 120 }}>
                햇살요양원은 2018년 개원 이래, 어르신 한 분 한 분의 존엄한 일상을 지키는 것을 가장 우선하는 가치로 삼아왔습니다. 24시간 상주 의료 인력과 4:1 보호사 비율로 안정적인 케어 환경을 제공하며, 인지 강화·원예·음악 치료 등 일상 회복 프로그램을 운영합니다.
                <div style={{ marginTop: 8, fontSize: 12, color: 'var(--ink-400)' }}>248 / 1000자</div>
              </div>
            </div>

            <div>
              <div className="label" style={{ marginBottom: 6 }}>제공 서비스</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6 }}>
                {[
                  { l: '치매 전담', on: true },
                  { l: '재활 프로그램', on: true },
                  { l: '24시간 의료진', on: true },
                  { l: '여성 전용동', on: true },
                  { l: '독립 화장실', on: true },
                  { l: '중증 환자', on: false },
                  { l: '호스피스', on: false }
                ].map(s => (
                  <div key={s.l} style={{ padding: '6px 12px', borderRadius: 'var(--r-pill)', fontSize: 12, fontWeight: 600, background: s.on ? 'var(--navy-700)' : '#fff', color: s.on ? '#fff' : 'var(--ink-500)', border: s.on ? 'none' : '1px solid var(--ink-200)' }}>
                    {s.on && '✓ '}{s.l}
                  </div>
                ))}
              </div>
            </div>
          </div>
        </Card>

        {/* Preview */}
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div style={{ padding: '14px 16px', background: 'var(--bg-sunken)', borderBottom: '1px solid var(--ink-100)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div style={{ fontSize: 12, fontWeight: 700 }}>실시간 미리보기</div>
            <Tag tone="green" size="sm" dot>저장됨</Tag>
          </div>
          <div style={{ padding: 16 }}>
            <Photo tone="navy" ratio="16/10" style={{ marginBottom: 12 }}/>
            <div style={{ display: 'flex', gap: 4, marginBottom: 6 }}>
              <Tag tone="green" size="sm" dot>공실 2</Tag>
              <Tag tone="navy" size="sm">치매 전담</Tag>
            </div>
            <div style={{ fontSize: 16, fontWeight: 700 }}>햇살요양원</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 4, marginTop: 4 }}>
              <Stars value={4.7} size={11}/>
              <span style={{ fontSize: 11, fontWeight: 600 }}>4.7</span>
              <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>(124)</span>
            </div>
            <div style={{ fontSize: 11, color: 'var(--ink-600)', marginTop: 8, lineHeight: 1.5 }}>
              햇살요양원은 2018년 개원 이래, 어르신 한 분 한 분의 존엄한 일상을 지키는 것을…
            </div>
            <div style={{ marginTop: 12, padding: '10px 12px', background: 'var(--bg-sunken)', borderRadius: 8, display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ fontSize: 11, color: 'var(--ink-500)' }}>월 비용</span>
              <span style={{ fontSize: 14, fontWeight: 700, color: 'var(--navy-700)' }}>218만원~</span>
            </div>
          </div>
        </Card>
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-8. 정산 관리
// ═══════════════════════════════════════════════════════════════════════
function FABilling() {
  return (
    <FAShell
      active="billing"
      title="정산 관리"
      breadcrumb="시설 · 정산"
      actions={
        <>
          <Btn kind="outline" size="sm" icon={<Ic.download/>}>정산서 다운로드</Btn>
          <Btn kind="primary" size="sm">5월 정산 확정</Btn>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 18 }}>
        <KPI label="5월 청구액" value="9,840" unit="만원" delta="46명 · 평균 213만"/>
        <KPI label="수금 완료" value="9,184" unit="만원" delta="93.3% 수금"/>
        <KPI label="미납" value="2" unit="건" delta="656만원" icon={<Ic.alert style={{ color: 'var(--warning)' }}/>}/>
        <KPI label="플랫폼 수수료" value="-98" unit="만원" delta="1% (입소 5건)"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 14, height: 'calc(100% - 130px)' }}>
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <div>
              <div className="h3">월별 청구 내역</div>
              <div className="cap" style={{ marginTop: 2 }}>2026년 5월 · 46명</div>
            </div>
            <div style={{ display: 'flex', gap: 6 }}>
              <Tag tone="navy" size="md">전체 46</Tag>
              <Tag tone="warn" size="md">미납 2</Tag>
              <Tag tone="success" size="md">완료 44</Tag>
            </div>
          </div>
          <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
            <thead>
              <tr style={{ background: 'var(--bg-sunken)' }}>
                {['입소자','보호자','시설료','간병·식비','감액','청구액','상태','결제일'].map(h => (
                  <th key={h} style={{ padding: '11px 14px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {[
                { n: '박정호', g: '박소영', f: 1650, c: 600, d: 98, t: 2152, s: '완료', sTone: 'success', date: '5/5' },
                { n: '김순례', g: '김민준', f: 1500, c: 580, d: 78, t: 2002, s: '완료', sTone: 'success', date: '5/5' },
                { n: '이갑수', g: '이지원', f: 1650, c: 620, d: 98, t: 2172, s: '미납', sTone: 'warn', date: '5/15 ⓘ' },
                { n: '최정심', g: '최우식', f: 1500, c: 540, d: 65, t: 1975, s: '완료', sTone: 'success', date: '5/5' },
                { n: '윤덕봉', g: '윤은혜', f: 1800, c: 720, d: 112, t: 2408, s: '완료', sTone: 'success', date: '5/5' },
                { n: '한금자', g: '한도윤', f: 1650, c: 580, d: 88, t: 2142, s: '예정', sTone: 'info', date: '6/5' },
                { n: '강명환', g: '강민서', f: 1650, c: 600, d: 78, t: 2172, s: '미납', sTone: 'warn', date: '5/15 ⓘ' },
                { n: '서영자', g: '서지호', f: 1500, c: 560, d: 76, t: 1984, s: '완료', sTone: 'success', date: '5/5' }
              ].map((r, i, a) => (
                <tr key={i} style={{ borderTop: '1px solid var(--ink-100)' }}>
                  <td style={{ padding: '11px 14px', fontWeight: 600 }}>{r.n}</td>
                  <td style={{ padding: '11px 14px', color: 'var(--ink-700)' }}>{r.g}</td>
                  <td style={{ padding: '11px 14px', color: 'var(--ink-800)' }} className="num">{r.f.toLocaleString()},000</td>
                  <td style={{ padding: '11px 14px', color: 'var(--ink-800)' }} className="num">{r.c.toLocaleString()},000</td>
                  <td style={{ padding: '11px 14px', color: 'var(--green-700)' }} className="num">-{r.d},000</td>
                  <td style={{ padding: '11px 14px', fontWeight: 700 }} className="num">{r.t.toLocaleString()},000</td>
                  <td style={{ padding: '11px 14px' }}><Tag tone={r.sTone} size="sm">{r.s}</Tag></td>
                  <td style={{ padding: '11px 14px', color: 'var(--ink-700)' }} className="num">{r.date}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </Card>

        {/* Side: settlement */}
        <Card padding={20}>
          <div className="h3" style={{ marginBottom: 14 }}>5월 정산 요약</div>
          <div style={{ background: 'linear-gradient(135deg, var(--navy-800), var(--navy-700))', borderRadius: 12, padding: 18, color: '#fff', marginBottom: 16 }}>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)' }}>이번 달 정산 예정액</div>
            <div className="num" style={{ fontSize: 28, fontWeight: 700, marginTop: 4 }}>9,086<span style={{ fontSize: 14, marginLeft: 4, color: 'rgba(255,255,255,0.7)' }}>만원</span></div>
            <div style={{ fontSize: 11, color: 'rgba(255,255,255,0.7)', marginTop: 6 }}>6월 10일 정산 입금</div>
          </div>

          <div style={{ display: 'flex', flexDirection: 'column', gap: 10, fontSize: 13 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--ink-700)' }}>총 청구액</span>
              <span className="num" style={{ fontWeight: 600 }}>98,400,000원</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--ink-700)' }}>수금 완료</span>
              <span className="num" style={{ fontWeight: 600, color: 'var(--green-700)' }}>+91,840,000원</span>
            </div>
            <div style={{ display: 'flex', justifyContent: 'space-between' }}>
              <span style={{ color: 'var(--ink-700)' }}>플랫폼 수수료</span>
              <span className="num" style={{ fontWeight: 600, color: 'var(--danger)' }}>-980,000원</span>
            </div>
            <div style={{ height: 1, background: 'var(--ink-100)', margin: '4px 0' }}/>
            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
              <span style={{ fontSize: 14, fontWeight: 700 }}>정산 금액</span>
              <span className="num" style={{ fontSize: 16, fontWeight: 700, color: 'var(--navy-700)' }}>90,860,000원</span>
            </div>
          </div>

          <div style={{ height: 1, background: 'var(--ink-100)', margin: '16px 0' }}/>

          <div className="label" style={{ marginBottom: 8 }}>미납 처리</div>
          <div style={{ background: 'var(--warning-soft)', borderRadius: 8, padding: 12, fontSize: 12, color: 'var(--warning)' }}>
            <div style={{ fontWeight: 700 }}>2건 미납 — 656만원</div>
            <div style={{ marginTop: 4, color: 'var(--ink-700)' }}>이지원·강민서 보호자에게 안내 발송 필요</div>
          </div>
        </Card>
      </div>
    </FAShell>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// 2-9. 통계
// ═══════════════════════════════════════════════════════════════════════
function FAStats() {
  return (
    <FAShell
      active="stats"
      title="통계 및 분석"
      breadcrumb="시설 · 통계"
      actions={
        <>
          <Btn kind="outline" size="sm">기간 · 최근 6개월 ▾</Btn>
          <Btn kind="outline" size="sm" icon={<Ic.download/>}>리포트</Btn>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 18 }}>
        <KPI label="평균 입소율" value="94.2" unit="%" delta="+2.1%p vs 전반기"/>
        <KPI label="상담 전환율" value="42" unit="%" delta="38건 중 16건 입소"/>
        <KPI label="평균 재실 기간" value="2.4" unit="년" delta="중위 1.8년"/>
        <KPI label="보호자 만족도" value="4.6" unit="/ 5.0" delta="후기 124건"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '2fr 1fr', gap: 14, height: 'calc(100% - 130px)' }}>
        {/* Big chart */}
        <Card padding={24} style={{ display: 'flex', flexDirection: 'column' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 16 }}>
            <div>
              <div className="h3">입소율 · 공실률 추이</div>
              <div className="cap" style={{ marginTop: 2 }}>최근 6개월</div>
            </div>
            <div style={{ display: 'flex', gap: 14, fontSize: 12 }}>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 14, height: 3, background: 'var(--navy-700)', borderRadius: 2 }}/>입소율</span>
              <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 14, height: 3, background: 'var(--green-600)', borderRadius: 2 }}/>상담 건수</span>
            </div>
          </div>

          <div style={{ flex: 1, minHeight: 0, position: 'relative', padding: '10px 0' }}>
            <svg width="100%" height="100%" viewBox="0 0 700 280" preserveAspectRatio="none" style={{ overflow: 'visible' }}>
              {/* gridlines */}
              {[0,1,2,3,4].map(i => (
                <g key={i}>
                  <line x1="40" x2="700" y1={50*i + 20} y2={50*i + 20} stroke="var(--ink-100)" strokeWidth="1"/>
                  <text x="0" y={50*i + 24} fontSize="11" fill="var(--ink-400)">{100 - i*10}%</text>
                </g>
              ))}
              {/* fill */}
              <path d="M 60 80 L 180 65 L 300 50 L 420 35 L 540 45 L 660 25 L 660 220 L 60 220 Z" fill="var(--navy-700)" opacity="0.08"/>
              {/* line */}
              <polyline points="60,80 180,65 300,50 420,35 540,45 660,25" fill="none" stroke="var(--navy-700)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              {[60,180,300,420,540,660].map((x, i) => (
                <circle key={i} cx={x} cy={[80,65,50,35,45,25][i]} r="4" fill="#fff" stroke="var(--navy-700)" strokeWidth="2"/>
              ))}
              {/* green line */}
              <polyline points="60,170 180,150 300,140 420,160 540,130 660,110" fill="none" stroke="var(--green-600)" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
              {[60,180,300,420,540,660].map((x, i) => (
                <circle key={i} cx={x} cy={[170,150,140,160,130,110][i]} r="4" fill="#fff" stroke="var(--green-600)" strokeWidth="2"/>
              ))}
              {['12월','1월','2월','3월','4월','5월'].map((m, i) => (
                <text key={m} x={60 + i*120} y="260" fontSize="11" textAnchor="middle" fill="var(--ink-500)" fontWeight="500">{m}</text>
              ))}
            </svg>
          </div>
        </Card>

        {/* Right column */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          {/* Conversion funnel */}
          <Card padding={20}>
            <div className="h3" style={{ marginBottom: 14 }}>상담 전환 퍼널</div>
            {[
              { l: '문의', v: 38, p: 100, c: 'var(--navy-400)' },
              { l: '상담', v: 28, p: 74, c: 'var(--navy-600)' },
              { l: '방문', v: 22, p: 58, c: 'var(--navy-700)' },
              { l: '계약', v: 18, p: 47, c: 'var(--green-600)' },
              { l: '입소', v: 16, p: 42, c: 'var(--green-700)' }
            ].map((f, i) => (
              <div key={i} style={{ marginBottom: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 5, fontSize: 12 }}>
                  <span style={{ color: 'var(--ink-700)', fontWeight: 600 }}>{f.l}</span>
                  <span><b className="num">{f.v}</b><span style={{ color: 'var(--ink-500)', marginLeft: 6 }}>{f.p}%</span></span>
                </div>
                <div style={{ height: 8, background: 'var(--ink-100)', borderRadius: 4, overflow: 'hidden' }}>
                  <div style={{ height: '100%', width: `${f.p}%`, background: f.c, borderRadius: 4 }}/>
                </div>
              </div>
            ))}
          </Card>

          {/* Resident composition */}
          <Card padding={20} style={{ flex: 1 }}>
            <div className="h3" style={{ marginBottom: 14 }}>입소자 구성</div>
            <div style={{ display: 'flex', alignItems: 'center', gap: 16 }}>
              <Donut percent={65} size={88} stroke={14} color="var(--navy-700)" track="var(--green-300)" label="46"/>
              <div style={{ flex: 1, fontSize: 12 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 10, height: 10, background: 'var(--navy-700)', borderRadius: 2 }}/>1·2등급</span>
                  <span style={{ fontWeight: 600 }}>30명 · 65%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8 }}>
                  <span style={{ display: 'inline-flex', alignItems: 'center', gap: 6 }}><span style={{ width: 10, height: 10, background: 'var(--green-300)', borderRadius: 2 }}/>3·4·5등급</span>
                  <span style={{ fontWeight: 600 }}>16명 · 35%</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: 8, color: 'var(--ink-700)' }}>
                  <span>치매 진단</span>
                  <span style={{ fontWeight: 600 }}>18명</span>
                </div>
                <div style={{ display: 'flex', justifyContent: 'space-between', color: 'var(--ink-700)' }}>
                  <span>평균 연령</span>
                  <span style={{ fontWeight: 600 }}>78.4세</span>
                </div>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </FAShell>
  );
}

Object.assign(window, {
  D_W, D_H, FAShell, FASidebar, FATopbar,
  FADashboard, FARooms, FACRM, FAResidents, FAGuardians, FAStaff, FAContent, FABilling, FAStats
});
