// other-portals.jsx — 병원/사회복지사, 케어 코디네이터, 플랫폼 관리자 (11 화면)

// ─── Reusable mini-shell for other portals ──────────────────────────────
function PortalShell({ brand, brandColor, role, active, navItems, title, breadcrumb, actions, children }) {
  return (
    <div style={{ width: D_W, height: D_H, background: 'var(--bg-app)', display: 'flex', overflow: 'hidden', fontFamily: 'var(--font-sans)' }}>
      {/* sidebar */}
      <div style={{ width: 224, height: '100%', background: '#fff', borderRight: '1px solid var(--ink-100)', display: 'flex', flexDirection: 'column', flexShrink: 0 }}>
        <div style={{ padding: '22px 20px 18px', borderBottom: '1px solid var(--ink-100)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <div style={{ width: 30, height: 30, borderRadius: 8, background: brandColor, color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 13 }}>{brand[0]}</div>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700 }}>{brand}</div>
              <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>{role}</div>
            </div>
          </div>
        </div>
        <div style={{ flex: 1, padding: '14px 10px' }}>
          {navItems.map(it => {
            const Icon = it.icon;
            const on = it.id === active;
            return (
              <div key={it.id} style={{
                display: 'flex', alignItems: 'center', gap: 10,
                padding: '10px 12px', borderRadius: 8,
                background: on ? 'var(--navy-50)' : 'transparent',
                color: on ? 'var(--navy-800)' : 'var(--ink-700)',
                fontSize: 13, fontWeight: on ? 700 : 500, marginBottom: 2
              }}>
                <Icon style={{ width: 16, height: 16 }}/>
                <span style={{ flex: 1 }}>{it.t}</span>
                {it.badge && <Tag tone={on ? 'navy' : 'neutral'} size="sm">{it.badge}</Tag>}
              </div>
            );
          })}
        </div>
        <div style={{ padding: 14, borderTop: '1px solid var(--ink-100)' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
            <Avatar name="홍" size={28} tone="navy"/>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 12, fontWeight: 600 }}>홍은영</div>
              <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>{role}</div>
            </div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
        <div style={{ padding: '20px 32px 18px', background: '#fff', borderBottom: '1px solid var(--ink-100)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            {breadcrumb && <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 500, marginBottom: 4 }}>{breadcrumb}</div>}
            <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.018em' }}>{title}</div>
          </div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            {actions}
          </div>
        </div>
        <div style={{ flex: 1, padding: '24px 32px', overflow: 'hidden' }}>{children}</div>
      </div>
    </div>
  );
}

// ════════════════════════════════════════════════════════════════════════
// 3. 병원 / 사회복지사 포털
// ════════════════════════════════════════════════════════════════════════
const HOSPITAL_NAV = [
  { id: 'register', t: '환자 등록', icon: Ic.user, badge: '4' },
  { id: 'recommend', t: '시설 추천', icon: Ic.building },
  { id: 'link', t: '연계 관리', icon: Ic.send }
];

// ── 3-1. 환자 등록 ─────────────────────────────────────────────────────
function HospitalRegister() {
  return (
    <PortalShell
      brand="복지 연계" brandColor="linear-gradient(135deg, #2A6FA8, #1B7654)" role="강남세브란스 · 사회복지팀"
      active="register" navItems={HOSPITAL_NAV}
      title="환자 등록 — 시설 연계 요청"
      breadcrumb="병원 포털 · 환자"
      actions={
        <>
          <Btn kind="outline" size="sm">임시 저장</Btn>
          <Btn kind="primary" size="sm">시설 추천 받기</Btn>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 16, height: '100%' }}>
        <Card padding={28} style={{ overflow: 'hidden' }}>
          {/* Stepper */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 0, marginBottom: 24 }}>
            {[
              { n: 1, l: '환자 정보', on: true, done: true },
              { n: 2, l: '건강 상태', on: true, done: false, active: true },
              { n: 3, l: '희망 조건', on: false },
              { n: 4, l: '확인' }
            ].map((s, i, a) => (
              <React.Fragment key={s.n}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
                  <div style={{
                    width: 28, height: 28, borderRadius: '50%',
                    background: s.done ? 'var(--green-700)' : s.active ? 'var(--navy-700)' : 'var(--ink-100)',
                    color: s.done || s.active ? '#fff' : 'var(--ink-500)',
                    display: 'flex', alignItems: 'center', justifyContent: 'center',
                    fontSize: 12, fontWeight: 700
                  }}>
                    {s.done ? <Ic.check style={{ width: 14, height: 14 }}/> : s.n}
                  </div>
                  <div style={{ fontSize: 13, fontWeight: s.active ? 700 : 500, color: s.active ? 'var(--ink-900)' : 'var(--ink-500)' }}>{s.l}</div>
                </div>
                {i < a.length - 1 && <div style={{ flex: 1, height: 2, background: s.done ? 'var(--green-700)' : 'var(--ink-100)', margin: '0 14px' }}/>}
              </React.Fragment>
            ))}
          </div>

          <div className="h3" style={{ marginBottom: 4 }}>건강 상태 입력</div>
          <div className="cap" style={{ marginBottom: 20 }}>환자의 현재 의료 상태를 정확히 입력해주세요. AI 추천에 활용됩니다.</div>

          {/* Form */}
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 16 }}>
            <div>
              <div className="label" style={{ marginBottom: 6 }}>장기요양등급</div>
              <div style={{ display: 'flex', gap: 4 }}>
                {['1등급','2등급','3등급','4등급','5등급','없음'].map((g, i) => (
                  <div key={g} style={{
                    flex: 1, padding: '10px 0', textAlign: 'center',
                    background: i === 1 ? 'var(--navy-700)' : '#fff',
                    color: i === 1 ? '#fff' : 'var(--ink-700)',
                    border: i === 1 ? 'none' : '1px solid var(--ink-200)',
                    borderRadius: 6, fontSize: 12, fontWeight: 600
                  }}>{g}</div>
                ))}
              </div>
            </div>

            <div>
              <div className="label" style={{ marginBottom: 6 }}>치매 여부</div>
              <div style={{ display: 'flex', gap: 4 }}>
                {['없음','초기','중기','후기'].map((g, i) => (
                  <div key={g} style={{
                    flex: 1, padding: '10px 0', textAlign: 'center',
                    background: i === 2 ? 'var(--navy-700)' : '#fff',
                    color: i === 2 ? '#fff' : 'var(--ink-700)',
                    border: i === 2 ? 'none' : '1px solid var(--ink-200)',
                    borderRadius: 6, fontSize: 12, fontWeight: 600
                  }}>{g}</div>
                ))}
              </div>
            </div>

            <div>
              <div className="label" style={{ marginBottom: 6 }}>거동</div>
              <div style={{ display: 'flex', gap: 4 }}>
                {['자립','부축','휠체어','와상'].map((g, i) => (
                  <div key={g} style={{
                    flex: 1, padding: '10px 0', textAlign: 'center',
                    background: i === 2 ? 'var(--navy-700)' : '#fff',
                    color: i === 2 ? '#fff' : 'var(--ink-700)',
                    border: i === 2 ? 'none' : '1px solid var(--ink-200)',
                    borderRadius: 6, fontSize: 12, fontWeight: 600
                  }}>{g}</div>
                ))}
              </div>
            </div>

            <div>
              <div className="label" style={{ marginBottom: 6 }}>의식 수준</div>
              <div style={{ padding: '10px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 6, fontSize: 13, display: 'flex', justifyContent: 'space-between' }}>
                명료 (Alert) <Ic.chevD style={{ color: 'var(--ink-500)' }}/>
              </div>
            </div>

            <div style={{ gridColumn: 'span 2' }}>
              <div className="label" style={{ marginBottom: 6 }}>기저 질환 / 진단명</div>
              <div style={{ display: 'flex', flexWrap: 'wrap', gap: 6, padding: 8, background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 6, minHeight: 60 }}>
                <Tag tone="navy" size="md">고혈압 ✕</Tag>
                <Tag tone="navy" size="md">당뇨 ✕</Tag>
                <Tag tone="navy" size="md">뇌졸중 후유증 ✕</Tag>
                <Tag tone="navy" size="md">치매 (혈관성) ✕</Tag>
                <span style={{ fontSize: 12, color: 'var(--ink-400)', padding: '3px 6px' }}>+ 추가</span>
              </div>
            </div>

            <div style={{ gridColumn: 'span 2' }}>
              <div className="label" style={{ marginBottom: 6 }}>특이사항</div>
              <div style={{ padding: '12px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 6, fontSize: 13, color: 'var(--ink-700)', lineHeight: 1.6, minHeight: 90 }}>
                급성기 치료 종료 후 회복 단계. 식사 시 가벼운 부축 필요, 야간 배회 증상 관찰됨. 가족과 떨어져 지내는 것에 불안감을 호소하므로 적응 기간 동안 가족 면회가 비교적 자유로운 시설을 선호합니다.
              </div>
            </div>
          </div>
        </Card>

        {/* Side */}
        <Card padding={20}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <Avatar name="박" tone="warm" size={48}/>
            <div>
              <div className="h3">박정자 환자</div>
              <div className="cap">F · 1953년생 (72세) · 본원 입원중</div>
            </div>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8, marginBottom: 16 }}>
            <div style={{ padding: 10, background: 'var(--bg-sunken)', borderRadius: 8 }}>
              <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>입원실</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>본관 7-12</div>
            </div>
            <div style={{ padding: 10, background: 'var(--bg-sunken)', borderRadius: 8 }}>
              <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>퇴원 예정</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>2026.06.10</div>
            </div>
            <div style={{ padding: 10, background: 'var(--bg-sunken)', borderRadius: 8 }}>
              <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>주치의</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>신경과 윤민호</div>
            </div>
            <div style={{ padding: 10, background: 'var(--bg-sunken)', borderRadius: 8 }}>
              <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>보호자</div>
              <div style={{ fontSize: 13, fontWeight: 700, marginTop: 2 }}>박지영 (딸)</div>
            </div>
          </div>

          <div className="label" style={{ marginBottom: 8 }}>입력 진행률</div>
          <div style={{ height: 8, background: 'var(--ink-100)', borderRadius: 4, overflow: 'hidden', marginBottom: 6 }}>
            <div style={{ height: '100%', width: '60%', background: 'linear-gradient(90deg, var(--navy-700), var(--green-600))' }}/>
          </div>
          <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>15 / 24 항목 입력됨</div>

          <div style={{ height: 1, background: 'var(--ink-100)', margin: '16px 0' }}/>

          <div className="label" style={{ marginBottom: 8 }}>안내</div>
          <div style={{ fontSize: 12, color: 'var(--ink-600)', lineHeight: 1.6 }}>
            건강 상태가 정확할수록 AI 매칭 정확도가 높아집니다. 정보는 환자/보호자 동의 하에 시설에 공유됩니다.
          </div>
        </Card>
      </div>
    </PortalShell>
  );
}

// ── 3-2. 시설 추천 (AI matching) ────────────────────────────────────────
function HospitalRecommend() {
  return (
    <PortalShell
      brand="복지 연계" brandColor="linear-gradient(135deg, #2A6FA8, #1B7654)" role="강남세브란스 · 사회복지팀"
      active="recommend" navItems={HOSPITAL_NAV}
      title="AI 시설 추천"
      breadcrumb="병원 포털 · 박정자 환자"
      actions={
        <>
          <Btn kind="outline" size="sm" icon={<Ic.filter/>}>조건 비교</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.send/>}>3개 시설에 연계 요청</Btn>
        </>
      }
    >
      {/* AI banner */}
      <Card padding={18} style={{ marginBottom: 16, background: 'linear-gradient(135deg, #07172A 0%, #133355 100%)', color: '#fff', border: 'none', display: 'flex', alignItems: 'center', gap: 16 }}>
        <div style={{ width: 44, height: 44, borderRadius: 12, background: 'linear-gradient(135deg, var(--green-500), var(--navy-400))', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
          <Ic.sparkle style={{ width: 22, height: 22 }}/>
        </div>
        <div style={{ flex: 1 }}>
          <div style={{ fontSize: 15, fontWeight: 700 }}>박정자 환자에게 적합한 시설 12곳을 찾았습니다</div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginTop: 4 }}>치매 중기 · 부축 거동 · 강남 인근 · 본인부담 250만원 이하 · 즉시 입소 가능 기준</div>
        </div>
        <div style={{ display: 'flex', gap: 6 }}>
          <Tag tone="outline" size="md" style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', borderColor: 'rgba(255,255,255,0.2)' }}>거리순</Tag>
          <Tag tone="outline" size="md" style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', borderColor: 'rgba(255,255,255,0.2)' }}>가격순</Tag>
          <Tag tone="outline" size="md" style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', borderColor: 'rgba(255,255,255,0.2)' }}>매칭 점수</Tag>
        </div>
      </Card>

      {/* Recommended facilities */}
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 14 }}>
        {[
          { n: '햇살요양원', tone: 'navy', dist: '2.3km', rooms: 2, score: 96, price: '218만', match: ['치매 전담','여성동','즉시 입소'], sel: true, rate: 4.7 },
          { n: '늘봄케어센터', tone: 'green', dist: '3.1km', rooms: 1, score: 92, price: '225만', match: ['재활 특화','24h 의료'], sel: true, rate: 4.5 },
          { n: '평안의 집', tone: 'sand', dist: '4.8km', rooms: 3, score: 89, price: '198만', match: ['저렴','정원 60명'], sel: true, rate: 4.6 }
        ].map((f, i) => (
          <Card key={i} padding={0} style={{ overflow: 'hidden', border: f.sel ? '2px solid var(--navy-700)' : '1px solid var(--ink-100)', position: 'relative' }}>
            {f.sel && <div style={{ position: 'absolute', top: 12, right: 12, background: 'var(--navy-700)', color: '#fff', width: 24, height: 24, borderRadius: '50%', display: 'flex', alignItems: 'center', justifyContent: 'center', zIndex: 1 }}><Ic.check style={{ width: 14, height: 14 }}/></div>}
            <Photo tone={f.tone} ratio="16/9">
              <div style={{ position: 'absolute', top: 12, left: 12, background: 'rgba(0,0,0,0.6)', color: '#fff', padding: '4px 10px', borderRadius: 'var(--r-pill)', fontSize: 11, fontWeight: 700, backdropFilter: 'blur(8px)' }}>매칭 {f.score}%</div>
            </Photo>
            <div style={{ padding: 16 }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                <div style={{ fontSize: 15, fontWeight: 700 }}>{f.n}</div>
                <Tag tone="green" size="sm" dot>공실 {f.rooms}</Tag>
              </div>
              <div style={{ display: 'flex', alignItems: 'center', gap: 6, marginTop: 6, fontSize: 12, color: 'var(--ink-500)' }}>
                <Stars value={f.rate} size={12}/>
                <span style={{ fontWeight: 600, color: 'var(--ink-900)' }}>{f.rate}</span>
                <span>·</span>
                <span>{f.dist}</span>
              </div>
              <div style={{ display: 'flex', gap: 4, marginTop: 10, flexWrap: 'wrap' }}>
                {f.match.map(m => <Tag key={m} tone="navy" size="sm">{m}</Tag>)}
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 14, paddingTop: 12, borderTop: '1px solid var(--ink-100)' }}>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>월 본인부담</div>
                  <div style={{ fontSize: 16, fontWeight: 700, color: 'var(--navy-700)' }}>{f.price}원</div>
                </div>
                <Btn kind="outline" size="sm">상세 →</Btn>
              </div>
            </div>
          </Card>
        ))}
      </div>

      {/* Compare table */}
      <Card padding={20} style={{ overflow: 'hidden' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
          <div className="h3">선택한 3개 시설 비교</div>
          <Btn kind="ghost" size="sm">전체 12개 보기 →</Btn>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <tbody>
            {[
              { l: '월 본인부담', v: ['218만원','225만원','198만원'] },
              { l: '치매 전담동', v: ['있음','없음','있음'] },
              { l: '간호인력', v: ['24h 상주','24h 상주','주간 상주'] },
              { l: '거리', v: ['2.3km','3.1km','4.8km'] },
              { l: '가족 면회', v: ['상시','예약','주 3회'] }
            ].map((r, i) => (
              <tr key={i} style={{ borderTop: '1px solid var(--ink-100)' }}>
                <td style={{ padding: '10px 0', color: 'var(--ink-500)', width: 140, fontSize: 12, fontWeight: 600 }}>{r.l}</td>
                {r.v.map((v, j) => (
                  <td key={j} style={{ padding: '10px 12px', fontSize: 13, fontWeight: 600 }}>{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </PortalShell>
  );
}

// ── 3-3. 연계 관리 ─────────────────────────────────────────────────────
function HospitalLink() {
  return (
    <PortalShell
      brand="복지 연계" brandColor="linear-gradient(135deg, #2A6FA8, #1B7654)" role="강남세브란스 · 사회복지팀"
      active="link" navItems={HOSPITAL_NAV}
      title="연계 관리"
      breadcrumb="병원 포털 · 진행 중인 연계"
      actions={<Btn kind="primary" size="sm" icon={<Ic.plus/>}>신규 연계</Btn>}
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="이번 분기 연계" value="42" unit="건" delta="작년 대비 +28%"/>
        <KPI label="입소 성공" value="34" unit="건" delta="성공률 81%"/>
        <KPI label="진행 중" value="6" unit="건" delta="평균 12일 소요"/>
        <KPI label="평균 대기" value="4.2" unit="일" delta="응답까지"/>
      </div>

      <Card padding={0} style={{ overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)', display: 'flex', alignItems: 'center', gap: 10 }}>
          <div className="h3">진행 중인 연계</div>
          <Tag tone="navy" size="md">6건</Tag>
          <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
            <Tag tone="outline" size="md">전체</Tag>
            <Tag tone="warn" size="md">응답 대기</Tag>
            <Tag tone="success" size="md">방문 예정</Tag>
          </div>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: 'var(--bg-sunken)' }}>
              {['환자','연계 시설','담당자','상태','진행 단계','다음 일정',''].map(h => (
                <th key={h} style={{ padding: '11px 18px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              { p: '박정자', age: 72, pt: 'warm', f: '햇살요양원', s: '햇살 김지원', st: '방문 예정', stTone: 'success', step: 75, sd: '5/30 14:00' },
              { p: '이상기', age: 76, pt: 'navy', f: '늘봄케어센터', s: '늘봄 정수정', st: '응답 대기', stTone: 'warn', step: 25, sd: '응답 대기 2일' },
              { p: '김순옥', age: 81, pt: 'green', f: '평안의 집', s: '평안 한미경', st: '서류 검토', stTone: 'info', step: 50, sd: '서류 5/29' },
              { p: '최영래', age: 78, pt: 'plum', f: '햇살요양원', s: '햇살 김지원', st: '계약 진행', stTone: 'navy', step: 90, sd: '계약 6/2' },
              { p: '한금희', age: 74, pt: 'warm', f: '드림케어', s: '드림 박상우', st: '응답 대기', stTone: 'warn', step: 15, sd: '응답 대기 1일' },
              { p: '강덕재', age: 83, pt: 'navy', f: '편안의 집', s: '편안 윤지혜', st: '입소 완료', stTone: 'success', step: 100, sd: '5/25 완료' }
            ].map((r, i, a) => (
              <tr key={i} style={{ borderTop: '1px solid var(--ink-100)' }}>
                <td style={{ padding: '13px 18px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <Avatar name={r.p[0]} tone={r.pt} size={32}/>
                    <div>
                      <div style={{ fontWeight: 600 }}>{r.p}</div>
                      <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>{r.age}세</div>
                    </div>
                  </div>
                </td>
                <td style={{ padding: '13px 18px', fontWeight: 600 }}>{r.f}</td>
                <td style={{ padding: '13px 18px', color: 'var(--ink-700)' }}>{r.s}</td>
                <td style={{ padding: '13px 18px' }}><Tag tone={r.stTone} size="sm" dot>{r.st}</Tag></td>
                <td style={{ padding: '13px 18px' }}>
                  <div style={{ width: 110, height: 5, background: 'var(--ink-100)', borderRadius: 3 }}>
                    <div style={{ width: `${r.step}%`, height: '100%', background: r.step === 100 ? 'var(--green-700)' : 'var(--navy-700)', borderRadius: 3 }}/>
                  </div>
                  <div style={{ fontSize: 10, color: 'var(--ink-500)', marginTop: 4 }}>{r.step}%</div>
                </td>
                <td style={{ padding: '13px 18px', color: 'var(--ink-700)' }}>{r.sd}</td>
                <td style={{ padding: '13px 18px' }}><Ic.chevR style={{ color: 'var(--ink-400)' }}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </PortalShell>
  );
}

// ════════════════════════════════════════════════════════════════════════
// 4. 케어 코디네이터 포털
// ════════════════════════════════════════════════════════════════════════
const COORD_NAV = [
  { id: 'caseload', t: '상담 관리', icon: Ic.chat, badge: '12' },
  { id: 'schedule', t: '방문 일정', icon: Ic.clock, badge: '3' },
  { id: 'admission', t: '입소 진행', icon: Ic.doc, badge: '5' }
];

// ── 4-1. 상담 관리 ─────────────────────────────────────────────────────
function CoordCaseload() {
  return (
    <PortalShell
      brand="케어 코디" brandColor="linear-gradient(135deg, #7A4B7A, #1B466F)" role="복지 플랫폼 · 코디네이터"
      active="caseload" navItems={COORD_NAV}
      title="내 상담 케이스"
      breadcrumb="코디네이터 · 케이스 관리"
      actions={
        <>
          <Btn kind="outline" size="sm">전체 보기</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>신규 케이스</Btn>
        </>
      }
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="담당 케이스" value="12" unit="건"/>
        <KPI label="이번 주 방문" value="3" unit="건" delta="동행 1건"/>
        <KPI label="응답 대기" value="2" unit="건" icon={<Ic.alert style={{ color: 'var(--warning)' }}/>}/>
        <KPI label="이번 달 성사" value="6" unit="건" delta="목표 8건"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1fr 360px', gap: 14, height: 'calc(100% - 130px)' }}>
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)', display: 'flex', gap: 10, alignItems: 'center' }}>
            <div className="h3">담당 케이스</div>
            <div style={{ marginLeft: 'auto', display: 'flex', gap: 6 }}>
              {['전체 12','긴급 2','신규 3','진행 5','완료 2'].map((t, i) => (
                <Tag key={i} tone={i === 0 ? 'navy' : 'outline'} size="md">{t}</Tag>
              ))}
            </div>
          </div>

          {[
            { n: '이상미 보호자', p: '이정자(어머니) · 72세', sel: true, last: '15분 전', stage: '시설 추천', stageT: 'navy', tone: 'warm', urgent: true, msg: '치매 의심 / 강남구 / 즉시 입소 희망' },
            { n: '박기수 보호자', p: '박철수(아버지) · 78세', last: '1시간 전', stage: '방문 예정', stageT: 'success', tone: 'navy', msg: '재활 시설 위주 추천 완료, 내일 햇살요양원 동행' },
            { n: '정혜영 보호자', p: '정해진(어머니) · 81세', last: '어제', stage: '계약 진행', stageT: 'green', tone: 'green', msg: '평안의 집과 계약 진행 중, 서류 검토 필요' },
            { n: '한승호 보호자', p: '한금희(어머니) · 75세', last: '2일 전', stage: '신규', stageT: 'info', tone: 'plum', msg: '와상 환자 / 중증 가능 시설 매칭 중' },
            { n: '오현주 보호자', p: '오영자(어머니) · 68세', last: '3일 전', stage: '상담 중', stageT: 'navy', tone: 'warm', msg: '비용 협의 단계, 본인부담 200만원 이하 희망' },
            { n: '강민철 보호자', p: '강덕재(아버지) · 80세', last: '5일 전', stage: '완료', stageT: 'success', tone: 'navy', msg: '편안의 집 입소 5/25 완료' }
          ].map((c, i, a) => (
            <div key={i} style={{
              padding: '14px 20px', display: 'flex', gap: 14, alignItems: 'center',
              borderTop: '1px solid var(--ink-100)',
              background: c.sel ? 'var(--navy-50)' : '#fff'
            }}>
              <Avatar name={c.n[0]} tone={c.tone} size={40}/>
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <div style={{ fontSize: 14, fontWeight: 700 }}>{c.n}</div>
                  {c.urgent && <Tag tone="danger" size="sm">긴급</Tag>}
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>{c.p}</div>
                <div style={{ fontSize: 12, color: 'var(--ink-700)', marginTop: 5 }}>{c.msg}</div>
              </div>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'flex-end', gap: 5 }}>
                <Tag tone={c.stageT} size="sm" dot>{c.stage}</Tag>
                <div style={{ fontSize: 11, color: 'var(--ink-400)' }}>{c.last}</div>
              </div>
            </div>
          ))}
        </Card>

        {/* Detail panel */}
        <Card padding={20} style={{ overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 14 }}>
            <Avatar name="이" tone="warm" size={48}/>
            <div style={{ flex: 1 }}>
              <div className="h3">이상미 보호자</div>
              <div className="cap">이정자 어머니 · 72세 · 2등급</div>
            </div>
            <Tag tone="danger" size="sm">긴급</Tag>
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 8, marginBottom: 14 }}>
            <Btn kind="secondary" size="sm" icon={<Ic.chat/>}>채팅</Btn>
            <Btn kind="primary" size="sm" icon={<Ic.phone/>}>통화</Btn>
          </div>

          <div className="label" style={{ marginBottom: 8 }}>추천한 시설 (3)</div>
          {[
            { n: '햇살요양원', stat: '방문 5/30', tone: 'green' },
            { n: '늘봄케어센터', stat: '답변 대기', tone: 'warn' },
            { n: '평안의 집', stat: '관심 없음', tone: 'neutral' }
          ].map((f, i) => (
            <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '10px 12px', background: 'var(--bg-sunken)', borderRadius: 8, marginBottom: 6 }}>
              <span style={{ fontSize: 13, fontWeight: 600 }}>{f.n}</span>
              <Tag tone={f.tone} size="sm">{f.stat}</Tag>
            </div>
          ))}

          <div style={{ height: 1, background: 'var(--ink-100)', margin: '16px 0' }}/>

          <div className="label" style={{ marginBottom: 8 }}>다음 액션</div>
          <div style={{ padding: 12, background: 'var(--warning-soft)', borderRadius: 8, color: 'var(--warning)' }}>
            <div style={{ fontSize: 12, fontWeight: 700 }}>늘봄케어센터에 재문의</div>
            <div style={{ fontSize: 11, color: 'var(--ink-700)', marginTop: 4 }}>답변 마감 D-1 · 응답 없으면 다른 시설 제안</div>
          </div>
        </Card>
      </div>
    </PortalShell>
  );
}

// ── 4-2. 방문 일정 관리 ────────────────────────────────────────────────
function CoordSchedule() {
  const slots = [
    { d: 0, h: 9, w: 1, t: '햇살요양원 동행', tone: 'navy', who: '이상미 보호자' },
    { d: 0, h: 14, w: 1, t: '늘봄 · 시설 투어', tone: 'green', who: '박기수 보호자' },
    { d: 1, h: 10, w: 2, t: '재상담 · 비용 협의', tone: 'navy', who: '오현주 보호자' },
    { d: 2, h: 11, w: 1, t: '평안 · 계약 서류', tone: 'green', who: '정혜영 보호자' },
    { d: 2, h: 15, w: 2, t: '시설장 미팅 · 햇살', tone: 'plum', who: '내부' },
    { d: 3, h: 9, w: 1, t: '신규 상담', tone: 'warm', who: '한승호 보호자' },
    { d: 3, h: 13, w: 1, t: '재가요양 안내', tone: 'navy', who: '강덕재 보호자' },
    { d: 4, h: 10, w: 2, t: '드림케어 동행', tone: 'green', who: '한금희 보호자' },
    { d: 4, h: 16, w: 1, t: '주간 리뷰', tone: 'plum', who: '팀 회의' }
  ];

  return (
    <PortalShell
      brand="케어 코디" brandColor="linear-gradient(135deg, #7A4B7A, #1B466F)" role="복지 플랫폼 · 코디네이터"
      active="schedule" navItems={COORD_NAV}
      title="방문 일정"
      breadcrumb="코디네이터 · 캘린더"
      actions={
        <>
          <Btn kind="outline" size="sm">월간 보기</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>일정 추가</Btn>
        </>
      }
    >
      <Card padding={0} style={{ overflow: 'hidden' }}>
        <div style={{ padding: '14px 24px', borderBottom: '1px solid var(--ink-100)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12 }}>
            <Btn kind="ghost" size="sm" icon={<Ic.chevL/>}/>
            <div className="h3" style={{ margin: 0 }}>2026년 5월 25일 ~ 5월 31일</div>
            <Btn kind="ghost" size="sm" icon={<Ic.chevR/>}/>
            <Btn kind="outline" size="xs" style={{ marginLeft: 6 }}>오늘</Btn>
          </div>
          <div style={{ display: 'flex', gap: 12, fontSize: 11 }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, color: 'var(--ink-700)' }}><span style={{ width: 10, height: 10, background: 'var(--navy-700)', borderRadius: 2 }}/>동행</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, color: 'var(--ink-700)' }}><span style={{ width: 10, height: 10, background: 'var(--green-600)', borderRadius: 2 }}/>방문</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, color: 'var(--ink-700)' }}><span style={{ width: 10, height: 10, background: 'var(--navy-500)', borderRadius: 2 }}/>상담</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5, color: 'var(--ink-700)' }}><span style={{ width: 10, height: 10, background: '#7A4B7A', borderRadius: 2 }}/>내부</span>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '60px repeat(5, 1fr)', borderBottom: '1px solid var(--ink-100)' }}>
          <div/>
          {['월 25','화 26','수 27','목 28','금 29'].map((d, i) => (
            <div key={d} style={{ padding: '12px 0', textAlign: 'center', borderLeft: '1px solid var(--ink-100)', background: i === 3 ? 'var(--navy-50)' : 'transparent' }}>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 500 }}>{d.split(' ')[0]}</div>
              <div style={{ fontSize: 18, fontWeight: 700, marginTop: 2, color: i === 3 ? 'var(--navy-700)' : 'var(--ink-900)' }}>{d.split(' ')[1]}</div>
            </div>
          ))}
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '60px repeat(5, 1fr)', position: 'relative' }}>
          {/* Hours */}
          {[9,10,11,12,13,14,15,16,17].map(h => (
            <React.Fragment key={h}>
              <div style={{ borderRight: '1px solid var(--ink-100)', padding: '8px 8px', fontSize: 10, color: 'var(--ink-500)', textAlign: 'right', height: 56 }}>{h}:00</div>
              {[0,1,2,3,4].map(d => (
                <div key={d} style={{ borderLeft: '1px solid var(--ink-100)', borderTop: h > 9 ? '1px solid var(--ink-100)' : 'none', position: 'relative', minHeight: 56 }}/>
              ))}
            </React.Fragment>
          ))}

          {/* Events overlay */}
          {slots.map((s, i) => {
            const colW = (1320 - 224 - 64 - 60) / 5;
            const top = (s.h - 9) * 56;
            const left = 60 + s.d * colW;
            const colors = {
              navy: { bg: 'var(--navy-100)', bd: 'var(--navy-700)', fg: 'var(--navy-900)' },
              green: { bg: 'var(--green-100)', bd: 'var(--green-700)', fg: 'var(--green-900)' },
              plum: { bg: '#EBE0EB', bd: '#7A4B7A', fg: '#4A2B4A' },
              warm: { bg: '#F3E1D4', bd: '#A65A3D', fg: '#5A2D1B' }
            };
            const c = colors[s.tone];
            return (
              <div key={i} style={{
                position: 'absolute', top: top + 3, left: left + 2,
                width: colW - 4, height: s.w * 56 - 6,
                background: c.bg, borderLeft: `3px solid ${c.bd}`, color: c.fg,
                borderRadius: 6, padding: '6px 9px', overflow: 'hidden'
              }}>
                <div style={{ fontSize: 11, fontWeight: 700 }}>{s.h}:00 — {s.h + s.w}:00</div>
                <div style={{ fontSize: 12, fontWeight: 600, marginTop: 2 }}>{s.t}</div>
                <div style={{ fontSize: 11, opacity: 0.7, marginTop: 1 }}>{s.who}</div>
              </div>
            );
          })}
        </div>
      </Card>
    </PortalShell>
  );
}

// ── 4-3. 입소 진행 관리 ────────────────────────────────────────────────
function CoordAdmission() {
  return (
    <PortalShell
      brand="케어 코디" brandColor="linear-gradient(135deg, #7A4B7A, #1B466F)" role="복지 플랫폼 · 코디네이터"
      active="admission" navItems={COORD_NAV}
      title="입소 진행 관리"
      breadcrumb="코디네이터 · 정혜영 보호자"
      actions={<Btn kind="primary" size="sm">계약 완료 처리</Btn>}
    >
      <div style={{ display: 'grid', gridTemplateColumns: '1fr 380px', gap: 16, height: '100%' }}>
        <Card padding={28} style={{ overflow: 'hidden' }}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start', marginBottom: 24 }}>
            <div>
              <div className="h2">정혜영 보호자 — 평안의 집 입소</div>
              <div className="cap" style={{ marginTop: 4 }}>정해진 어르신 · 81세 · 4등급 · 입소 예정 2026.06.05</div>
            </div>
            <Tag tone="green" size="lg" dot>계약 진행 75%</Tag>
          </div>

          {/* Stepper */}
          <div style={{ position: 'relative', paddingLeft: 20 }}>
            <div style={{ position: 'absolute', left: 28, top: 16, bottom: 16, width: 2, background: 'var(--ink-100)' }}/>
            {[
              { n: 1, t: '상담 완료', d: '5/15', s: '시설 추천 3곳 제공, 평안의 집 선택', done: true },
              { n: 2, t: '시설 방문', d: '5/22', s: '평안의 집 시설 투어 동행 · 80분', done: true },
              { n: 3, t: '서류 제출', d: '5/26', s: '장기요양인정서, 건강검진서, 동의서 4건', done: true },
              { n: 4, t: '계약 체결', d: '5/30', s: '계약서 서명 일정 협의 중', done: false, active: true },
              { n: 5, t: '입소 준비', d: '6/3', s: '소지품 정리, 가족 면회 안내', done: false },
              { n: 6, t: '입소 완료', d: '6/5', s: '평안의 집 F-208 호실 입소', done: false }
            ].map((st, i, a) => (
              <div key={i} style={{ display: 'flex', gap: 16, paddingBottom: i === a.length - 1 ? 0 : 22, position: 'relative' }}>
                <div style={{
                  width: 36, height: 36, borderRadius: '50%',
                  background: st.done ? 'var(--green-700)' : st.active ? 'var(--navy-700)' : '#fff',
                  border: st.done || st.active ? 'none' : '2px solid var(--ink-200)',
                  color: st.done || st.active ? '#fff' : 'var(--ink-500)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center',
                  fontSize: 13, fontWeight: 700, flexShrink: 0, zIndex: 1
                }}>
                  {st.done ? <Ic.check/> : st.n}
                </div>
                <div style={{ flex: 1, paddingTop: 4 }}>
                  <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                    <div style={{ fontSize: 14, fontWeight: 700, color: st.done || st.active ? 'var(--ink-900)' : 'var(--ink-500)' }}>{st.t}</div>
                    <div style={{ fontSize: 12, color: 'var(--ink-500)' }}>{st.d}</div>
                  </div>
                  <div style={{ fontSize: 12, color: 'var(--ink-600)', marginTop: 4 }}>{st.s}</div>
                  {st.active && (
                    <div style={{ marginTop: 10, display: 'flex', gap: 6 }}>
                      <Btn kind="primary" size="sm">계약서 보내기</Btn>
                      <Btn kind="outline" size="sm">일정 변경</Btn>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Documents */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: 14 }}>
          <Card padding={20}>
            <div className="h3" style={{ marginBottom: 14 }}>제출 서류 (5)</div>
            {[
              { n: '장기요양인정서', s: '제출 완료', tone: 'success' },
              { n: '건강검진서', s: '제출 완료', tone: 'success' },
              { n: '의사 소견서', s: '제출 완료', tone: 'success' },
              { n: '입소 신청서', s: '제출 완료', tone: 'success' },
              { n: '입소 계약서', s: '서명 대기', tone: 'warn' }
            ].map((d, i, a) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderTop: i > 0 ? '1px solid var(--ink-100)' : 'none' }}>
                <Ic.doc style={{ color: d.tone === 'warn' ? 'var(--warning)' : 'var(--green-700)' }}/>
                <div style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{d.n}</div>
                <Tag tone={d.tone} size="sm">{d.s}</Tag>
              </div>
            ))}
          </Card>

          <Card padding={20} style={{ flex: 1 }}>
            <div className="h3" style={{ marginBottom: 14 }}>관련 인원</div>
            {[
              { n: '정혜영', r: '보호자 (딸)', tone: 'warm' },
              { n: '한미경', r: '평안의 집 담당자', tone: 'green' },
              { n: '홍은영', r: '코디네이터 (나)', tone: 'navy' }
            ].map((p, i) => (
              <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '8px 0' }}>
                <Avatar name={p.n[0]} tone={p.tone} size={32}/>
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{p.n}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-500)' }}>{p.r}</div>
                </div>
                <Ic.chat style={{ color: 'var(--ink-400)' }}/>
              </div>
            ))}
          </Card>
        </div>
      </div>
    </PortalShell>
  );
}

// ════════════════════════════════════════════════════════════════════════
// 5. 플랫폼 관리자
// ════════════════════════════════════════════════════════════════════════
const PLATFORM_NAV = [
  { id: 'members', t: '회원 관리', icon: Ic.user },
  { id: 'approval', t: '시설 승인', icon: Ic.shield, badge: '6' },
  { id: 'ads', t: '광고 관리', icon: Ic.sparkle },
  { id: 'settle', t: '정산 관리', icon: Ic.won },
  { id: 'support', t: '고객센터', icon: Ic.alert, badge: '14' }
];

// ── 5-1. 회원 관리 ─────────────────────────────────────────────────────
function PlatformMembers() {
  return (
    <PortalShell
      brand="복지 어드민" brandColor="var(--ink-1000)" role="플랫폼 운영"
      active="members" navItems={PLATFORM_NAV}
      title="회원 관리"
      breadcrumb="플랫폼 · 회원"
      actions={
        <>
          <Btn kind="outline" size="sm" icon={<Ic.download/>}>내보내기</Btn>
          <Btn kind="primary" size="sm" icon={<Ic.plus/>}>계정 추가</Btn>
        </>
      }
    >
      {/* Tabs */}
      <div style={{ display: 'flex', gap: 4, marginBottom: 16, background: '#fff', padding: 4, borderRadius: 10, width: 'fit-content', border: '1px solid var(--ink-100)' }}>
        {[
          { l: '보호자', n: '4,128', on: true },
          { l: '시설', n: '286' },
          { l: '병원·복지사', n: '94' },
          { l: '코디네이터', n: '32' }
        ].map((t, i) => (
          <div key={t.l} style={{
            padding: '8px 18px', borderRadius: 6,
            background: t.on ? 'var(--navy-700)' : 'transparent',
            color: t.on ? '#fff' : 'var(--ink-700)',
            fontSize: 13, fontWeight: 600,
            display: 'inline-flex', alignItems: 'center', gap: 8
          }}>
            {t.l}
            <span style={{ background: t.on ? 'rgba(255,255,255,0.2)' : 'var(--ink-100)', padding: '1px 7px', borderRadius: 'var(--r-pill)', fontSize: 11 }}>{t.n}</span>
          </div>
        ))}
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="전체 가입" value="4,128" unit="명" delta="+184 이번 달"/>
        <KPI label="활성 사용자" value="2,946" unit="명" delta="71.4% 활성"/>
        <KPI label="입소 완료" value="1,082" unit="건" delta="누적"/>
        <KPI label="평균 만족도" value="4.6" unit="/ 5.0" delta="후기 2.4k건"/>
      </div>

      <Card padding={0} style={{ overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)', display: 'flex', gap: 10, alignItems: 'center' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8, padding: '8px 12px', background: 'var(--ink-50)', borderRadius: 8, width: 280 }}>
            <Ic.search style={{ width: 14, height: 14, color: 'var(--ink-500)' }}/>
            <span style={{ fontSize: 13, color: 'var(--ink-500)' }}>이름·이메일·휴대폰</span>
          </div>
          <Tag tone="outline" size="md">전체</Tag>
          <Tag tone="success" size="md">활성</Tag>
          <Tag tone="warn" size="md">미인증</Tag>
          <Tag tone="danger" size="md">정지</Tag>
        </div>

        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: 'var(--bg-sunken)' }}>
              {['','이름','연락처','입소자','가입일','마지막 로그인','상태',''].map(h => (
                <th key={h} style={{ padding: '11px 16px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              { n: '박소영', tone: 'warm', tel: 'p.soyoung@***', p: '박정호 · 햇살요양원', d: '2024.03.10', l: '15분 전', s: '활성', sT: 'success' },
              { n: '김민준', tone: 'navy', tel: 'k.minjun@***', p: '김순례 · 햇살요양원', d: '2024.07.01', l: '2시간 전', s: '활성', sT: 'success' },
              { n: '이지원', tone: 'green', tel: 'l.jiwon@***', p: '이갑수 · 햇살요양원', d: '2025.01.18', l: '어제', s: '활성', sT: 'success' },
              { n: '최우식', tone: 'plum', tel: 'c.woosik@***', p: '최정심 · 햇살요양원', d: '2025.03.05', l: '3일 전', s: '활성', sT: 'success' },
              { n: '윤은혜', tone: 'warm', tel: 'y.eunhye@***', p: '윤덕봉 · 햇살요양원', d: '2023.11.12', l: '1주 전', s: '활성', sT: 'success' },
              { n: '한도윤', tone: 'navy', tel: 'h.doyoon@***', p: '미배정', d: '2026.05.15', l: '오늘', s: '미인증', sT: 'warn' },
              { n: '강민서', tone: 'green', tel: 'k.minseo@***', p: '강명환 · 햇살요양원', d: '2024.09.15', l: '5일 전', s: '활성', sT: 'success' },
              { n: '서지호', tone: 'plum', tel: 's.jiho@***', p: '서영자 · 햇살요양원', d: '2024.05.19', l: '2일 전', s: '활성', sT: 'success' }
            ].map((r, i, a) => (
              <tr key={i} style={{ borderTop: '1px solid var(--ink-100)' }}>
                <td style={{ padding: '12px 16px' }}><div style={{ width: 16, height: 16, border: '1.5px solid var(--ink-300)', borderRadius: 4 }}/></td>
                <td style={{ padding: '12px 16px' }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
                    <Avatar name={r.n[0]} tone={r.tone} size={32}/>
                    <div style={{ fontWeight: 600 }}>{r.n}</div>
                  </div>
                </td>
                <td style={{ padding: '12px 16px', color: 'var(--ink-700)' }} className="num">{r.tel}</td>
                <td style={{ padding: '12px 16px', color: 'var(--ink-700)' }}>{r.p}</td>
                <td style={{ padding: '12px 16px', color: 'var(--ink-700)' }} className="num">{r.d}</td>
                <td style={{ padding: '12px 16px', color: 'var(--ink-700)' }}>{r.l}</td>
                <td style={{ padding: '12px 16px' }}><Tag tone={r.sT} size="sm" dot>{r.s}</Tag></td>
                <td style={{ padding: '12px 16px' }}><Ic.more style={{ color: 'var(--ink-400)' }}/></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </PortalShell>
  );
}

// ── 5-2. 시설 승인 ─────────────────────────────────────────────────────
function PlatformApproval() {
  return (
    <PortalShell
      brand="복지 어드민" brandColor="var(--ink-1000)" role="플랫폼 운영"
      active="approval" navItems={PLATFORM_NAV}
      title="시설 승인 심사"
      breadcrumb="플랫폼 · 시설 인증"
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="승인 대기" value="6" unit="건" delta="평균 2.3일" icon={<Ic.alert style={{ color: 'var(--warning)' }}/>}/>
        <KPI label="이번 달 승인" value="12" unit="건"/>
        <KPI label="반려" value="2" unit="건" delta="서류 미비"/>
        <KPI label="전체 등록 시설" value="286"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14, height: 'calc(100% - 130px)' }}>
        {/* Queue */}
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)' }}>
            <div className="h3">승인 대기 중</div>
          </div>
          {[
            { n: '드림케어요양원', loc: '서울 송파구', d: '2일 전', stage: '서류 검토 중', sel: true, t: 'green' },
            { n: '편안의 집', loc: '경기 분당구', d: '3일 전', stage: '현장 실사 예정', t: 'navy' },
            { n: '햇살 제2호점', loc: '서울 강남구', d: '4일 전', stage: '서류 검토 중', t: 'plum' },
            { n: '늘봄 강서점', loc: '서울 강서구', d: '5일 전', stage: '추가 서류 요청', t: 'warm' },
            { n: '평안의 집 2호', loc: '경기 수원시', d: '6일 전', stage: '심사 위원회', t: 'navy' },
            { n: '온누리요양원', loc: '인천 부평구', d: '7일 전', stage: '서류 검토 중', t: 'green' }
          ].map((f, i, a) => (
            <div key={i} style={{
              padding: '14px 20px', display: 'flex', gap: 12, alignItems: 'center',
              borderTop: '1px solid var(--ink-100)',
              background: f.sel ? 'var(--navy-50)' : '#fff'
            }}>
              <div style={{ width: 44, height: 44, borderRadius: 10, background: `linear-gradient(135deg, var(--${f.t === 'navy' ? 'navy' : f.t === 'green' ? 'green' : 'navy'}-600), var(--${f.t === 'navy' ? 'navy' : f.t === 'green' ? 'green' : 'navy'}-700))`, display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
                <Ic.building/>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 14, fontWeight: 700 }}>{f.n}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>{f.loc} · 신청 {f.d}</div>
              </div>
              <Tag tone={f.stage === '추가 서류 요청' ? 'warn' : 'navy'} size="sm">{f.stage}</Tag>
              <Ic.chevR style={{ color: 'var(--ink-400)' }}/>
            </div>
          ))}
        </Card>

        {/* Detail review */}
        <Card padding={24} style={{ overflow: 'hidden' }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 12, marginBottom: 16 }}>
            <div style={{ width: 52, height: 52, borderRadius: 12, background: 'linear-gradient(135deg, var(--green-600), var(--green-800))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.building/></div>
            <div style={{ flex: 1 }}>
              <div className="h3">드림케어요양원</div>
              <div className="cap">서울 송파구 가락동 · 정원 56명</div>
            </div>
            <Tag tone="warn" size="md">검토 중</Tag>
          </div>

          <div className="label" style={{ marginBottom: 8 }}>제출 서류</div>
          {[
            { n: '사업자등록증', s: '확인 완료', tone: 'success' },
            { n: '노인의료복지시설 신고증', s: '확인 완료', tone: 'success' },
            { n: '시설 평면도', s: '확인 완료', tone: 'success' },
            { n: '인력 배치도', s: '확인 중', tone: 'warn' },
            { n: '운영 규정', s: '확인 완료', tone: 'success' }
          ].map((d, i, a) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '9px 0', borderTop: i > 0 ? '1px solid var(--ink-100)' : 'none' }}>
              <Ic.doc style={{ color: d.tone === 'warn' ? 'var(--warning)' : 'var(--green-700)' }}/>
              <div style={{ flex: 1, fontSize: 13, fontWeight: 500 }}>{d.n}</div>
              <Tag tone={d.tone} size="sm">{d.s}</Tag>
              <Ic.download style={{ color: 'var(--ink-400)' }}/>
            </div>
          ))}

          <div style={{ height: 1, background: 'var(--ink-100)', margin: '16px 0' }}/>

          <div className="label" style={{ marginBottom: 8 }}>심사 메모</div>
          <div style={{ padding: 12, background: 'var(--bg-sunken)', borderRadius: 8, fontSize: 12, color: 'var(--ink-700)', lineHeight: 1.6, marginBottom: 14 }}>
            인력 배치도 상 야간 간호 인력이 1명으로 표기되어 있음. 정원 56명 기준 야간 최소 2명 필요 — 보완 요청 필요
          </div>

          <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr 1fr', gap: 6 }}>
            <Btn kind="outline" size="sm">반려</Btn>
            <Btn kind="secondary" size="sm">보완 요청</Btn>
            <Btn kind="accent" size="sm">승인</Btn>
          </div>
        </Card>
      </div>
    </PortalShell>
  );
}

// ── 5-3. 광고 관리 ─────────────────────────────────────────────────────
function PlatformAds() {
  return (
    <PortalShell
      brand="복지 어드민" brandColor="var(--ink-1000)" role="플랫폼 운영"
      active="ads" navItems={PLATFORM_NAV}
      title="광고 관리"
      breadcrumb="플랫폼 · 광고 상품"
      actions={<Btn kind="primary" size="sm" icon={<Ic.plus/>}>광고 등록</Btn>}
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="이번 달 광고 매출" value="4,820" unit="만원" delta="+18% vs 전월"/>
        <KPI label="진행 중 캠페인" value="38" delta="프리미엄 22"/>
        <KPI label="평균 CTR" value="3.4" unit="%" delta="목표 3.0%"/>
        <KPI label="대기 검수" value="4" unit="건" icon={<Ic.alert style={{ color: 'var(--warning)' }}/>}/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 14, marginBottom: 16 }}>
        {[
          { t: '프리미엄 노출', s: '검색 결과 상단', n: 22, p: '월 150만원', tone: 'navy', icon: Ic.sparkle },
          { t: '메인 배너', s: '앱 홈 화면', n: 8, p: '주 80만원', tone: 'green', icon: Ic.building },
          { t: '지역 광고', s: '지역 검색 결과', n: 8, p: '월 40만원', tone: 'plum', icon: Ic.pin }
        ].map((c, i) => {
          const Icon = c.icon;
          const colors = { navy: 'var(--navy-700)', green: 'var(--green-700)', plum: '#7A4B7A' };
          return (
            <Card key={i} padding={20}>
              <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
                <div style={{ width: 40, height: 40, borderRadius: 10, background: colors[c.tone], color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center' }}><Icon/></div>
                <div style={{ flex: 1 }}>
                  <div className="h3">{c.t}</div>
                  <div className="cap" style={{ marginTop: 2 }}>{c.s}</div>
                </div>
                <Ic.more style={{ color: 'var(--ink-400)' }}/>
              </div>
              <div style={{ display: 'flex', justifyContent: 'space-between', marginTop: 14, paddingTop: 14, borderTop: '1px solid var(--ink-100)' }}>
                <div>
                  <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>진행 중</div>
                  <div className="num" style={{ fontSize: 18, fontWeight: 700 }}>{c.n}건</div>
                </div>
                <div style={{ textAlign: 'right' }}>
                  <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>단가</div>
                  <div style={{ fontSize: 14, fontWeight: 700, color: 'var(--navy-700)' }}>{c.p}</div>
                </div>
              </div>
            </Card>
          );
        })}
      </div>

      <Card padding={0} style={{ overflow: 'hidden' }}>
        <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)' }}>
          <div className="h3">진행 중인 캠페인</div>
        </div>
        <table style={{ width: '100%', borderCollapse: 'collapse', fontSize: 13 }}>
          <thead>
            <tr style={{ background: 'var(--bg-sunken)' }}>
              {['시설명','상품','기간','노출','클릭','CTR','상태'].map(h => (
                <th key={h} style={{ padding: '11px 18px', textAlign: 'left', fontSize: 11, fontWeight: 700, color: 'var(--ink-500)', letterSpacing: '0.04em', textTransform: 'uppercase' }}>{h}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {[
              { n: '햇살요양원', p: '프리미엄 노출', t: 'navy', d: '5/1 ~ 5/31', i: '128,492', c: '4,824', ctr: '3.76%', s: '진행 중', sT: 'success' },
              { n: '늘봄케어센터', p: '메인 배너', t: 'green', d: '5/20 ~ 5/26', i: '88,124', c: '2,148', ctr: '2.44%', s: '진행 중', sT: 'success' },
              { n: '평안의 집', p: '지역 광고', t: 'plum', d: '5/15 ~ 6/14', i: '24,488', c: '892', ctr: '3.64%', s: '진행 중', sT: 'success' },
              { n: '드림케어', p: '프리미엄 노출', t: 'navy', d: '대기', i: '—', c: '—', ctr: '—', s: '검수 중', sT: 'warn' }
            ].map((r, i, a) => (
              <tr key={i} style={{ borderTop: '1px solid var(--ink-100)' }}>
                <td style={{ padding: '12px 18px', fontWeight: 600 }}>{r.n}</td>
                <td style={{ padding: '12px 18px' }}><Tag tone={r.t} size="sm">{r.p}</Tag></td>
                <td style={{ padding: '12px 18px', color: 'var(--ink-700)' }}>{r.d}</td>
                <td style={{ padding: '12px 18px', color: 'var(--ink-800)' }} className="num">{r.i}</td>
                <td style={{ padding: '12px 18px', color: 'var(--ink-800)' }} className="num">{r.c}</td>
                <td style={{ padding: '12px 18px', fontWeight: 700 }}>{r.ctr}</td>
                <td style={{ padding: '12px 18px' }}><Tag tone={r.sT} size="sm" dot>{r.s}</Tag></td>
              </tr>
            ))}
          </tbody>
        </table>
      </Card>
    </PortalShell>
  );
}

// ── 5-4. 정산 관리 (플랫폼) ────────────────────────────────────────────
function PlatformSettle() {
  return (
    <PortalShell
      brand="복지 어드민" brandColor="var(--ink-1000)" role="플랫폼 운영"
      active="settle" navItems={PLATFORM_NAV}
      title="플랫폼 정산"
      breadcrumb="플랫폼 · 정산"
      actions={<Btn kind="primary" size="sm">5월 정산 확정</Btn>}
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="5월 총 GMV" value="58.4" unit="억원" delta="+8.2% vs 전월"/>
        <KPI label="입소 수수료" value="2.92" unit="억원" delta="입소 134건"/>
        <KPI label="광고 매출" value="4,820" unit="만원" delta="38 캠페인"/>
        <KPI label="시설 정산 예정" value="55.0" unit="억원" delta="6월 10일"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: 14, height: 'calc(100% - 130px)' }}>
        {/* Revenue chart */}
        <Card padding={24}>
          <div className="h3" style={{ marginBottom: 16 }}>월별 매출 구성</div>
          <div style={{ height: 280, padding: '10px 0' }}>
            <svg width="100%" height="100%" viewBox="0 0 700 280" preserveAspectRatio="none">
              {[0,1,2,3,4].map(i => (
                <g key={i}>
                  <line x1="40" x2="700" y1={50*i + 20} y2={50*i + 20} stroke="var(--ink-100)" strokeWidth="1"/>
                </g>
              ))}
              {[
                { co: 200, ad: 35 },
                { co: 215, ad: 38 },
                { co: 240, ad: 42 },
                { co: 258, ad: 45 },
                { co: 270, ad: 41 },
                { co: 292, ad: 48 }
              ].map((d, i) => {
                const x = 60 + i * 110;
                const coH = d.co * 0.75;
                const adH = d.ad * 1.5;
                return (
                  <g key={i}>
                    <rect x={x} y={250 - coH} width="44" height={coH} rx="3" fill="var(--navy-700)"/>
                    <rect x={x} y={250 - coH - adH} width="44" height={adH} rx="3" fill="var(--green-600)"/>
                    <text x={x + 22} y={245 - coH - adH - 5} fontSize="10" fontWeight="700" textAnchor="middle" fill="var(--ink-800)">{(d.co + d.ad / 10).toFixed(0)}M</text>
                  </g>
                );
              })}
              {['12월','1월','2월','3월','4월','5월'].map((m, i) => (
                <text key={m} x={60 + i*110 + 22} y="275" fontSize="11" textAnchor="middle" fill="var(--ink-500)" fontWeight="500">{m}</text>
              ))}
            </svg>
          </div>
          <div style={{ display: 'flex', gap: 14, fontSize: 12, marginTop: 8, justifyContent: 'center' }}>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 12, background: 'var(--navy-700)', borderRadius: 3 }}/>입소 수수료</span>
            <span style={{ display: 'inline-flex', alignItems: 'center', gap: 5 }}><span style={{ width: 12, height: 12, background: 'var(--green-600)', borderRadius: 3 }}/>광고 매출</span>
          </div>
        </Card>

        {/* Settlement list */}
        <Card padding={0} style={{ overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)' }}>
            <div className="h3">시설 정산 예정</div>
            <div className="cap" style={{ marginTop: 2 }}>6월 10일 입금 · 286개 시설</div>
          </div>
          <div style={{ flex: 1, overflow: 'hidden' }}>
            {[
              { n: '햇살요양원', a: 9086, c: 98 },
              { n: '늘봄케어센터', a: 12420, c: 124 },
              { n: '평안의 집', a: 14250, c: 142 },
              { n: '편안의 집', a: 6820, c: 68 },
              { n: '드림케어', a: 8910, c: 89 },
              { n: '온누리요양원', a: 7280, c: 72 }
            ].map((s, i, a) => (
              <div key={i} style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', padding: '12px 20px', borderTop: i > 0 ? '1px solid var(--ink-100)' : 'none' }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600 }}>{s.n}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>수수료 {s.c}만원</div>
                </div>
                <div className="num" style={{ fontSize: 14, fontWeight: 700 }}>{s.a.toLocaleString()}만원</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </PortalShell>
  );
}

// ── 5-5. 고객센터 ──────────────────────────────────────────────────────
function PlatformSupport() {
  return (
    <PortalShell
      brand="복지 어드민" brandColor="var(--ink-1000)" role="플랫폼 운영"
      active="support" navItems={PLATFORM_NAV}
      title="고객센터"
      breadcrumb="플랫폼 · CS"
      actions={<Btn kind="outline" size="sm">FAQ 관리</Btn>}
    >
      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 14, marginBottom: 16 }}>
        <KPI label="대기 중" value="14" delta="평균 응답 1.2시간" icon={<Ic.alert style={{ color: 'var(--warning)' }}/>}/>
        <KPI label="진행 중" value="28"/>
        <KPI label="이번 주 해결" value="42" delta="평균 8.4시간"/>
        <KPI label="만족도" value="4.7" unit="/ 5"/>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: '320px 1fr 360px', gap: 14, height: 'calc(100% - 130px)' }}>
        {/* Ticket list */}
        <Card padding={0} style={{ overflow: 'hidden' }}>
          <div style={{ padding: '12px 16px', borderBottom: '1px solid var(--ink-100)', display: 'flex', alignItems: 'center', gap: 6 }}>
            <Tag tone="navy" size="md">전체</Tag>
            <Tag tone="warn" size="md">신고 3</Tag>
            <Tag tone="info" size="md">문의</Tag>
          </div>
          {[
            { t: '신고', tT: 'danger', n: '박소영 보호자', s: '시설 위생 관련 신고', time: '10분', new: true, sel: true },
            { t: '문의', tT: 'navy', n: '김지원 원장', s: '플랫폼 수수료 정산 문의', time: '34분', new: true },
            { t: '신고', tT: 'danger', n: '이지원 보호자', s: '계약 해지 분쟁', time: '1시간', new: true },
            { t: '문의', tT: 'navy', n: '한미경 담당자', s: '광고 상품 노출 문의', time: '2시간' },
            { t: '문의', tT: 'navy', n: '윤지혜 담당자', s: '보호자 메시지 발송 오류', time: '3시간' },
            { t: '신고', tT: 'danger', n: '최우식 보호자', s: '후기 작성 거부 사유', time: '5시간' },
            { t: '문의', tT: 'navy', n: '강민서 보호자', s: '결제 영수증 재발급', time: '어제' }
          ].map((c, i, a) => (
            <div key={i} style={{
              padding: '14px 16px', borderTop: '1px solid var(--ink-100)',
              background: c.sel ? 'var(--navy-50)' : '#fff'
            }}>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 6 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <Tag tone={c.tT} size="sm">{c.t}</Tag>
                  {c.new && <span style={{ width: 6, height: 6, background: 'var(--danger)', borderRadius: '50%' }}/>}
                </div>
                <div style={{ fontSize: 11, color: 'var(--ink-400)' }}>{c.time}</div>
              </div>
              <div style={{ fontSize: 13, fontWeight: 600, color: 'var(--ink-900)' }}>{c.s}</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 3 }}>{c.n}</div>
            </div>
          ))}
        </Card>

        {/* Chat */}
        <Card padding={0} style={{ display: 'flex', flexDirection: 'column', overflow: 'hidden' }}>
          <div style={{ padding: '14px 20px', borderBottom: '1px solid var(--ink-100)', display: 'flex', alignItems: 'center', gap: 12 }}>
            <Avatar name="박" tone="warm" size={36}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700, display: 'flex', alignItems: 'center', gap: 6 }}>박소영 보호자 <Tag tone="danger" size="sm">신고</Tag></div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>박정호 어르신 · 햇살요양원</div>
            </div>
            <Btn kind="outline" size="sm">시설에 문의</Btn>
            <Btn kind="accent" size="sm">해결 처리</Btn>
          </div>

          <div style={{ flex: 1, overflow: 'hidden', padding: 20, display: 'flex', flexDirection: 'column', gap: 12 }}>
            <div style={{ alignSelf: 'center', fontSize: 10, color: 'var(--ink-400)', padding: '4px 10px', background: 'var(--ink-50)', borderRadius: 'var(--r-pill)' }}>오늘 14:22</div>

            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <Avatar name="박" tone="warm" size={28}/>
              <div style={{ flex: 1 }}>
                <div style={{ background: '#fff', border: '1px solid var(--ink-100)', borderRadius: '4px 12px 12px 12px', padding: '10px 14px', fontSize: 13, lineHeight: 1.55, maxWidth: '76%' }}>
                  아버지 호실에서 곰팡이 냄새가 난다는 말을 들었습니다. 어제 면회 갔을 때도 확인했어요. 시설 측에 직접 말씀드렸는데 답이 늦어 신고드립니다.
                </div>
              </div>
            </div>

            <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
              <div style={{ background: 'var(--navy-700)', color: '#fff', borderRadius: '12px 4px 12px 12px', padding: '10px 14px', fontSize: 13, maxWidth: '76%' }}>
                안녕하세요 박소영 님. 신고 접수가 완료되었습니다. 햇살요양원에 즉시 사실 확인 요청드렸고, 24시간 내 답변 드리겠습니다.
              </div>
            </div>

            <div style={{ alignSelf: 'center', fontSize: 10, color: 'var(--ink-400)', padding: '4px 10px', background: 'var(--ink-50)', borderRadius: 'var(--r-pill)' }}>15분 전</div>

            <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
              <Avatar name="박" tone="warm" size={28}/>
              <div style={{ flex: 1 }}>
                <div style={{ background: '#fff', border: '1px solid var(--ink-100)', borderRadius: '4px 12px 12px 12px', padding: '10px 14px', fontSize: 13, maxWidth: '76%' }}>
                  네 빠른 답변 감사합니다. 결과 알려주세요.
                </div>
              </div>
            </div>
          </div>

          <div style={{ padding: '12px 16px', borderTop: '1px solid var(--ink-100)', display: 'flex', gap: 8, alignItems: 'center' }}>
            <div style={{ flex: 1, background: 'var(--ink-50)', borderRadius: 8, padding: '10px 14px', fontSize: 13, color: 'var(--ink-400)' }}>답변 입력…</div>
            <Btn kind="primary" size="sm" icon={<Ic.send/>}>전송</Btn>
          </div>
        </Card>

        {/* Side */}
        <Card padding={20} style={{ overflow: 'hidden' }}>
          <div className="label" style={{ marginBottom: 8 }}>신고 정보</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8, marginBottom: 16 }}>
            {[
              ['카테고리', '시설 위생'],
              ['접수일시', '오늘 14:22'],
              ['시설', '햇살요양원'],
              ['담당자', '김지원 원장'],
              ['우선순위', '높음']
            ].map(([l, v]) => (
              <div key={l} style={{ display: 'flex', justifyContent: 'space-between', fontSize: 12 }}>
                <span style={{ color: 'var(--ink-500)' }}>{l}</span>
                <span style={{ fontWeight: 600 }}>{v}</span>
              </div>
            ))}
          </div>

          <div className="label" style={{ marginBottom: 8 }}>처리 단계</div>
          <div style={{ position: 'relative', paddingLeft: 16 }}>
            <div style={{ position: 'absolute', left: 7, top: 8, bottom: 8, width: 2, background: 'var(--ink-100)' }}/>
            {[
              { l: '접수', d: '오늘 14:22', done: true },
              { l: '시설 확인 요청', d: '15분 전', done: true },
              { l: '시설 답변', d: '진행 중', active: true },
              { l: '보호자 안내', d: '대기' },
              { l: '해결 완료', d: '대기' }
            ].map((s, i) => (
              <div key={i} style={{ display: 'flex', gap: 12, paddingBottom: 12, position: 'relative' }}>
                <div style={{ width: 14, height: 14, borderRadius: '50%', background: s.done ? 'var(--green-700)' : s.active ? 'var(--navy-700)' : '#fff', border: s.done || s.active ? 'none' : '2px solid var(--ink-300)', flexShrink: 0, marginLeft: -16, marginTop: 3, zIndex: 1 }}/>
                <div>
                  <div style={{ fontSize: 12, fontWeight: 600, color: s.done || s.active ? 'var(--ink-900)' : 'var(--ink-500)' }}>{s.l}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 1 }}>{s.d}</div>
                </div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </PortalShell>
  );
}

Object.assign(window, {
  PortalShell,
  HospitalRegister, HospitalRecommend, HospitalLink,
  CoordCaseload, CoordSchedule, CoordAdmission,
  PlatformMembers, PlatformApproval, PlatformAds, PlatformSettle, PlatformSupport
});
