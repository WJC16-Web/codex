// auth-flow.jsx — 보호자 앱 로그인 전/후 플로우 (12 화면)
// 모두 MobileFrame 내부에 들어가는 컨텐츠 (M_W=390, CONTENT_H=763)

// ─── Helper: 모바일 헤더 (뒤로가기 + 타이틀) ─────────────────────────
function MNavBar({ title, back = true, right, dark }) {
  return (
    <div style={{
      height: 48, padding: '0 8px 0 4px',
      display: 'flex', alignItems: 'center',
      background: dark ? 'transparent' : '#fff',
      color: dark ? '#fff' : 'var(--ink-900)',
      borderBottom: dark ? 'none' : '1px solid var(--ink-100)'
    }}>
      {back ? (
        <div style={{ width: 44, height: 44, display: 'flex', alignItems: 'center', justifyContent: 'center' }}>
          <Ic.chevL/>
        </div>
      ) : <div style={{ width: 16 }}/>}
      <div style={{ flex: 1, fontSize: 16, fontWeight: 700, textAlign: 'center', marginRight: back ? 44 : 16 }}>{title}</div>
      {right && <div style={{ minWidth: 44, display: 'flex', justifyContent: 'flex-end', paddingRight: 12 }}>{right}</div>}
    </div>
  );
}

function MProgressBar({ step, total }) {
  return (
    <div style={{ padding: '0 16px 14px', background: '#fff' }}>
      <div style={{ height: 3, background: 'var(--ink-100)', borderRadius: 2, overflow: 'hidden' }}>
        <div style={{ width: `${(step/total)*100}%`, height: '100%', background: 'var(--navy-700)', transition: 'width .3s' }}/>
      </div>
      <div style={{ fontSize: 10, color: 'var(--ink-500)', marginTop: 6, fontWeight: 500 }}>{step} / {total}</div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A1. Splash
// ═══════════════════════════════════════════════════════════════════════
function MobileSplash() {
  return (
    <div style={{
      width: M_W, height: CONTENT_H + 47 + 34, marginTop: -47, marginBottom: -34,
      background: 'linear-gradient(170deg, #07172A 0%, #133355 50%, #1B7654 130%)',
      color: '#fff', position: 'relative', overflow: 'hidden',
      display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center'
    }}>
      {/* decorative orbs */}
      <div style={{ position: 'absolute', top: -80, right: -80, width: 280, height: 280, borderRadius: '50%', background: 'rgba(255,255,255,0.05)' }}/>
      <div style={{ position: 'absolute', bottom: -100, left: -60, width: 240, height: 240, borderRadius: '50%', background: 'rgba(54,164,124,0.12)' }}/>

      {/* Logo */}
      <div style={{ width: 92, height: 92, borderRadius: 26, background: 'linear-gradient(135deg, #36A47C, #4180B0)', display: 'flex', alignItems: 'center', justifyContent: 'center', fontWeight: 800, fontSize: 46, marginBottom: 28, boxShadow: '0 12px 40px rgba(54, 164, 124, 0.35)' }}>복</div>

      <div style={{ fontSize: 36, fontWeight: 800, letterSpacing: '-0.03em', marginBottom: 12 }}>복지</div>
      <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.7)', textAlign: 'center', lineHeight: 1.6, padding: '0 32px' }}>
        부모님 곁에, 더 가까이<br/>
        실시간 공실 요양시설 매칭
      </div>

      {/* loading dots */}
      <div style={{ position: 'absolute', bottom: 80, display: 'flex', gap: 8 }}>
        {[0,1,2].map(i => (
          <div key={i} style={{ width: 8, height: 8, borderRadius: '50%', background: 'rgba(255,255,255,0.4)', opacity: i === 1 ? 1 : 0.5 }}/>
        ))}
      </div>

      <div style={{ position: 'absolute', bottom: 50, fontSize: 11, color: 'rgba(255,255,255,0.4)' }}>v 1.4.2</div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A2. 온보딩 (3페이지 중 2페이지)
// ═══════════════════════════════════════════════════════════════════════
function MobileOnboarding() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <div style={{ display: 'flex', justifyContent: 'flex-end', padding: '12px 20px' }}>
        <span style={{ fontSize: 13, color: 'var(--ink-500)', fontWeight: 500 }}>건너뛰기</span>
      </div>

      {/* Illustration */}
      <div style={{ flex: 1, display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', padding: '0 32px' }}>
        <div style={{ width: 260, height: 260, position: 'relative', marginBottom: 36 }}>
          {/* Stylized AI matching illustration */}
          <div style={{ position: 'absolute', inset: 0, background: 'radial-gradient(circle at center, var(--green-100), transparent 70%)' }}/>

          {/* Center AI orb */}
          <div style={{ position: 'absolute', left: '50%', top: '50%', transform: 'translate(-50%, -50%)', width: 76, height: 76, borderRadius: 22, background: 'linear-gradient(135deg, var(--navy-700), var(--green-700))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', boxShadow: '0 14px 30px rgba(27, 70, 111, 0.3)' }}>
            <Ic.sparkle style={{ width: 36, height: 36 }}/>
          </div>

          {/* Surrounding facility cards */}
          {[
            { x: 30, y: 30, tone: 'navy', label: '햇살' },
            { x: 200, y: 30, tone: 'green', label: '늘봄' },
            { x: 20, y: 180, tone: 'plum', label: '평안' },
            { x: 200, y: 180, tone: 'warm', label: '드림' }
          ].map((c, i) => {
            const toneColors = { navy: '#1B466F', green: '#1B7654', plum: '#7A4B7A', warm: '#A65A3D' };
            return (
              <div key={i} style={{
                position: 'absolute', left: c.x, top: c.y, width: 60, height: 60, borderRadius: 14,
                background: '#fff', boxShadow: '0 4px 14px rgba(11,27,63,0.12)',
                display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', gap: 4
              }}>
                <div style={{ width: 28, height: 28, borderRadius: 8, background: toneColors[c.tone], display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}>
                  <Ic.building style={{ width: 14, height: 14 }}/>
                </div>
                <div style={{ fontSize: 9, fontWeight: 700, color: 'var(--ink-700)' }}>{c.label}</div>
              </div>
            );
          })}

          {/* Dotted connections */}
          <svg style={{ position: 'absolute', inset: 0, pointerEvents: 'none' }} viewBox="0 0 260 260">
            <line x1="130" y1="130" x2="60" y2="60" stroke="var(--green-500)" strokeWidth="1.5" strokeDasharray="3 3"/>
            <line x1="130" y1="130" x2="230" y2="60" stroke="var(--green-500)" strokeWidth="1.5" strokeDasharray="3 3"/>
            <line x1="130" y1="130" x2="50" y2="210" stroke="var(--green-500)" strokeWidth="1.5" strokeDasharray="3 3"/>
            <line x1="130" y1="130" x2="230" y2="210" stroke="var(--green-500)" strokeWidth="1.5" strokeDasharray="3 3"/>
          </svg>
        </div>

        <Tag tone="green" size="md" dot>STEP 2 of 3</Tag>
        <div style={{ fontSize: 26, fontWeight: 800, letterSpacing: '-0.02em', marginTop: 14, textAlign: 'center', lineHeight: 1.3 }}>
          AI가 부모님께 맞는<br/>시설을 찾아드려요
        </div>
        <div style={{ fontSize: 14, color: 'var(--ink-500)', textAlign: 'center', marginTop: 12, lineHeight: 1.55 }}>
          장기요양등급, 치매 여부, 거동 상태와<br/>
          희망 지역·예산을 고려해 12곳을 추천합니다
        </div>
      </div>

      {/* Dots */}
      <div style={{ display: 'flex', justifyContent: 'center', gap: 6, padding: '20px 0 24px' }}>
        {[0,1,2].map(i => (
          <div key={i} style={{ width: i === 1 ? 24 : 8, height: 8, borderRadius: 4, background: i === 1 ? 'var(--navy-700)' : 'var(--ink-200)', transition: 'all .3s' }}/>
        ))}
      </div>

      {/* CTA */}
      <div style={{ padding: '0 16px 24px', display: 'flex', gap: 8 }}>
        <Btn kind="outline" size="lg" style={{ flex: 1 }}>이전</Btn>
        <Btn kind="primary" size="lg" style={{ flex: 2 }}>다음</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A3. 로그인 (소셜)
// ═══════════════════════════════════════════════════════════════════════
function MobileLogin() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: '#fff', display: 'flex', flexDirection: 'column', padding: '0 24px 24px' }}>
      <div style={{ height: 30 }}/>

      <div style={{ width: 60, height: 60, borderRadius: 16, background: 'linear-gradient(135deg, #36A47C, #4180B0)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', fontWeight: 800, fontSize: 30, marginBottom: 24 }}>복</div>

      <div style={{ fontSize: 28, fontWeight: 800, letterSpacing: '-0.025em', lineHeight: 1.25 }}>
        부모님 곁의 시간을<br/>
        <span style={{ color: 'var(--navy-700)' }}>복지</span>로 시작하세요
      </div>
      <div style={{ fontSize: 14, color: 'var(--ink-500)', marginTop: 10, lineHeight: 1.55 }}>
        간편 로그인으로 빠르게 시작할 수 있어요
      </div>

      <div style={{ flex: 1 }}/>

      {/* Social logins */}
      <div style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
        {/* Kakao */}
        <div style={{ height: 52, borderRadius: 12, background: '#FEE500', color: '#191919', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8, fontSize: 15, fontWeight: 700, position: 'relative' }}>
          <svg width="20" height="18" viewBox="0 0 20 18" fill="currentColor"><path d="M10 0C4.5 0 0 3.5 0 7.8c0 2.8 1.8 5.2 4.5 6.6L3.3 18l4.6-3c.7.1 1.4.2 2.1.2 5.5 0 10-3.5 10-7.8S15.5 0 10 0z"/></svg>
          카카오톡으로 1초 시작
          <span style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%) translateY(-32px)', background: 'var(--navy-800)', color: '#fff', fontSize: 10, padding: '4px 8px', borderRadius: 'var(--r-pill)', fontWeight: 600, whiteSpace: 'nowrap' }}>가장 많이 사용</span>
        </div>

        {/* Naver */}
        <div style={{ height: 52, borderRadius: 12, background: '#03C75A', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, fontSize: 15, fontWeight: 700 }}>
          <span style={{ fontFamily: 'serif', fontSize: 18, fontWeight: 900 }}>N</span>
          네이버로 시작하기
        </div>

        {/* Apple */}
        <div style={{ height: 52, borderRadius: 12, background: '#000', color: '#fff', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, fontSize: 15, fontWeight: 700 }}>
          <svg width="18" height="20" viewBox="0 0 18 20" fill="currentColor"><path d="M14.6 10.6c0-2.7 2.2-4 2.3-4-1.3-1.8-3.2-2.1-3.9-2.1-1.7-.2-3.2 1-4 1-.8 0-2.1-1-3.5-.9-1.8 0-3.4 1-4.3 2.7-1.8 3.2-.5 7.9 1.3 10.5.9 1.3 1.9 2.7 3.3 2.6 1.3-.1 1.8-.8 3.4-.8 1.6 0 2.1.8 3.5.8 1.4 0 2.3-1.3 3.2-2.6 1-1.5 1.4-2.9 1.4-3-.1 0-2.7-1-2.7-4.2zM12 2.7c.7-.9 1.2-2.1 1.1-3.3-1.1.1-2.4.7-3.1 1.6-.7.8-1.3 2-1.1 3.2 1.2.1 2.4-.6 3.1-1.5z"/></svg>
          Apple로 계속하기
        </div>

        {/* Phone */}
        <div style={{ height: 52, borderRadius: 12, border: '1px solid var(--ink-200)', display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 10, fontSize: 15, fontWeight: 700, color: 'var(--ink-800)' }}>
          <Ic.phone/>
          휴대폰 번호로 가입
        </div>
      </div>

      <div style={{ textAlign: 'center', marginTop: 22, fontSize: 12, color: 'var(--ink-500)' }}>
        가입 시 <span style={{ color: 'var(--ink-800)', fontWeight: 600, textDecoration: 'underline' }}>이용약관</span>과 <span style={{ color: 'var(--ink-800)', fontWeight: 600, textDecoration: 'underline' }}>개인정보 처리방침</span>에 동의하게 됩니다
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A4. 본인인증 (PASS)
// ═══════════════════════════════════════════════════════════════════════
function MobileAuth() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <MNavBar title="본인인증" back/>
      <MProgressBar step={1} total={5}/>

      <div style={{ padding: '12px 20px', flex: 1 }}>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.35 }}>
          본인 명의 휴대폰으로<br/>인증을 진행해주세요
        </div>
        <div style={{ fontSize: 13, color: 'var(--ink-500)', marginTop: 8, lineHeight: 1.5 }}>
          어르신 시설 입소는 신원 확인이 필요해<br/>본인인증을 거쳐야 합니다
        </div>

        {/* Carrier */}
        <div style={{ marginTop: 28 }}>
          <div className="label" style={{ marginBottom: 8 }}>통신사 선택</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 8 }}>
            {[
              { l: 'SKT', sel: true, color: '#EE0F38' },
              { l: 'KT', color: '#000' },
              { l: 'LG U+', color: '#A50034' }
            ].map(c => (
              <div key={c.l} style={{
                padding: '14px 0', borderRadius: 10, textAlign: 'center',
                background: c.sel ? c.color : '#fff',
                color: c.sel ? '#fff' : 'var(--ink-700)',
                border: c.sel ? 'none' : '1px solid var(--ink-200)',
                fontSize: 14, fontWeight: 700
              }}>{c.l}</div>
            ))}
            {[
              { l: 'SKT 알뜰' }, { l: 'KT 알뜰' }, { l: 'LG 알뜰' }
            ].map(c => (
              <div key={c.l} style={{ padding: '12px 0', borderRadius: 10, textAlign: 'center', background: '#fff', border: '1px solid var(--ink-200)', fontSize: 12, fontWeight: 600, color: 'var(--ink-700)' }}>{c.l}</div>
            ))}
          </div>
        </div>

        {/* Name */}
        <div style={{ marginTop: 22 }}>
          <div className="label" style={{ marginBottom: 8 }}>이름</div>
          <div style={{ padding: '14px 16px', background: '#fff', border: '1px solid var(--navy-700)', borderRadius: 10, fontSize: 15, fontWeight: 500, position: 'relative' }}>
            박소영
            <span style={{ position: 'absolute', right: 16, top: '50%', transform: 'translateY(-50%)', width: 6, height: 18, background: 'var(--navy-700)', animation: 'blink 1s infinite' }}/>
          </div>
        </div>

        {/* Birth */}
        <div style={{ marginTop: 16 }}>
          <div className="label" style={{ marginBottom: 8 }}>주민등록번호</div>
          <div style={{ display: 'flex', alignItems: 'center', gap: 8 }}>
            <div style={{ flex: 1, padding: '14px 16px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 10, fontSize: 15, fontWeight: 500 }} className="num">851205</div>
            <span style={{ fontSize: 16, color: 'var(--ink-400)' }}>—</span>
            <div style={{ flex: 1, padding: '14px 16px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 10, fontSize: 15, color: 'var(--ink-400)', display: 'flex', alignItems: 'center', gap: 4 }} className="num">
              2 <span style={{ letterSpacing: 4 }}>••••••</span>
            </div>
          </div>
        </div>

        {/* Phone */}
        <div style={{ marginTop: 16 }}>
          <div className="label" style={{ marginBottom: 8 }}>휴대폰 번호</div>
          <div style={{ padding: '14px 16px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 10, fontSize: 15, fontWeight: 500 }} className="num">010-2238-7124</div>
        </div>

        {/* Consent */}
        <div style={{ marginTop: 18, padding: 12, background: 'var(--bg-sunken)', borderRadius: 10, display: 'flex', gap: 8, alignItems: 'flex-start' }}>
          <div style={{ width: 16, height: 16, borderRadius: 4, background: 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff', flexShrink: 0, marginTop: 1 }}><Ic.check style={{ width: 11, height: 11 }}/></div>
          <div style={{ flex: 1, fontSize: 12, color: 'var(--ink-700)', lineHeight: 1.5 }}>
            본인인증 약관 및 통신사 약관에 모두 동의
            <span style={{ color: 'var(--ink-500)', fontWeight: 500 }}> · 자세히</span>
          </div>
        </div>
      </div>

      <div style={{ padding: '0 16px 24px' }}>
        <Btn kind="primary" size="lg" full>PASS 앱으로 인증하기</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A5. 약관 동의
// ═══════════════════════════════════════════════════════════════════════
function MobileTerms() {
  const items = [
    { l: '서비스 이용약관', req: true, on: true },
    { l: '개인정보 수집·이용 동의', req: true, on: true },
    { l: '개인정보 제3자 제공 동의', req: true, on: true, desc: '연계 시설/병원' },
    { l: '위치 기반 서비스 이용약관', req: true, on: true },
    { l: '마케팅 정보 수신 동의', req: false, on: false, desc: '혜택·이벤트 안내' },
    { l: '광고성 정보 수신 동의 (SMS, 이메일)', req: false, on: false }
  ];

  return (
    <div style={{ width: M_W, height: CONTENT_H, background: '#fff', display: 'flex', flexDirection: 'column' }}>
      <MNavBar title="약관 동의" back/>
      <MProgressBar step={2} total={5}/>

      <div style={{ padding: '12px 20px 0', flex: 1 }}>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.35 }}>
          서비스 이용을 위한<br/>약관에 동의해주세요
        </div>

        {/* All consent */}
        <div style={{ marginTop: 22, padding: '14px 16px', background: 'var(--navy-50)', borderRadius: 12, display: 'flex', alignItems: 'center', gap: 12, border: '1px solid var(--navy-200)' }}>
          <div style={{ width: 24, height: 24, borderRadius: 6, background: 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.check style={{ width: 14, height: 14 }}/></div>
          <div style={{ flex: 1 }}>
            <div style={{ fontSize: 14, fontWeight: 700 }}>전체 약관에 동의합니다</div>
            <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>선택 항목 포함 모두 동의</div>
          </div>
        </div>

        {/* Items */}
        <div style={{ marginTop: 18, display: 'flex', flexDirection: 'column' }}>
          {items.map((it, i) => (
            <div key={i} style={{ display: 'flex', alignItems: 'center', gap: 12, padding: '14px 4px', borderTop: i > 0 ? '1px solid var(--ink-100)' : 'none' }}>
              <div style={{
                width: 22, height: 22, borderRadius: 6,
                background: it.on ? 'var(--navy-700)' : '#fff',
                border: it.on ? 'none' : '1.5px solid var(--ink-200)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff'
              }}>{it.on && <Ic.check style={{ width: 12, height: 12 }}/>}</div>
              <div style={{ flex: 1 }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
                  <span style={{ fontSize: 11, fontWeight: 700, color: it.req ? 'var(--navy-700)' : 'var(--ink-500)' }}>{it.req ? '[필수]' : '[선택]'}</span>
                  <span style={{ fontSize: 13, color: 'var(--ink-800)' }}>{it.l}</span>
                </div>
                {it.desc && <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>{it.desc}</div>}
              </div>
              <Ic.chevR style={{ color: 'var(--ink-400)', width: 14, height: 14 }}/>
            </div>
          ))}
        </div>
      </div>

      <div style={{ padding: '12px 16px 24px' }}>
        <Btn kind="primary" size="lg" full>동의하고 계속</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A6. 부모님 정보 등록
// ═══════════════════════════════════════════════════════════════════════
function MobileParent() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', display: 'flex', flexDirection: 'column' }}>
      <MNavBar title="부모님 정보 등록" back/>
      <MProgressBar step={3} total={5}/>

      <div style={{ padding: '12px 16px 0', flex: 1, overflow: 'hidden', display: 'flex', flexDirection: 'column', gap: 14 }}>
        <div>
          <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.35, padding: '0 4px' }}>
            돌보시는 어르신에 대해<br/>알려주세요
          </div>
          <div style={{ fontSize: 12, color: 'var(--ink-500)', marginTop: 8, padding: '0 4px' }}>
            정확할수록 AI 시설 추천이 더 정확해집니다
          </div>
        </div>

        <Card padding={16}>
          {/* Photo upload */}
          <div style={{ display: 'flex', alignItems: 'center', gap: 14, marginBottom: 16 }}>
            <div style={{ width: 64, height: 64, borderRadius: '50%', background: 'var(--ink-100)', border: '2px dashed var(--ink-300)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: 'var(--ink-500)' }}>
              <Ic.camera/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 600 }}>어르신 사진 (선택)</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 3 }}>홈 화면에 표시됩니다</div>
            </div>
          </div>

          <div className="label" style={{ marginBottom: 6 }}>이름 / 호칭</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <div style={{ flex: 2, padding: '12px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 10, fontSize: 14 }}>박정호</div>
            <div style={{ flex: 1, padding: '12px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 10, fontSize: 14, display: 'flex', justifyContent: 'space-between' }}>아버지 <Ic.chevD style={{ color: 'var(--ink-500)' }}/></div>
          </div>

          <div className="label" style={{ marginTop: 14, marginBottom: 6 }}>생년월일 / 성별</div>
          <div style={{ display: 'flex', gap: 8 }}>
            <div style={{ flex: 2, padding: '12px 14px', background: '#fff', border: '1px solid var(--ink-200)', borderRadius: 10, fontSize: 14 }} className="num">1948.07.15</div>
            <div style={{ display: 'flex', gap: 4, flex: 1 }}>
              {[{l:'남',on:true},{l:'여'}].map(s => (
                <div key={s.l} style={{ flex: 1, padding: '12px 0', background: s.on ? 'var(--navy-700)' : '#fff', color: s.on ? '#fff' : 'var(--ink-700)', borderRadius: 10, border: s.on ? 'none' : '1px solid var(--ink-200)', textAlign: 'center', fontSize: 14, fontWeight: 600 }}>{s.l}</div>
              ))}
            </div>
          </div>
        </Card>

        <Card padding={16}>
          <div className="label" style={{ marginBottom: 8 }}>장기요양등급</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 6 }}>
            {['1등급','2등급','3등급','4등급','5등급','없음·모름'].map((g, i) => (
              <div key={g} style={{
                padding: '10px 0', textAlign: 'center',
                background: i === 1 ? 'var(--navy-700)' : '#fff',
                color: i === 1 ? '#fff' : 'var(--ink-700)',
                border: i === 1 ? 'none' : '1px solid var(--ink-200)',
                borderRadius: 8, fontSize: 12, fontWeight: 600
              }}>{g}</div>
            ))}
          </div>

          <div className="label" style={{ marginTop: 14, marginBottom: 8 }}>치매 / 거동 상태</div>
          <div style={{ display: 'flex', flexDirection: 'column', gap: 8 }}>
            <div style={{ display: 'flex', gap: 4 }}>
              {[{l:'치매 없음'},{l:'초기',on:true},{l:'중기'},{l:'후기'}].map(o => (
                <div key={o.l} style={{ flex: 1, padding: '10px 0', textAlign: 'center', background: o.on ? 'var(--navy-700)' : '#fff', color: o.on ? '#fff' : 'var(--ink-700)', borderRadius: 8, border: o.on ? 'none' : '1px solid var(--ink-200)', fontSize: 12, fontWeight: 600 }}>{o.l}</div>
              ))}
            </div>
            <div style={{ display: 'flex', gap: 4 }}>
              {[{l:'자립',on:true},{l:'부축'},{l:'휠체어'},{l:'와상'}].map(o => (
                <div key={o.l} style={{ flex: 1, padding: '10px 0', textAlign: 'center', background: o.on ? 'var(--navy-700)' : '#fff', color: o.on ? '#fff' : 'var(--ink-700)', borderRadius: 8, border: o.on ? 'none' : '1px solid var(--ink-200)', fontSize: 12, fontWeight: 600 }}>{o.l}</div>
              ))}
            </div>
          </div>
        </Card>
      </div>

      <div style={{ padding: '12px 16px 24px' }}>
        <Btn kind="primary" size="lg" full>다음 — 시설 연결</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// A7. 시설 연결
// ═══════════════════════════════════════════════════════════════════════
function MobileLinkFacility() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', display: 'flex', flexDirection: 'column' }}>
      <MNavBar title="시설 연결" back right={<span style={{ fontSize: 13, color: 'var(--ink-500)', fontWeight: 500 }}>나중에</span>}/>
      <MProgressBar step={4} total={5}/>

      <div style={{ padding: '12px 16px', flex: 1, overflow: 'hidden' }}>
        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.35 }}>
          아버지께서 이미<br/>입소 중이신가요?
        </div>
        <div style={{ fontSize: 12, color: 'var(--ink-500)', marginTop: 8 }}>
          시설을 연결하면 매일 케어 현황을 받아볼 수 있어요
        </div>

        {/* Option A — already in facility */}
        <Card padding={18} style={{ marginTop: 18, border: '2px solid var(--navy-700)' }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--navy-100)', color: 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Ic.building/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>이미 입소 중</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2, lineHeight: 1.5 }}>시설에서 받은 초대코드 또는 시설명으로 연결</div>
            </div>
            <div style={{ width: 18, height: 18, borderRadius: '50%', background: 'var(--navy-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.check style={{ width: 12, height: 12 }}/></div>
          </div>

          <div className="label" style={{ marginTop: 14, marginBottom: 6 }}>시설 초대코드</div>
          <div style={{ display: 'flex', gap: 6 }}>
            {['H','A','J','-','4','8','9','2'].map((c, i) => (
              <div key={i} style={{
                flex: 1, height: 44, display: 'flex', alignItems: 'center', justifyContent: 'center',
                background: '#fff', border: '1px solid ' + (c === '-' ? 'transparent' : i < 4 ? 'var(--navy-700)' : 'var(--ink-200)'),
                borderRadius: 8, fontSize: 18, fontWeight: 700,
                color: c === '-' ? 'var(--ink-300)' : 'var(--ink-900)'
              }}>{c}</div>
            ))}
          </div>
          <div style={{ fontSize: 11, color: 'var(--navy-700)', marginTop: 8, fontWeight: 600, display: 'inline-flex', alignItems: 'center', gap: 4 }}>
            <Ic.check style={{ width: 12, height: 12 }}/> 햇살요양원 — 박정호 (304호)
          </div>
        </Card>

        {/* Option B — looking */}
        <Card padding={18} style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: 'var(--green-100)', color: 'var(--green-700)', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Ic.search/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>시설을 찾고 있어요</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2, lineHeight: 1.5 }}>AI 추천으로 부모님께 맞는 시설 찾기</div>
            </div>
            <div style={{ width: 18, height: 18, borderRadius: '50%', border: '1.5px solid var(--ink-300)' }}/>
          </div>
        </Card>

        {/* Option C — care at home */}
        <Card padding={18} style={{ marginTop: 10 }}>
          <div style={{ display: 'flex', alignItems: 'flex-start', gap: 12 }}>
            <div style={{ width: 40, height: 40, borderRadius: 10, background: '#F3E1D4', color: '#A65A3D', display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0 }}>
              <Ic.home/>
            </div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>아직 재가 중</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2, lineHeight: 1.5 }}>나중에 필요할 때 시설을 찾을게요</div>
            </div>
            <div style={{ width: 18, height: 18, borderRadius: '50%', border: '1.5px solid var(--ink-300)' }}/>
          </div>
        </Card>
      </div>

      <div style={{ padding: '12px 16px 24px' }}>
        <Btn kind="primary" size="lg" full>연결하고 시작하기</Btn>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// B1. 홈 — 미연결 (Empty State)
// ═══════════════════════════════════════════════════════════════════════
function MobileHomeEmpty() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      {/* Slim header */}
      <div style={{ padding: '14px 20px 8px', background: '#fff', borderBottom: '1px solid var(--ink-100)' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <div>
            <div style={{ fontSize: 12, color: 'var(--ink-500)', fontWeight: 500 }}>안녕하세요</div>
            <div style={{ fontSize: 18, fontWeight: 700 }}>박소영 님</div>
          </div>
          <div style={{ display: 'flex', gap: 14, color: 'var(--ink-700)' }}>
            <Ic.bell/>
            <Ic.cog/>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '16px 16px 80px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* Big CTA empty */}
        <div style={{ background: 'linear-gradient(135deg, var(--navy-800), var(--navy-700))', borderRadius: 16, padding: 22, color: '#fff', position: 'relative', overflow: 'hidden' }}>
          <div style={{ position: 'absolute', top: -40, right: -40, width: 160, height: 160, borderRadius: '50%', background: 'rgba(255,255,255,0.06)' }}/>

          <Tag tone="outline" size="sm" style={{ background: 'rgba(255,255,255,0.1)', color: '#fff', borderColor: 'rgba(255,255,255,0.2)', marginBottom: 10 }}>
            <Ic.sparkle style={{ width: 11, height: 11 }}/> 시작하기
          </Tag>
          <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.35 }}>
            돌보실 어르신을<br/>먼저 등록해주세요
          </div>
          <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.75)', marginTop: 8, lineHeight: 1.55 }}>
            AI가 시설을 추천하고, 입소 후엔<br/>매일 케어 현황을 받아볼 수 있어요
          </div>
          <div style={{ marginTop: 16, display: 'flex', gap: 8 }}>
            <div style={{ padding: '10px 16px', background: '#fff', color: 'var(--navy-800)', borderRadius: 'var(--r-pill)', fontSize: 13, fontWeight: 700 }}>어르신 등록 →</div>
          </div>
        </div>

        {/* Next steps */}
        <Card padding={16}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>시작 가이드</div>
          {[
            { n: 1, t: '어르신 정보 등록', s: '이름, 등급, 건강 상태', done: false, current: true },
            { n: 2, t: '시설 찾기 또는 연결', s: 'AI 추천 받기 / 초대코드', done: false },
            { n: 3, t: '매일 케어 현황 확인', s: '식사 · 복약 · 활력 · 사진', done: false }
          ].map((s, i, a) => (
            <div key={i} style={{ display: 'flex', gap: 12, padding: '8px 0' }}>
              <div style={{
                width: 24, height: 24, borderRadius: '50%',
                background: s.done ? 'var(--green-700)' : s.current ? 'var(--navy-700)' : 'var(--ink-100)',
                color: s.done || s.current ? '#fff' : 'var(--ink-500)',
                display: 'flex', alignItems: 'center', justifyContent: 'center',
                fontSize: 12, fontWeight: 700, flexShrink: 0
              }}>{s.done ? <Ic.check style={{ width: 12, height: 12 }}/> : s.n}</div>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: s.current ? 'var(--ink-900)' : 'var(--ink-700)' }}>{s.t}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>{s.s}</div>
              </div>
              {s.current && <Ic.chevR style={{ color: 'var(--navy-700)', marginTop: 4 }}/>}
            </div>
          ))}
        </Card>

        {/* Helpful shortcuts */}
        <div>
          <div style={{ fontSize: 12, fontWeight: 700, color: 'var(--ink-700)', marginBottom: 8, padding: '0 4px' }}>먼저 둘러볼까요?</div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(2, 1fr)', gap: 8 }}>
            {[
              { t: '시설 찾기', s: '지역·등급별 검색', ic: Ic.search, tone: 'navy' },
              { t: 'AI 상담', s: '미리 알아보기', ic: Ic.sparkle, tone: 'green' },
              { t: '비용 가이드', s: '본인부담금 계산', ic: Ic.won, tone: 'plum' },
              { t: '입소 안내', s: '준비 절차', ic: Ic.doc, tone: 'warm' }
            ].map((q, i) => {
              const Icon = q.ic;
              const tones = { navy: ['var(--navy-100)','var(--navy-700)'], green: ['var(--green-100)','var(--green-700)'], plum: ['#EBE0EB','#7A4B7A'], warm: ['#F3E1D4','#A65A3D'] };
              const [bg, fg] = tones[q.tone];
              return (
                <div key={i} style={{ background: '#fff', borderRadius: 12, padding: 14, border: '1px solid var(--ink-100)' }}>
                  <div style={{ width: 36, height: 36, borderRadius: 10, background: bg, color: fg, display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: 10 }}><Icon/></div>
                  <div style={{ fontSize: 13, fontWeight: 700 }}>{q.t}</div>
                  <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>{q.s}</div>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// B2. 홈 — 시설 대기 중 (부모 등록 / 시설 매칭 진행)
// ═══════════════════════════════════════════════════════════════════════
function MobileHomePending() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      {/* Header */}
      <div style={{ background: 'linear-gradient(180deg, var(--navy-800) 0%, var(--navy-700) 100%)', color: '#fff', padding: '14px 20px 22px' }}>
        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 18 }}>
          <div style={{ fontSize: 14, color: 'rgba(255,255,255,0.7)', fontWeight: 500 }}>2026년 5월 28일 목</div>
          <div style={{ display: 'flex', gap: 14 }}>
            <Ic.bell style={{ color: '#fff' }}/>
            <Ic.cog style={{ color: '#fff' }}/>
          </div>
        </div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 14 }}>
          <Avatar name="박" tone="warm" size={52} style={{ border: '2px solid rgba(255,255,255,0.3)' }}/>
          <div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.7)', marginBottom: 2 }}>아버지</div>
            <div style={{ fontSize: 20, fontWeight: 700, letterSpacing: '-0.02em' }}>박정호 님</div>
            <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)', marginTop: 4, display: 'flex', alignItems: 'center', gap: 4 }}>
              <span style={{ width: 6, height: 6, borderRadius: '50%', background: 'var(--warning)' }}/>
              시설 매칭 진행 중
            </div>
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '16px 16px 80px', display: 'flex', flexDirection: 'column', gap: 14 }}>
        {/* AI matching status */}
        <Card padding={18}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 12 }}>
            <div style={{ width: 32, height: 32, borderRadius: 10, background: 'linear-gradient(135deg, var(--navy-700), var(--green-700))', display: 'flex', alignItems: 'center', justifyContent: 'center', color: '#fff' }}><Ic.sparkle style={{ width: 16, height: 16 }}/></div>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 14, fontWeight: 700 }}>AI가 시설을 찾고 있어요</div>
              <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>2등급 · 치매 초기 · 강남 인근 기준</div>
            </div>
            <Tag tone="navy" size="sm" dot>진행 중</Tag>
          </div>

          {/* Progress */}
          <div style={{ marginTop: 8 }}>
            <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 11, color: 'var(--ink-500)', marginBottom: 6 }}>
              <span>매칭 단계</span>
              <span style={{ fontWeight: 700, color: 'var(--navy-700)' }}>3 / 5 완료</span>
            </div>
            <div style={{ height: 6, background: 'var(--ink-100)', borderRadius: 3, overflow: 'hidden' }}>
              <div style={{ width: '60%', height: '100%', background: 'linear-gradient(90deg, var(--navy-700), var(--green-600))' }}/>
            </div>
          </div>

          <div style={{ marginTop: 14, padding: 12, background: 'var(--bg-sunken)', borderRadius: 10 }}>
            <div style={{ fontSize: 11, color: 'var(--ink-500)', fontWeight: 600 }}>현재 상태</div>
            <div style={{ fontSize: 13, fontWeight: 600, marginTop: 4 }}>3개 시설 방문 예약 단계</div>
            <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 4 }}>케어 코디 홍은영 담당</div>
          </div>
        </Card>

        {/* Recommended facilities */}
        <Card padding={16}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>추천 시설 (3)</div>
            <span style={{ fontSize: 11, color: 'var(--navy-700)', fontWeight: 600 }}>모두 보기</span>
          </div>
          <div style={{ display: 'flex', gap: 8, overflowX: 'auto' }}>
            {[
              { n: '햇살요양원', tone: 'navy', stat: '방문 5/30', rate: 4.7 },
              { n: '늘봄케어', tone: 'green', stat: '응답 대기', rate: 4.5 },
              { n: '평안의 집', tone: 'plum', stat: '검토 중', rate: 4.6 }
            ].map((f, i) => (
              <div key={i} style={{ minWidth: 130, padding: 10, background: 'var(--bg-sunken)', borderRadius: 10 }}>
                <Photo tone={f.tone} ratio="4/3" style={{ borderRadius: 8, marginBottom: 8 }}/>
                <div style={{ fontSize: 12, fontWeight: 700 }}>{f.n}</div>
                <div style={{ display: 'flex', alignItems: 'center', gap: 3, marginTop: 3 }}>
                  <Stars value={f.rate} size={10}/>
                  <span style={{ fontSize: 10, color: 'var(--ink-500)' }}>{f.rate}</span>
                </div>
                <Tag tone="navy" size="sm" style={{ marginTop: 6 }}>{f.stat}</Tag>
              </div>
            ))}
          </div>
        </Card>

        {/* Next action */}
        <Card padding={14} style={{ background: 'var(--warning-soft)', border: '1px solid #F2DDB8' }}>
          <div style={{ display: 'flex', gap: 10, alignItems: 'flex-start' }}>
            <Ic.clock style={{ color: 'var(--warning)', flexShrink: 0, marginTop: 1 }}/>
            <div style={{ flex: 1 }}>
              <div style={{ fontSize: 13, fontWeight: 700, color: 'var(--warning)' }}>내일 햇살요양원 방문</div>
              <div style={{ fontSize: 11, color: 'var(--ink-700)', marginTop: 3 }}>5월 30일 (금) 오전 10시 · 코디네이터 동행</div>
            </div>
            <Ic.chevR style={{ color: 'var(--warning)', marginTop: 2 }}/>
          </div>
        </Card>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════
// B3. 홈 — 긴급 상태
// ═══════════════════════════════════════════════════════════════════════
function MobileHomeUrgent() {
  return (
    <div style={{ width: M_W, height: CONTENT_H, background: 'var(--bg-page)', overflow: 'hidden', display: 'flex', flexDirection: 'column' }}>
      {/* Urgent banner — replaces hero */}
      <div style={{ background: 'linear-gradient(180deg, #8C1F1A 0%, #C8362F 100%)', color: '#fff', padding: '14px 20px 22px', position: 'relative', overflow: 'hidden' }}>
        <div style={{ position: 'absolute', top: -40, right: -40, width: 180, height: 180, borderRadius: '50%', background: 'rgba(255,255,255,0.06)' }}/>

        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 14 }}>
          <div style={{ display: 'flex', alignItems: 'center', gap: 6 }}>
            <Ic.alert style={{ color: '#fff' }}/>
            <span style={{ fontSize: 13, fontWeight: 700, letterSpacing: '0.05em' }}>긴급 알림</span>
          </div>
          <div style={{ display: 'flex', gap: 14 }}>
            <Ic.bell style={{ color: '#fff' }}/>
            <Ic.cog style={{ color: '#fff' }}/>
          </div>
        </div>

        <div style={{ fontSize: 22, fontWeight: 700, letterSpacing: '-0.02em', lineHeight: 1.35 }}>
          아버지 발열 관찰<br/>응급실 이송 검토 중
        </div>
        <div style={{ fontSize: 12, color: 'rgba(255,255,255,0.85)', marginTop: 8, lineHeight: 1.55 }}>
          14:08 측정 · 체온 38.6°C · 호흡곤란 동반<br/>
          햇살요양원 간호사 김지영 — 8분 전 보고
        </div>

        <div style={{ display: 'flex', gap: 8, marginTop: 16 }}>
          <div style={{ flex: 1, padding: '11px 0', background: '#fff', color: '#C8362F', borderRadius: 10, textAlign: 'center', fontSize: 13, fontWeight: 700, display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Ic.phone style={{ width: 14, height: 14 }}/> 시설 전화
          </div>
          <div style={{ flex: 1, padding: '11px 0', background: 'rgba(255,255,255,0.15)', color: '#fff', borderRadius: 10, textAlign: 'center', fontSize: 13, fontWeight: 700, border: '1px solid rgba(255,255,255,0.3)', display: 'inline-flex', alignItems: 'center', justifyContent: 'center', gap: 6 }}>
            <Ic.chat style={{ width: 14, height: 14 }}/> 메시지
          </div>
        </div>
      </div>

      <div style={{ flex: 1, overflow: 'hidden', padding: '14px 16px 80px', display: 'flex', flexDirection: 'column', gap: 12 }}>
        {/* Vitals timeline */}
        <Card padding={16}>
          <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginBottom: 12 }}>
            <div style={{ fontSize: 13, fontWeight: 700 }}>활력 측정 추이</div>
            <Tag tone="danger" size="sm" dot>관찰 필요</Tag>
          </div>
          <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 6 }}>
            {[
              { t: '08:00', v: '36.5', tone: 'ok' },
              { t: '12:00', v: '37.1', tone: 'warn' },
              { t: '14:00', v: '38.2', tone: 'warn' },
              { t: '14:30', v: '38.6', tone: 'danger', now: true }
            ].map((m, i) => {
              const tones = {
                ok: { bg: 'var(--green-50)', fg: 'var(--green-800)' },
                warn: { bg: 'var(--warning-soft)', fg: 'var(--warning)' },
                danger: { bg: 'var(--danger-soft)', fg: 'var(--danger)' }
              };
              const c = tones[m.tone];
              return (
                <div key={i} style={{ padding: 10, background: c.bg, borderRadius: 8, textAlign: 'center', border: m.now ? `1.5px solid ${c.fg}` : 'none' }}>
                  <div style={{ fontSize: 10, color: 'var(--ink-500)' }}>{m.t}</div>
                  <div className="num" style={{ fontSize: 16, fontWeight: 700, color: c.fg, marginTop: 2 }}>{m.v}°</div>
                  {m.now && <div style={{ fontSize: 9, fontWeight: 600, color: c.fg, marginTop: 1 }}>최근</div>}
                </div>
              );
            })}
          </div>
        </Card>

        {/* Action plan */}
        <Card padding={16}>
          <div style={{ fontSize: 13, fontWeight: 700, marginBottom: 12 }}>시설 대응 현황</div>
          {[
            { t: '발열 1차 측정', d: '14:00 · 김지영 간호사', done: true },
            { t: '주치의 보고', d: '14:12 · 윤민호 원장', done: true },
            { t: '응급실 이송 결정 대기', d: '진행 중 · 보호자 협의 필요', done: false, current: true },
            { t: '이송 및 가족 합류', d: '대기', done: false }
          ].map((it, i, a) => (
            <div key={i} style={{ display: 'flex', gap: 10, padding: '6px 0', position: 'relative' }}>
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center' }}>
                <div style={{
                  width: 18, height: 18, borderRadius: '50%',
                  background: it.done ? 'var(--green-700)' : it.current ? 'var(--danger)' : '#fff',
                  border: it.done || it.current ? 'none' : '1.5px solid var(--ink-300)',
                  color: '#fff',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', flexShrink: 0
                }}>{it.done && <Ic.check style={{ width: 10, height: 10 }}/>}</div>
                {i < a.length - 1 && <div style={{ width: 2, flex: 1, background: 'var(--ink-100)', minHeight: 16 }}/>}
              </div>
              <div style={{ flex: 1, paddingTop: 1 }}>
                <div style={{ fontSize: 13, fontWeight: it.current ? 700 : 600, color: it.current ? 'var(--danger)' : 'var(--ink-800)' }}>{it.t}</div>
                <div style={{ fontSize: 11, color: 'var(--ink-500)', marginTop: 2 }}>{it.d}</div>
              </div>
            </div>
          ))}

          <Btn kind="danger" full style={{ marginTop: 12 }}>응급실 이송에 동의</Btn>
        </Card>
      </div>
    </div>
  );
}

Object.assign(window, {
  MNavBar, MProgressBar,
  MobileSplash, MobileOnboarding, MobileLogin, MobileAuth, MobileTerms,
  MobileParent, MobileLinkFacility,
  MobileHomeEmpty, MobileHomePending, MobileHomeUrgent
});
